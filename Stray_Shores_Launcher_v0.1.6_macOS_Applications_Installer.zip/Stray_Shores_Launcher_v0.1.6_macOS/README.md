# Stray Shores Launcher v0.1.6 — Mac installer fix

**This archive is a source-and-builder installer, not an already-built notarized Mac app.**

## Install in the standard Applications folder

1. Install Python 3 with Tk from [python.org](https://www.python.org/downloads/macos/).
2. Extract the ZIP, then double-click `Build_and_Install_Launcher.command` **once**.
3. Let the builder finish; macOS may ask for **administrator permission** to copy the app into `/Applications`.
4. The installer **verifies** `/Applications/Stray Shores Launcher.app` and reveals the installed file in Finder. It will not report success if installation fails.
5. On later launches, open **Applications → Stray Shores Launcher** (or use Launchpad / the Dock).

Unlike v0.1.5, this installer does **not** put the app into `~/Applications`.
It also does not include a misleading, Python-dependent `.app` wrapper in the ZIP.

## macOS security

The resulting application is ad-hoc signed, **not Apple Developer ID signed or notarized**. You may need to go to System Settings → Privacy & Security → Open Anyway after trying to open it. Only approve software you trust. Never disable Gatekeeper globally.

## Online games

The GitHub game catalog will remain empty until compiled game releases are published. This is unrelated to installing the launcher itself.
