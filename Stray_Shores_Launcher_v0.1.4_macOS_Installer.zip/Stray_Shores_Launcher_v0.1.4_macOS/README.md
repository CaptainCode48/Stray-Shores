# Stray Shores Launcher v0.1.4 — Mac

The launcher is a graphical Mac application. **The bundled `.app` is a Python/Tk wrapper, not a prebuilt self-contained executable.** The ZIP includes the source and a one-time builder/installer for a standalone app.

## Recommended installation (once)

1. Install current Python 3 from python.org, including Tk.
2. Extract this ZIP, right-click `Build_and_Install_Launcher.command` and choose **Open** (or run `bash Build_and_Install_Launcher.command` in Terminal).
3. The builder installs PyInstaller, creates a standalone app, and copies it to `~/Applications/Stray Shores Launcher.app`.
4. In Finder choose **Go > Home > Applications**. The `~/Applications` folder is **different** from the system `/Applications` folder shown in Finder's sidebar. Drag the finished app into `/Applications` if desired.
5. Launch the app from Finder or add it to your Dock. You do **not** need to rerun the command for normal launches.

## macOS security

These are community-generated, locally built apps. They are **not Apple Developer ID signed or notarized**, so macOS Gatekeeper may block the first launch. For an app you trust and built yourself, use Finder's contextual **Open** action or System Settings > Privacy & Security > **Open Anyway** when offered. Never globally disable Gatekeeper or run obscure bypass commands.

## Games and updates

- Launcher version: **0.1.4**. Game versions are separate.
- Public GitHub repository: https://github.com/CaptainCode48/Stray-Shores
- The launcher uses verified SHA-256 release manifests. If the catalog is missing, it checks public GitHub release metadata and shows a friendly empty state rather than HTTP 404.
- Game builder ZIPs are **not** compiled `.app` game releases. Build the game on a Mac first, then import the compiled `.app`.
- To download games directly in the launcher, GitHub must publish real compiled `.app` ZIP releases and their SHA-256 catalog entries.

Python source and Mac builder scripts can be audited before running. The launcher has not been tested interactively on macOS in this environment.
