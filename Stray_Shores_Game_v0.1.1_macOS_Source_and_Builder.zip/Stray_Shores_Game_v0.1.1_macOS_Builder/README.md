# Stray Shores Game v0.1.1 — Mac

This package contains **game source and a macOS Apple Silicon app builder**, not a precompiled, signed or notarized application.

- Platform: macOS 26+; Apple Silicon Mac (arm64).
- Game version: **v0.1.1** (independent of the launcher).
- Build: double-click `Build_Standalone_ARM64_on_Mac.command` or use Terminal `bash Build_Standalone_ARM64_on_Mac.command`.
- Install: run `Install_App_in_Applications.command` once after building, then start from Applications.
- The Mac may display a Gatekeeper warning for an unsigned/notarized local build. Do not disable security globally.
- Back up saves before switching between versions.

Game v0.1.1 adds islands, regional markets and fantasy encounters. Game v0.1.0 is the original baseline.
