#!/bin/bash
set -u
cd "$(dirname "$0")"
APP="/Applications/Stray Shores.app"
[[ -d "$APP" ]] || APP="$PWD/build-output/Stray Shores.app"
REPORT="$HOME/Desktop/Stray_Shores_Diagnostic.txt"
{
 echo 'Stray Shores macOS diagnostic'
 date
 uname -a
 echo "App: $APP"
 if [[ ! -d "$APP" ]]; then echo 'APP NOT FOUND. Build first.'; exit 1; fi
 echo 'Bundle metadata:'
 /usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$APP/Contents/Info.plist"
 /usr/libexec/PlistBuddy -c 'Print :CFBundleExecutable' "$APP/Contents/Info.plist"
 /usr/libexec/PlistBuddy -c 'Print :LSMinimumSystemVersion' "$APP/Contents/Info.plist"
 plutil -lint "$APP/Contents/Info.plist"
 echo 'Architecture:'
 file "$APP/Contents/MacOS/Stray Shores"
 echo 'Signature:'
 codesign --verify --deep --strict --verbose=2 "$APP" 2>&1
 echo 'Packaged runtime self-test:'
 "$APP/Contents/MacOS/Stray Shores" --self-test 2>&1
 echo 'Latest crash log:'
 LOG="$HOME/Library/Application Support/Stray Shores/crash.log"
 if [[ -f "$LOG" ]]; then tail -n 80 "$LOG"; else echo 'No crash log.'; fi
} >"$REPORT" 2>&1
cat "$REPORT"
echo "Diagnostic saved to: $REPORT"
read -r -p 'Press Return to close...' _ || true
