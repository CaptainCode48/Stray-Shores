"""Mac app entrypoint. Logs crashes so they do not silently disappear."""
import os
import sys
import traceback
from pathlib import Path
import runpy
# Import normally during startup; a --self-test verifies packaged resources.
import pygame  # Ensure PyInstaller detects the graphics dependency.
import mod_extensions  # Bundle the mod system in the standalone application.

data_dir = Path(os.environ.get("STRAY_SHORES_DATA_DIR") or (Path.home() / "Library" / "Application Support" / "Stray Shores" / "versions" / "0.1.0"))
data_dir.mkdir(parents=True, exist_ok=True)
os.environ["STRAY_SHORES_DATA_DIR"] = str(data_dir)
bundle_dir = Path(getattr(sys, "_MEIPASS", Path(__file__).parent))
game_path = bundle_dir / "game.py"

if "--self-test" in sys.argv:
    import importlib.util
    import py_compile
    import json
    print("Stray Shores app diagnostic")
    print("Game file:", game_path)
    print("Game exists:", game_path.is_file())
    print("Mod loader:", mod_extensions.__file__)
    print("Pygame version:", pygame.version.ver)
    print("Data folder:", data_dir)
    if not game_path.is_file():
        raise SystemExit("ERROR: game.py wasn't bundled")
    source = game_path.read_text(encoding="utf-8")
    compile(source, str(game_path), "exec")
    (data_dir / "app_diagnostic.txt").write_text(
        "Self-test passed\nPygame: " + pygame.version.ver + "\nGame source: " + str(game_path) + "\n",
        encoding="utf-8",
    )
    print("SELF-TEST PASSED")
    raise SystemExit(0)
try:
    runpy.run_path(str(game_path), run_name="__main__")
except SystemExit:
    raise
except BaseException:
    log = data_dir / "crash.log"
    with log.open("a", encoding="utf-8") as fp:
        fp.write("\n=== Stray Shores startup/runtime failure ===\n")
        traceback.print_exc(file=fp)
    traceback.print_exc()
    # Show a clear Finder-style alert for GUI app users.
    import subprocess
    subprocess.run(["osascript", "-e",
      'display alert "Stray Shores crashed" message "A technical report was saved to ~/Library/Application Support/Stray Shores/crash.log" as critical'], check=False)
    sys.exit(1)
