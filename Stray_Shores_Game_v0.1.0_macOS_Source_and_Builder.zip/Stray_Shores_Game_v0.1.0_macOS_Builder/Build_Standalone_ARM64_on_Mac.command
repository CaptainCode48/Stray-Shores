#!/bin/bash
# Build a native arm64 standalone .app on macOS 26+.
set -Eeuo pipefail
cd "$(dirname "$0")"
ROOT="$PWD"
GAME="$ROOT/Game"
OUT="$ROOT/build-output"

fail() {
  echo
  echo 'BUILD FAILED. Read the error above.'
  read -r -p 'Press Return to close this window...' _ || true
}
trap fail ERR

echo '================================================'
echo ' Stray Shores GAME v0.1.0 — macOS 26+ ARM64 App Builder'
echo '================================================'

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo 'This script only works on macOS.'
  exit 1
fi
if [[ "$(uname -m)" != "arm64" ]]; then
  echo 'Apple Silicon is required. Run Terminal natively, not through Rosetta.'
  exit 1
fi

# Choose an Apple Silicon Python, with Homebrew preferred when present.
if [[ -x /opt/homebrew/bin/python3 ]]; then
  PYTHON=/opt/homebrew/bin/python3
else
  PYTHON="$(command -v python3 || true)"
fi
if [[ -z "$PYTHON" ]]; then
  echo 'Python 3.11 or newer is required to build. Install the Apple Silicon release from python.org.'
  exit 1
fi
"$PYTHON" - <<'PY'
import platform, sys
major = int(platform.mac_ver()[0].split('.')[0])
if major < 26:
    raise SystemExit('Requires macOS 26 or newer.')
if platform.machine() != 'arm64':
    raise SystemExit('Requires native ARM64 Python (not Rosetta).')
if sys.version_info < (3, 11):
    raise SystemExit('Requires Python 3.11 or newer. Install from python.org or Homebrew.')
print('macOS:',platform.mac_ver()[0], '| Python:',sys.version.split()[0], '| Arch:',platform.machine())
PY

VENV="$ROOT/.build-venv"
if [[ ! -x "$VENV/bin/python" ]]; then
  "$PYTHON" -m venv "$VENV"
fi
"$VENV/bin/python" -m pip install --upgrade pip
# pygame 2.6.1 has no CPython 3.14 macOS wheel; pygame-ce 2.5.7 does.
# Force binary wheels so a missing SDK cannot trigger a source compile.
"$VENV/bin/python" -m pip uninstall -y pygame >/dev/null 2>&1 || true
"$VENV/bin/python" -m pip install --only-binary=:all: 'pyinstaller>=6.11,<8' 'pygame-ce==2.5.7'
"$VENV/bin/python" - <<'PYVERIFY'
import pygame, platform
print('Graphics runtime:', pygame.version.ver, '| Machine:', platform.machine())
PYVERIFY

mkdir -p "$OUT"
export MACOSX_DEPLOYMENT_TARGET=26.0
"$VENV/bin/python" -m PyInstaller \
    --noconfirm --clean --windowed --onedir \
    --target-arch arm64 \
    --name 'Stray Shores' \
    --osx-bundle-identifier 'com.strayshores.game' \
    --icon "$ROOT/StrayShores.icns" \
    --add-data "$GAME/mods:mods" \
    --add-data "$GAME/game.py:." \
    --distpath "$OUT" \
    --workpath "$ROOT/.pyinstaller-build" \
    --specpath "$ROOT" \
    "$GAME/launcher.py"

APP="$OUT/Stray Shores.app"
if [[ ! -d "$APP" ]]; then
  echo 'No .app was produced.'
  exit 1
fi
# Declare macOS 26+ explicitly in the app's metadata.
"$VENV/bin/python" - "$APP/Contents/Info.plist" <<'PY'
import plistlib,sys
path=sys.argv[1]
with open(path,'rb') as f: info=plistlib.load(f)
info['LSMinimumSystemVersion']='26.0'
info['CFBundleIdentifier']='com.strayshores.game'
info['CFBundlePackageType']='APPL'
info['LSApplicationCategoryType']='public.app-category.games'
info['NSHighResolutionCapable']=True
info['CFBundleShortVersionString']='0.1.0'
info['CFBundleVersion']='100'
with open(path,'wb') as f: plistlib.dump(info,f)
PY
# App registration needs valid metadata, a real executable and a valid signature.
plutil -lint "$APP/Contents/Info.plist"
if [[ ! -x "$APP/Contents/MacOS/Stray Shores" ]]; then
  echo 'ERROR: Missing executable in app bundle.'
  exit 1
fi
file "$APP/Contents/MacOS/Stray Shores"
if ! lipo -archs "$APP/Contents/MacOS/Stray Shores" | grep -qw arm64; then
  echo 'ERROR: Bundled launcher is not ARM64.'
  exit 1
fi
# Ad-hoc signing is local only and does not provide notarization.
codesign --force --deep --sign - "$APP"
codesign --verify --deep --strict --verbose=2 "$APP"
# Check packaged Python, pygame, source code, and mod loader before install.
"$APP/Contents/MacOS/Stray Shores" --self-test
# Ask Launch Services to index this exact app before installation.
LSREG="/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister"
if [[ -x "$LSREG" ]]; then
  "$LSREG" -f "$APP" || echo 'Launch Services registration deferred until install.'
fi


printf '\nBUILD COMPLETE: %s\n' "$APP"
echo 'Build validated. Use Install_App_in_Applications.command to register it in Applications.'
echo 'Game saves: ~/Library/Application Support/Stray Shores/versions/0.1.0/saves/'
echo 'Editable mods: ~/Library/Application Support/Stray Shores/versions/0.1.0/mods/'
echo 'Crash reports: ~/Library/Application Support/Stray Shores/crash.log'
echo 'The app includes Python and Pygame and does not need them on the playing Mac.'
echo 'macOS may still warn because the app is not developer-notarized.'
echo 'If it fails to open, run Diagnose_App.command and read the report.'
if [[ "${CI:-}" != "true" ]]; then
 open "$OUT"
 read -r -p 'Press Return to close this window...' _ || true
fi
