#!/usr/bin/env python3
"""Stray Shores Launcher — compact version manager for macOS."""
import queue
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog
import launcher_core as core

BG='#101b28'
SIDE='#152436'
PANEL='#192c3d'
PANEL2='#213749'
INK='#f2f6fa'
MUTED='#a2b4c2'
TEAL='#70dfbe'
BTN='#2c4759'
LINE='#345064'

class Launcher(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Stray Shores Launcher v0.1.6')
        self.geometry('1050x680')
        self.minsize(850,600)
        self.configure(bg=BG)
        self.settings=core.load_settings()
        self.remote=[]
        self.entries={}
        self.versions=[]
        self.selected_version=None
        self.selected_remote=None
        self.jobs=queue.Queue()
        self.busy=False
        self.status_text=tk.StringVar(value='Ready to explore')
        self.build_ui()
        self.refresh_local()
        self.after(140,self.poll)
        self.after(800,self.check_updates)

    def label(self,parent,text,size=12,color=INK,bold=False,wrap=0):
        kw=dict(bg=parent.cget('bg'),fg=color,font=('Helvetica Neue',size,'bold' if bold else 'normal'),justify='left',anchor='w')
        if wrap:kw['wraplength']=wrap
        return tk.Label(parent,text=text,**kw)

    def btn(self,parent,text,cmd,primary=False):
        color=TEAL if primary else BTN
        fg=BG if primary else INK
        b=tk.Label(parent,text=text,bg=color,fg=fg,font=('Helvetica Neue',12,'bold'),padx=22,pady=13,cursor='hand2')
        b.bind('<Button-1>',lambda event:cmd())
        b.bind('<Enter>',lambda e:b.configure(bg='#9cf6d8' if primary else '#37576e'))
        b.bind('<Leave>',lambda e:b.configure(bg=color))
        return b

    def separator(self,parent):
        tk.Frame(parent,bg=LINE,height=1).pack(fill='x',pady=(12,16))

    def build_ui(self):
        # Narrow side rail holds the brand and meaningful navigation, not giant empty lists.
        rail=tk.Frame(self,bg=SIDE,width=235)
        rail.pack(side='left',fill='y')
        rail.pack_propagate(False)
        brand=tk.Frame(rail,bg=SIDE)
        brand.pack(fill='x',padx=24,pady=(33,28))
        self.label(brand,'◈  STRAY SHORES',18,bold=True).pack(anchor='w')
        self.label(brand,'LAUNCHER  ·  v0.1.6',10,color=MUTED).pack(anchor='w',pady=(8,0))
        self.separator(brand)
        self.label(brand,'LIBRARY',10,color=TEAL,bold=True).pack(anchor='w')
        self.label(brand,'Your installed games',11,color=MUTED).pack(anchor='w',pady=(8,0))
        self.library=tk.Frame(rail,bg=SIDE)
        self.library.pack(fill='x',padx=14)
        self.btn(rail,'＋  Import game',self.import_version).pack(fill='x',padx=18,pady=(18,0))
        tk.Frame(rail,bg=SIDE).pack(fill='both',expand=True)
        foot=tk.Frame(rail,bg=SIDE)
        foot.pack(fill='x',padx=22,pady=(8,23))
        self.label(foot,'MAC EDITION',10,bold=True,color=TEAL).pack(anchor='w')
        self.label(foot,'Apple Silicon · macOS',10,color=MUTED).pack(anchor='w',pady=(4,0))

        main=tk.Frame(self,bg=BG)
        main.pack(side='left',fill='both',expand=True)
        top=tk.Frame(main,bg=BG)
        top.pack(fill='x',padx=36,pady=(31,24))
        self.label(top,'Your adventure starts here.',26,bold=True).pack(anchor='w')
        self.label(top,'Manage game versions and continue exploring the islands.',12,color=MUTED).pack(anchor='w',pady=(7,0))

        hero=tk.Frame(main,bg=PANEL,highlightbackground=LINE,highlightthickness=1)
        hero.pack(fill='x',padx=36)
        h=tk.Frame(hero,bg=PANEL)
        h.pack(fill='x',padx=27,pady=24)
        self.label(h,'CURRENT GAME',10,color=TEAL,bold=True).pack(anchor='w')
        self.hero_version=tk.StringVar(value='No game installed')
        tk.Label(h,textvariable=self.hero_version,bg=PANEL,fg=INK,font=('Helvetica Neue',22,'bold'),anchor='w').pack(anchor='w',pady=(10,4))
        self.hero_detail=tk.StringVar(value='Import a compiled Mac game to get started.')
        tk.Label(h,textvariable=self.hero_detail,bg=PANEL,fg=MUTED,font=('Helvetica Neue',11),anchor='w').pack(anchor='w')
        hbuttons=tk.Frame(h,bg=PANEL);hbuttons.pack(fill='x',pady=(23,0))
        self.primary_action=self.btn(hbuttons,'＋  IMPORT A GAME',self.primary_click,True)
        self.primary_action.pack(side='left')
        self.btn(hbuttons,'CHANGE VERSION',self.choose_version).pack(side='left',padx=(12,0))

        lower=tk.Frame(main,bg=BG)
        lower.pack(fill='both',expand=True,padx=36,pady=(24,0))
        downloads=tk.Frame(lower,bg=PANEL,highlightbackground=LINE,highlightthickness=1)
        downloads.pack(fill='both',expand=True)
        head=tk.Frame(downloads,bg=PANEL)
        head.pack(fill='x',padx=26,pady=(23,12))
        self.label(head,'GAME RELEASES',14,bold=True).pack(side='left')
        self.btn(head,'↻  Refresh',self.check_updates).pack(side='right')
        self.release_area=tk.Frame(downloads,bg=PANEL)
        self.release_area.pack(fill='both',expand=True,padx=24,pady=(0,10))
        row=tk.Frame(downloads,bg=PANEL)
        row.pack(fill='x',padx=26,pady=(0,20))
        self.download_action=self.btn(row,'DOWNLOAD SELECTED',self.download_selected,True)
        self.download_action.pack(side='left')
        self.catalog_state=tk.StringVar(value='Checking for game downloads…')
        tk.Label(row,textvariable=self.catalog_state,bg=PANEL,fg=MUTED,font=('Helvetica Neue',10),anchor='w',wraplength=280,justify='left').pack(side='left',padx=18)

        footer=tk.Frame(main,bg=BG)
        footer.pack(fill='x',padx=36,pady=(14,22))
        tk.Label(footer,textvariable=self.status_text,bg=BG,fg=MUTED,font=('Helvetica Neue',11),anchor='w',wraplength=480).pack(side='left',fill='x',expand=True)
        self.auto=tk.BooleanVar(value=bool(self.settings.get('auto_update',True)))
        tk.Checkbutton(footer,text='Auto-install latest game',variable=self.auto,command=self.toggle_auto,bg=BG,fg=INK,selectcolor=PANEL,activebackground=BG,activeforeground=INK,font=('Helvetica Neue',11),highlightthickness=0).pack(side='right')

    def row_choice(self,parent,title,subtitle,click,selected=False):
        panel=tk.Frame(parent,bg=PANEL2 if selected else PANEL,highlightbackground=TEAL if selected else LINE,highlightthickness=1,cursor='hand2')
        panel.pack(fill='x',pady=(0,8))
        text=tk.Frame(panel,bg=panel.cget('bg'))
        text.pack(fill='x',padx=15,pady=12)
        self.label(text,title,12,bold=True).pack(anchor='w')
        self.label(text,subtitle,10,color=MUTED,wrap=420).pack(anchor='w',pady=(4,0))
        for node in (panel,text,*text.winfo_children()):node.bind('<Button-1>',lambda e:click())
        return panel

    def refresh_local(self):
        self.entries=core.registry_versions()
        self.versions=sorted(self.entries,key=core.version_key,reverse=True)
        if self.selected_version not in self.versions:
            self.selected_version=self.settings.get('preferred_version') if self.settings.get('preferred_version') in self.versions else (self.versions[0] if self.versions else None)
        for child in self.library.winfo_children():child.destroy()
        if not self.versions:
            self.label(self.library,'No games installed yet.',11,color=MUTED,wrap=180).pack(anchor='w',padx=10,pady=15)
            self.hero_version.set('No game installed')
            self.hero_detail.set('Import a compiled Mac game to begin playing.')
            self.primary_action.configure(text='＋  IMPORT A GAME')
        else:
            for v in self.versions[:7]:
                self.row_choice(self.library,'v'+v,'Installed • Mac game',lambda v=v:self.select_local(v),selected=v==self.selected_version)
            self.hero_version.set('Stray Shores  v'+self.selected_version)
            self.hero_detail.set('Ready to play · installed on this Mac')
            self.primary_action.configure(text='▶  PLAY GAME')

    def select_local(self,version):
        self.selected_version=version
        self.refresh_local()

    def choose_version(self):
        if not self.versions:
            messagebox.showinfo('No games installed','Import a compiled Stray Shores .app first.')
            return
        self.select_local(self.versions[(self.versions.index(self.selected_version)+1)%len(self.versions)])

    def primary_click(self):
        if self.selected_version:self.play()
        else:self.import_version()

    def play(self):
        version=self.selected_version
        if not version:return
        try:
            core.launch(version,self.entries[version])
            self.settings['preferred_version']=version
            core.write_json(core.SETTINGS,self.settings)
            self.status_text.set('Launched Stray Shores v'+version)
        except Exception as exc:messagebox.showerror('Cannot launch',str(exc))

    def import_version(self):
        src=filedialog.askopenfilename(title='Select compiled game ZIP',filetypes=[('Mac game ZIP','*.zip')])
        if not src:src=filedialog.askdirectory(title='Or select a compiled Stray Shores .app')
        if not src:return
        version=simpledialog.askstring('Import game','Game version (for example, 0.1.1)',parent=self)
        if not version:return
        try:
            version=version.lstrip('v')
            if not core.VERSION_RE.fullmatch(version):raise ValueError('Use a version like 0.1.1')
            if src.lower().endswith('.zip'):core.install_zip(version,src)
            else:core.register(version,src)
            self.select_local(version)
            self.status_text.set('Imported game v'+version)
        except Exception as exc:messagebox.showerror('Import failed',str(exc))

    def toggle_auto(self):
        self.settings['auto_update']=self.auto.get()
        core.write_json(core.SETTINGS,self.settings)

    def run_job(self,work,done):
        if self.busy:return
        self.busy=True
        def worker():
            try:self.jobs.put((done,work(),None))
            except Exception as exc:self.jobs.put((done,None,str(exc)))
        threading.Thread(target=worker,daemon=True).start()

    def poll(self):
        try:
            while True:
                done,result,error=self.jobs.get_nowait()
                self.busy=False
                done(result,error)
        except queue.Empty:pass
        self.after(110,self.poll)

    def check_updates(self):
        self.catalog_state.set('Checking releases…')
        self.run_job(lambda:core.fetch_catalog(self.settings),self.catalog_loaded)

    def catalog_loaded(self,releases,error):
        self.remote=releases or []
        for child in self.release_area.winfo_children():child.destroy()
        if error:
            self.label(self.release_area,'Could not reach game releases',14,bold=True).pack(anchor='w',pady=(25,9))
            self.label(self.release_area,'Check your connection and refresh. Installed games still work.',11,color=MUTED,wrap=450).pack(anchor='w')
            self.catalog_state.set('Offline or unavailable')
        elif not self.remote:
            self.label(self.release_area,'No published games yet',15,bold=True).pack(anchor='w',pady=(28,10))
            self.label(self.release_area,'Game v0.1.0 and v0.1.1 need compiled Mac releases on GitHub. You can import a game built on your Mac.',11,color=MUTED,wrap=480).pack(anchor='w')
            self.catalog_state.set('Waiting for GitHub game builds')
        else:
            self.catalog_state.set(str(len(self.remote))+' releases available')
            installed=core.registry_versions()
            self.selected_remote=self.remote[0]['version']
            for entry in self.remote[:5]:
                v=entry['version']
                subtitle='Installed' if v in installed else 'Ready to download'
                self.row_choice(self.release_area,'Stray Shores  v'+v,subtitle,lambda v=v:self.select_remote(v),selected=v==self.selected_remote)
            latest=self.remote[0]
            if self.auto.get() and latest['version'] not in installed and latest.get('sha256'):
                self.install_entry(latest)
        self.status_text.set('Ready' if not error else 'Could not refresh the online catalog')

    def select_remote(self,version):
        self.selected_remote=version
        for child in self.release_area.winfo_children():child.destroy()
        installed=core.registry_versions()
        for entry in self.remote[:5]:
            v=entry['version']
            self.row_choice(self.release_area,'Stray Shores  v'+v,'Installed' if v in installed else 'Ready to download',lambda v=v:self.select_remote(v),selected=v==version)

    def download_selected(self):
        entry=next((r for r in self.remote if r['version']==self.selected_remote),None)
        if not entry:
            messagebox.showinfo('No downloads','No compiled Mac game builds are published yet.')
            return
        if not entry.get('sha256'):
            messagebox.showinfo('Not ready','This release has no verified Mac download yet.')
            return
        self.install_entry(entry)

    def install_entry(self,entry):
        if entry['version'] in core.registry_versions():
            self.status_text.set('Game v'+entry['version']+' is already installed.')
            return
        self.status_text.set('Downloading and verifying v'+entry['version']+'…')
        def done(result,error):
            if error:
                self.status_text.set('Download failed; installed games were not modified.')
                messagebox.showerror('Download failed',error)
            else:
                self.refresh_local()
                self.status_text.set('Installed game v'+entry['version'])
                self.catalog_loaded(self.remote,None)
        self.run_job(lambda:core.install_release(entry),done)

if __name__=='__main__':
    Launcher().mainloop()
