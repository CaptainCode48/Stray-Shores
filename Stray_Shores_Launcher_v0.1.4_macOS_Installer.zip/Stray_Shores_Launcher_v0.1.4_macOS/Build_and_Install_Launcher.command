#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
PY=""
for CANDIDATE in /opt/homebrew/bin/python3 /usr/local/bin/python3 /Library/Frameworks/Python.framework/Versions/Current/bin/python3; do
  if [ -x "$CANDIDATE" ] && "$CANDIDATE" -c 'import tkinter' >/dev/null 2>&1; then PY="$CANDIDATE"; break; fi
done
if [ -z "$PY" ]; then
  echo "A Mac Python 3 installation with Tk is required to build the launcher."
  echo "Install Python 3 from python.org, then run this installer again."
  read -r -p "Press Return to close..." _
  exit 1
fi
"$PY" -m pip install --upgrade pyinstaller
"$PY" -m PyInstaller --noconfirm --clean --windowed --name 'Stray Shores Launcher' --osx-bundle-identifier com.strayshores.launcher Launcher_GUI.py
APP="$PWD/dist/Stray Shores Launcher.app"
# Ad-hoc signing identifies the locally built app, but is not Developer ID signing / notarization.
/usr/bin/codesign --force --deep --sign - "$APP" || true
mkdir -p "$HOME/Applications"
rm -rf "$HOME/Applications/Stray Shores Launcher.app"
/usr/bin/ditto "$APP" "$HOME/Applications/Stray Shores Launcher.app"
echo "Installed in ~/Applications/Stray Shores Launcher.app"
echo "You can open it from Finder > Go > Home > Applications, and drag it to the Dock."
echo "For system-wide Applications instead, drag the finished .app to /Applications."
/usr/bin/open "$HOME/Applications/Stray Shores Launcher.app" || true
read -r -p "Press Return to close..." _
