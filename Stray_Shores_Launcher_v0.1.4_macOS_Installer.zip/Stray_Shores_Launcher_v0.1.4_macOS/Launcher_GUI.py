#!/usr/bin/env python3
"""Stray Shores — clean Mac launcher. Requires Python with Tk if not bundled."""
import queue
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
import launcher_core as core

BG='#f5f7fa'
WHITE='#ffffff'
INK='#172536'
MUTED='#526275'
BORDER='#dbe3ea'
BLUE='#245dc2'
BLUE_ACTIVE='#174897'

class Launcher(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Stray Shores Launcher v0.1.4')
        self.geometry('1040x680')
        self.minsize(820,565)
        self.configure(bg=BG)
        self.settings=core.load_settings()
        self.remote=[]
        self.jobs=queue.Queue()
        self.busy=False
        self.entries={}
        self.versions=[]
        self.build_ui()
        self.refresh_local()
        self.after(150,self.poll)
        self.after(700,self.check_updates)

    def label(self,parent,text,size=12,bold=False,color=INK,bg=None):
        return tk.Label(parent,text=text,bg=bg or parent.cget('bg'),fg=color,
            font=('Helvetica Neue',size,'bold' if bold else 'normal'),anchor='w',justify='left')

    def button(self,parent,text,cmd,primary=False):
        # Explicit label colors solve the unreadable button issue in dark-mode Tk.
        return tk.Button(parent,text=text,command=cmd,relief='flat',bd=0,
            bg=BLUE if primary else WHITE,fg=WHITE if primary else INK,
            activebackground=BLUE_ACTIVE if primary else '#e9eef5',
            activeforeground=WHITE if primary else INK,
            highlightthickness=1,highlightbackground=BLUE if primary else BORDER,
            font=('Helvetica Neue',12,'bold'),padx=18,pady=12,cursor='hand2')

    def card(self,parent):
        frame=tk.Frame(parent,bg=WHITE,highlightthickness=1,highlightbackground=BORDER)
        return frame

    def build_ui(self):
        header=tk.Frame(self,bg=WHITE,height=94)
        header.pack(fill='x');header.pack_propagate(False)
        h=tk.Frame(header,bg=WHITE)
        h.pack(fill='both',expand=True,padx=32,pady=19)
        self.label(h,'STRAY SHORES',28,True,bg=WHITE).pack(side='left')
        self.label(h,'LAUNCHER  v0.1.4  ·  macOS',11,color=MUTED,bg=WHITE).pack(side='right',pady=12)

        hero=tk.Frame(self,bg=BG)
        hero.pack(fill='x',padx=32,pady=(25,15))
        self.label(hero,'Your island adventure',20,True,bg=BG).pack(anchor='w')
        self.label(hero,'Install a game version, then select it and play. Older versions stay available.',11,color=MUTED,bg=BG).pack(anchor='w',pady=(3,0))

        columns=tk.Frame(self,bg=BG)
        columns.pack(fill='both',expand=True,padx=32,pady=(0,16))
        left=self.card(columns);left.pack(side='left',fill='both',expand=True,padx=(0,9))
        right=self.card(columns);right.pack(side='left',fill='both',expand=True,padx=(9,0))
        self.label(left,'INSTALLED GAMES',13,True,bg=WHITE).pack(anchor='w',padx=22,pady=(23,8))
        self.label(left,'Choose what to play',11,color=MUTED,bg=WHITE).pack(anchor='w',padx=22)
        self.local=tk.Listbox(left,font=('Helvetica Neue',13),height=10,bd=0,highlightthickness=1,highlightbackground=BORDER,
           bg='#f9fbfd',fg=INK,selectbackground='#dce9ff',selectforeground=INK,activestyle='none',exportselection=False)
        self.local.pack(fill='both',expand=True,padx=22,pady=(15,15))
        self.play_button=self.button(left,'▶  Play selected game',self.play,primary=True)
        self.play_button.pack(fill='x',padx=22,pady=(0,8))
        self.button(left,'Import an existing Mac game',self.import_version).pack(fill='x',padx=22,pady=(0,21))

        row=tk.Frame(right,bg=WHITE);row.pack(fill='x',padx=22,pady=(23,0))
        self.label(row,'ONLINE GAME RELEASES',13,True,bg=WHITE).pack(side='left')
        self.refresh_button=self.button(row,'Refresh',self.check_updates)
        self.refresh_button.pack(side='right')
        self.label(right,'From the official public GitHub repository',11,color=MUTED,bg=WHITE).pack(anchor='w',padx=22,pady=(6,0))
        self.remote_list=tk.Listbox(right,font=('Helvetica Neue',13),height=10,bd=0,highlightthickness=1,highlightbackground=BORDER,
           bg='#f9fbfd',fg=INK,selectbackground='#dce9ff',selectforeground=INK,activestyle='none',exportselection=False)
        self.remote_list.pack(fill='both',expand=True,padx=22,pady=(15,14))
        self.remote_list.bind('<<ListboxSelect>>',lambda evt:self.update_release_description())
        self.description=tk.StringVar(value='Checking for published game downloads…')
        tk.Label(right,textvariable=self.description,bg=WHITE,fg=MUTED,font=('Helvetica Neue',11),wraplength=400,justify='left',anchor='w').pack(fill='x',padx=22)
        self.download_button=self.button(right,'↓  Download selected game',self.download_selected,primary=True)
        self.download_button.pack(fill='x',padx=22,pady=(14,21))

        footer=tk.Frame(self,bg=BG);footer.pack(fill='x',padx=32,pady=(0,22))
        self.status=tk.StringVar(value='Ready')
        tk.Label(footer,textvariable=self.status,bg=BG,fg=MUTED,font=('Helvetica Neue',11),anchor='w',justify='left',wraplength=680).pack(side='left',fill='x',expand=True)
        self.auto=tk.BooleanVar(value=bool(self.settings.get('auto_update',True)))
        tk.Checkbutton(footer,text='Download latest game automatically',variable=self.auto,command=self.toggle_auto,
            bg=BG,fg=INK,selectcolor=WHITE,activebackground=BG,activeforeground=INK,font=('Helvetica Neue',11),
            highlightthickness=0).pack(side='right')

    def refresh_local(self):
        selected=self.selected_installed()
        self.entries=core.registry_versions()
        self.versions=sorted(self.entries,key=core.version_key,reverse=True)
        self.local.delete(0,'end')
        if not self.versions:
            self.local.insert('end','No games installed yet')
        else:
            for v in self.versions:self.local.insert('end','Stray Shores  v'+v)
            version=selected if selected in self.versions else self.settings.get('preferred_version')
            idx=self.versions.index(version) if version in self.versions else 0
            self.local.selection_set(idx)
        self.play_button.configure(state='normal' if self.versions else 'disabled')

    def selected_installed(self):
        current=self.local.curselection()
        return self.versions[current[0]] if current and current[0]<len(self.versions) else None

    def play(self):
        version=self.selected_installed()
        if not version:
            messagebox.showinfo('Install a game first','Use a published release or import an existing Stray Shores .app.')
            return
        try:
            core.launch(version,self.entries[version])
            self.settings['preferred_version']=version
            core.write_json(core.SETTINGS,self.settings)
            self.status.set('Started Stray Shores v'+version)
        except Exception as exc:messagebox.showerror('Cannot launch',str(exc))

    def import_version(self):
        src=filedialog.askopenfilename(title='Select a compiled Mac game ZIP',filetypes=[('ZIP files','*.zip')])
        if not src:src=filedialog.askdirectory(title='Or select a Stray Shores .app folder')
        if not src:return
        version=simpledialog.askstring('Game version','Game version to register (example: 0.1.1):',parent=self)
        if not version:return
        try:
            version=version.lstrip('v')
            if not core.VERSION_RE.fullmatch(version):raise ValueError('Use a version like 0.1.1')
            if src.lower().endswith('.zip'):core.install_zip(version,src)
            else:core.register(version,src)
            self.refresh_local()
            self.status.set('Imported game v'+version)
        except Exception as exc:messagebox.showerror('Import failed',str(exc))

    def toggle_auto(self):
        self.settings['auto_update']=self.auto.get()
        core.write_json(core.SETTINGS,self.settings)

    def run_job(self,task,done):
        if self.busy:return
        self.busy=True
        self.refresh_button.configure(state='disabled')
        self.download_button.configure(state='disabled')
        def worker():
            try:self.jobs.put((done,task(),None))
            except Exception as exc:self.jobs.put((done,None,str(exc)))
        threading.Thread(target=worker,daemon=True).start()

    def poll(self):
        try:
            while True:
                done,result,error=self.jobs.get_nowait()
                self.busy=False
                self.refresh_button.configure(state='normal')
                self.download_button.configure(state='normal' if self.remote else 'disabled')
                done(result,error)
        except queue.Empty:pass
        self.after(100,self.poll)

    def check_updates(self):
        self.status.set('Checking GitHub for published game releases…')
        self.run_job(lambda:core.fetch_catalog(self.settings),self.catalog_loaded)

    def catalog_loaded(self,releases,error):
        self.remote=releases or []
        self.remote_list.delete(0,'end')
        if error:
            self.remote_list.insert('end','Could not check for updates')
            self.description.set('Check your internet connection and try again. Existing installed games still work.')
            self.status.set('Could not reach the game release catalog.')
        elif not self.remote:
            self.remote_list.insert('end','No published game builds yet')
            self.description.set('The GitHub repository exists, but its downloadable Mac game releases are not published yet.')
            self.status.set('No downloadable game builds published yet. You can import an existing game .app.')
        else:
            installed=core.registry_versions()
            for e in self.remote:
                note='  ·  Installed' if e['version'] in installed else ('  ·  Available' if e.get('sha256') else '  ·  Not ready')
                self.remote_list.insert('end','Stray Shores  v'+e['version']+note)
            self.remote_list.selection_set(0)
            self.update_release_description()
            self.status.set('Found '+str(len(self.remote))+' published game version(s).')
            latest=self.remote[0]
            if self.auto.get() and latest['version'] not in installed and latest.get('sha256'):
                self.install_entry(latest)
        self.download_button.configure(state='normal' if any(x.get('sha256') for x in self.remote) else 'disabled')

    def update_release_description(self):
        current=self.remote_list.curselection()
        if not current or current[0]>=len(self.remote):return
        entry=self.remote[current[0]]
        self.description.set(entry.get('notes') or 'Game v'+entry['version'])
        self.download_button.configure(state='normal' if entry.get('sha256') else 'disabled')

    def download_selected(self):
        current=self.remote_list.curselection()
        if not current or current[0]>=len(self.remote):return
        entry=self.remote[current[0]]
        if not entry.get('sha256'):
            messagebox.showinfo('Not published yet','This game version has no verified download available yet.')
            return
        self.install_entry(entry)

    def install_entry(self,entry):
        if entry['version'] in core.registry_versions():
            self.status.set('Game v'+entry['version']+' is already installed.')
            return
        self.status.set('Downloading and verifying game v'+entry['version']+'…')
        def done(result,error):
            if error:
                self.status.set('Download failed; installed games were not changed.')
                messagebox.showerror('Download failed',error)
            else:
                self.refresh_local()
                self.status.set('Installed game v'+entry['version'])
                self.catalog_loaded(self.remote,None)
        self.run_job(lambda:core.install_release(entry),done)

if __name__=='__main__':Launcher().mainloop()
