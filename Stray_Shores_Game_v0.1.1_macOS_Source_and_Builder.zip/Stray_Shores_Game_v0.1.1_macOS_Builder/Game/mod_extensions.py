"""Stray Shores mod framework v2.
Data packs are validated and interpreted; Python hooks run only if explicitly trusted.
Python mods are not sandboxed: never trust a mod from an unknown author.
"""
import json, hashlib, importlib.util, traceback
from pathlib import Path

VALID_TERRAIN={'grass','forest','sand','rock','path','water'}
MAX_FILE=1024*1024


def _str(v, limit=50):
    return isinstance(v,str) and 0<len(v)<=limit


def _nonneg(v, limit=9999):
    return type(v) is int and 0<=v<=limit


class ModManager:
    def __init__(self, base, slot, game_version=51):
        self.base=Path(base);self.slot=slot;self.game_version=game_version
        self.items={};self.recipes={};self.buildings={};self.enemies={};self.events=[];self.encounters=[]
        self.statuses=[];self.hooks=[];self.override_keys=set();self.mods=set()
        self.allowed=self._read_trust()
        self.active=[]

    def _read_trust(self):
        p=self.base/'mods'/f'slot_{self.slot}'/'trusted_python.json'
        try:
            val=json.loads(p.read_text(encoding='utf8'))
            return val.get('trusted_sha256',{}) if isinstance(val,dict) else {}
        except (ValueError,OSError):return {}

    def candidates(self):
        folders=(self.base/'mods',self.base/'mods'/f'slot_{self.slot}')
        for folder in folders:
            if folder.exists():
                for path in sorted(folder.iterdir()):
                    if path.is_file() and path.name!='trusted_python.json' and path.suffix.lower() in ('.json','.py','.zip','.dylib','.so','.dll','.exe'):
                        yield path,'Global' if folder==folders[0] else f'Slot {self.slot}'

    def record(self,path,scope,status,detail):
        self.statuses.append({'name':path.name,'scope':scope,'status':status,'features':detail[:150],'path':str(path)})

    def load(self):
        pending=[]
        for path,scope in self.candidates():
            if path.suffix.lower()=='.py':
                pending.append((path,scope));continue
            if path.suffix.lower()!='.json':
                self.record(path,scope,'BLOCKED','Executable archives and libraries are not supported; use reviewed Python .py hooks.');continue
            try:
                if path.stat().st_size>MAX_FILE:raise ValueError('File exceeds 1 MB')
                doc=json.loads(path.read_text(encoding='utf8'))
                if not isinstance(doc,dict):raise ValueError('Expected JSON object')
                extra=set(doc)&{'items','recipes','buildings','enemies','world_events','encounters'}
                if not extra:continue  # Existing fishing pack is handled by the legacy loader
                name=doc.get('name',path.stem)
                if not _str(name):raise ValueError('Invalid mod name')
                if 'mod_format' in doc and doc['mod_format']!=2:raise ValueError('Use mod_format 2')
                if doc.get('game_version_min',0)>self.game_version or doc.get('game_version_max',9999)<self.game_version:
                    self.record(path,scope,'INCOMPATIBLE','Game version mismatch');continue
                if doc.get('changes_save_format'):raise ValueError('Save-format replacement not allowed in data packs')
                if name in self.mods:raise ValueError('Duplicate mod ID')
                if not isinstance(doc.get('requires',[]),list) or not isinstance(doc.get('incompatible_with',[]),list):raise ValueError('Bad dependency list')
                if any(req not in self.mods for req in doc.get('requires',[])):
                    self.record(path,scope,'INCOMPATIBLE','Missing dependency (load alphabetically, global before slot mods)');continue
                if any(req in self.mods for req in doc.get('incompatible_with',[])):
                    self.record(path,scope,'CONFLICT','Incompatible with an active mod');continue
                allowed={'name','description','author','version','mod_format','game_version_min','game_version_max','requires','incompatible_with','items','recipes','buildings','enemies','world_events','encounters'}
                if set(doc)-allowed:raise ValueError('Unknown fields: '+', '.join(set(doc)-allowed))
                self._add_data(doc)
                self.mods.add(name);self.active.append(doc)
                self.record(path,scope,'ACTIVE','Items/recipes/structures/enemies/events')
            except (OSError,TypeError,KeyError,ValueError) as exc:
                self.record(path,scope,'INVALID',str(exc))
        for path,scope in pending:self._load_python(path,scope)

    def _add_data(self,doc):
        # Validate the full pack before committing, ensuring a failed pack cannot partially apply.
        items={};recipes={};buildings={};enemies={};events=[];encounters=[]
        for item in doc.get('items',[]):
            if not isinstance(item,dict) or not _str(item.get('id'),32) or not _str(item.get('label'),50):raise ValueError('Invalid item')
            name=item['id']
            if name in self.items or name in items:raise ValueError('Duplicate item '+name)
            if not name.replace('_','').isalnum():raise ValueError('Item IDs must be alphanumeric/underscore')
            items[name]={'label':item['label']}
        for entry in doc.get('recipes',[]):
            if not isinstance(entry,dict) or not _str(entry.get('id'),45) or not _str(entry.get('output'),32):raise ValueError('Invalid recipe')
            req=entry.get('requires',{});qty=entry.get('quantity',1)
            if not isinstance(req,dict) or not req or len(req)>12 or any(not _str(k,32) or not _nonneg(v,999) or v==0 for k,v in req.items()) or not _nonneg(qty,99) or qty==0:raise ValueError('Invalid recipe materials')
            name=entry['id']
            if name in recipes or name in self.recipes:raise ValueError('Duplicate recipe')
            recipes[name]={'output':entry['output'],'quantity':qty,'requires':req,'era':entry.get('era',0)}
        for entry in doc.get('buildings',[]):
            if not isinstance(entry,dict) or not _str(entry.get('id'),45) or not isinstance(entry.get('cost',{}),dict):raise ValueError('Invalid building')
            if any(not _str(k,32) or not _nonneg(v,999) for k,v in entry['cost'].items()):raise ValueError('Invalid building materials')
            name=entry['id']
            if name in self.buildings or name in buildings:raise ValueError('Duplicate building')
            buildings[name]={'cost':entry['cost'],'era':entry.get('era',0),'color':entry.get('color',[110,155,200])}
            if not _nonneg(buildings[name]['era'],6) or not isinstance(buildings[name]['color'],list) or len(buildings[name]['color'])!=3 or any(not _nonneg(v,255) for v in buildings[name]['color']):raise ValueError('Invalid building era/color')
        for entry in doc.get('enemies',[]):
            if not isinstance(entry,dict) or not _str(entry.get('id'),32):raise ValueError('Invalid enemy')
            if entry['id'] in self.enemies or entry['id'] in enemies:raise ValueError('Duplicate enemy')
            hp=entry.get('hp',60);weight=entry.get('weight',1)
            if not _nonneg(hp,1000) or not 1<=hp or not _nonneg(weight,100) or weight<1:raise ValueError('Invalid enemy hp/weight')
            enemies[entry['id']]={'hp':hp,'weight':weight}
        for entry in doc.get('world_events',[]):
            if not isinstance(entry,dict) or not _str(entry.get('message'),150):raise ValueError('Invalid world event')
            item=entry.get('item');qty=entry.get('quantity',0);chance=entry.get('chance',0.001)
            if item is not None and not _str(item,32):raise ValueError('Invalid event item')
            if not _nonneg(qty,20) or type(chance) not in (float,int) or not 0<=chance<=.05:raise ValueError('Invalid event amount/chance')
            events.append({'message':entry['message'],'item':item,'quantity':qty,'chance':chance})
        # Data-only interactive encounters: no arbitrary expressions or scripting.
        # Choices have unpredictable consequences, not simply item rewards.
        for entry in doc.get('encounters',[]):
            if not isinstance(entry,dict) or not _str(entry.get('id'),32) or not _str(entry.get('label'),42):raise ValueError('Invalid encounter')
            if entry['id'] in {e['id'] for e in self.encounters+encounters}:raise ValueError('Duplicate encounter')
            pos=entry.get('position')
            if not isinstance(pos,list) or len(pos)!=2 or any(not _nonneg(v,479) for v in pos):raise ValueError('Encounter position must be two map coordinates')
            choices=entry.get('choices',[])
            if not isinstance(choices,list) or not 2<=len(choices)<=4:raise ValueError('Encounter requires 2-4 choices')
            clean=[]
            for ch in choices:
                if not isinstance(ch,dict) or not _str(ch.get('text'),65) or not _str(ch.get('message'),130):raise ValueError('Invalid choice')
                outcome=ch.get('effect','message')
                if outcome not in ('message','damage','exhaust','teleport','break_weapon','lose_coins','storm'):raise ValueError('Unsupported encounter effect')
                strength=ch.get('strength',10)
                if not _nonneg(strength,100):raise ValueError('Invalid encounter strength')
                clean.append({'text':ch['text'],'message':ch['message'],'effect':outcome,'strength':strength})
            encounters.append({'id':entry['id'],'label':entry['label'],'position':pos,'choices':clean,'cooldown':max(15,min(600,entry.get('cooldown',90)))})
        self.items.update(items);self.recipes.update(recipes);self.buildings.update(buildings);self.enemies.update(enemies);self.events.extend(events);self.encounters.extend(encounters)

    def _load_python(self,path,scope):
        # Never import code just to determine whether it is trusted.
        if scope=='Global':
            self.record(path,scope,'BLOCKED','Python plugins must be save-specific, never global');return
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        if self.allowed.get(path.name)!=digest:
            self.record(path,scope,'TRUST REQUIRED','Review source, then add filename and SHA256 to trusted_python.json');return
        try:
            spec=importlib.util.spec_from_file_location('stray_mod_'+digest[:16],path)
            module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
            self.hooks.append(module)
            self.record(path,scope,'ACTIVE','Trusted Python plugin (full permissions; not sandboxed)')
        except Exception as exc:
            self.record(path,scope,'CRASH',repr(exc))

    def dispatch(self,event,api,**info):
        for plugin in list(self.hooks):
            handler=getattr(plugin,event,None)
            if callable(handler):
                try:handler(api,**info)
                except Exception as exc:
                    self.hooks.remove(plugin)
                    self.statuses.append({'name':plugin.__name__,'scope':f'Slot {self.slot}','status':'CRASH','features':repr(exc),'path':''})
                    log=self.base/'mod_errors.log'
                    with log.open('a',encoding='utf8') as f:f.write(traceback.format_exc()+'\n')
