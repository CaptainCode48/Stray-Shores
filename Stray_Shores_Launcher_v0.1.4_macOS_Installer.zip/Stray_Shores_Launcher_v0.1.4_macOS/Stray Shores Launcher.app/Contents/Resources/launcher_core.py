#!/usr/bin/env python3
"""Stray Shores Launcher — versioned installs, optional verified online release catalog.

Release manifest schema (HTTPS URL, configured by the player):
{"releases": [{"version":"0.1.1", "url":"https://example.com/StrayShores.zip",
               "sha256":"64 lower-case hex chars", "notes":"..."}]}
The zip must contain exactly one Stray Shores .app bundle (top-level or nested).
"""
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

LAUNCHER_VERSION='0.1.4'
PUBLIC_REPO='CaptainCode48/Stray-Shores'
DEFAULT_CATALOG=f'https://github.com/{PUBLIC_REPO}/releases/download/launcher-catalog/releases.json'

BASE=Path.home()/'Library'/'Application Support'/'Stray Shores'
REGISTRY=BASE/'version_registry.json'
SETTINGS=BASE/'launcher_settings.json'
VERSIONS=BASE/'installed_versions'
VERSION_RE=re.compile(r'[A-Za-z0-9][A-Za-z0-9._-]{0,31}\Z')
SHA_RE=re.compile(r'[a-fA-F0-9]{64}\Z')
MAX_DOWNLOAD=1_500_000_000
MAX_EXTRACT=2_500_000_000


def read_json(path,default):
 try:
  result=json.loads(path.read_text());return result if isinstance(result,type(default)) else default
 except (OSError,ValueError):return default


def write_json(path, data):
 path.parent.mkdir(parents=True,exist_ok=True)
 tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(data,indent=2));tmp.replace(path)


def load_registry():
 return read_json(REGISTRY,{})


def load_settings():
 return read_json(SETTINGS,{'catalog_url':DEFAULT_CATALOG,'github_repository':PUBLIC_REPO,'preferred_version':'','auto_update':True})


def version_key(v):
 match=re.fullmatch(r'v?(\d+)\.(\d+)\.(\d+)',v)
 if match:return (1,*(int(x) for x in match.groups()))
 return (0,v)


def registry_versions():
 return {k:v for k,v in load_registry().items() if VERSION_RE.fullmatch(k) and Path(v).is_dir()}


def validate_app(app):
 app=Path(app).expanduser().resolve()
 if app.suffix!='.app' or not (app/'Contents'/'MacOS').is_dir():
  raise ValueError('Select a valid macOS .app bundle')
 if not any(p.is_file() for p in (app/'Contents'/'MacOS').iterdir()):
  raise ValueError('This app has no executable')
 return app


def register(version,app):
 if not VERSION_RE.fullmatch(version):raise ValueError('Invalid version label')
 app=validate_app(app)
 dest=VERSIONS/version/'Stray Shores.app'
 dest.parent.mkdir(parents=True,exist_ok=True)
 if app!=dest:
  if dest.exists():raise FileExistsError('Version already installed; it will not be overwritten')
  shutil.copytree(app,dest,symlinks=True)
 else:
  validate_app(dest)
 data=load_registry();data[version]=str(dest);write_json(REGISTRY,data)
 return dest


def message(body):
 subprocess.run(['osascript','-e','display dialog '+json.dumps(str(body))+' buttons {"OK"} default button "OK"'],check=False)


def choose(prompt,options):
 if not options:return None
 script='choose from list '+json.dumps(options)+' with prompt '+json.dumps(prompt)+' without multiple selections allowed'
 p=subprocess.run(['osascript','-e',script],capture_output=True,text=True)
 if p.returncode or p.stdout.strip()=='false':return None
 return p.stdout.strip()


def ask(prompt, default=''):
 cmd='text returned of (display dialog '+json.dumps(prompt)+' default answer '+json.dumps(default)+')'
 p=subprocess.run(['osascript','-e',cmd],capture_output=True,text=True)
 return p.stdout.strip() if p.returncode==0 else None


def choose_path():
 script='POSIX path of (choose file with prompt "Choose a Stray Shores release ZIP or .app bundle")'
 p=subprocess.run(['osascript','-e',script],capture_output=True,text=True)
 return p.stdout.strip() if p.returncode==0 else None


def download(url,destination):
 parsed=urllib.parse.urlparse(url)
 if parsed.scheme!='https' or not parsed.netloc or parsed.username or parsed.password:
  raise ValueError('Release catalog and archives must use trusted HTTPS URLs')
 req=urllib.request.Request(url,headers={'User-Agent':'StrayShoresLauncher/'+LAUNCHER_VERSION})
 with urllib.request.urlopen(req,timeout=20) as stream, open(destination,'wb') as f:
  length=0
  if urllib.parse.urlparse(stream.geturl()).scheme!='https':
   raise ValueError('Insecure redirect rejected')
  while True:
   chunk=stream.read(1024*512)
   if not chunk:break
   length+=len(chunk)
   if length>MAX_DOWNLOAD:raise ValueError('Download too large')
   f.write(chunk)
 return destination


def discover_public_game_releases(repo='CaptainCode48/Stray-Shores'):
 """Discover published game versions from GitHub Releases if the catalog is missing.
 Returns [] when releases are not yet published, rather than propagating a 404.
 """
 if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+',repo):
  raise ValueError('Invalid GitHub repository')
 request=urllib.request.Request('https://api.github.com/repos/'+repo+'/releases?per_page=100', headers={'User-Agent':'StrayShoresLauncher/0.1.4','Accept':'application/vnd.github+json'})
 try:
  with urllib.request.urlopen(request,timeout=15) as response:
   releases=json.load(response)
 except urllib.error.HTTPError as exc:
  if exc.code==404:return []
  raise
 result=[]
 for release in releases:
  tag=release.get('tag_name','')
  if not tag.startswith('game-v') or release.get('draft') or release.get('prerelease'):continue
  v=tag[6:]
  if not VERSION_RE.fullmatch(v):continue
  assets={a.get('name',''):a for a in release.get('assets',[])}
  expected=f'Stray_Shores_{v}_macOS26_arm64.app.zip'
  asset=assets.get(expected)
  if not asset:continue
  # Github API discovery is metadata only: require checksum in published
  # machine-readable catalog, so unknown downloads cannot bypass validation.
  result.append({'version':v,'sha256':'','url':'','notes':release.get('name',tag)+' — checksum catalog pending; download disabled'})
 return sorted(result,key=lambda e:version_key(e['version']),reverse=True)


def fetch_catalog(settings):
 url=settings.get('catalog_url','')
 if not url:return discover_public_game_releases(settings.get('github_repository','CaptainCode48/Stray-Shores'))
 with tempfile.TemporaryDirectory(prefix='sh-catalog-') as td:
  target=Path(td)/'catalog.json'
  try:download(url,target)
  except urllib.error.HTTPError as exc:
   if exc.code==404:return discover_public_game_releases(settings.get('github_repository','CaptainCode48/Stray-Shores'))
   raise
  if target.stat().st_size>2_000_000:raise ValueError('Catalog too large')
  catalog=read_json(target,{})
 result=[]
 for entry in catalog.get('releases',[]):
  if not isinstance(entry,dict):continue
  ver=entry.get('version','');sha=entry.get('sha256','');url=entry.get('url','')
  if not isinstance(ver,str) or not VERSION_RE.fullmatch(ver):continue
  if not isinstance(sha,str) or not SHA_RE.fullmatch(sha):continue
  parsed=urllib.parse.urlparse(str(url))
  if parsed.scheme!='https' or not parsed.netloc:continue
  result.append({'version':ver,'sha256':sha.lower(),'url':url,'notes':str(entry.get('notes',''))[:500]})
 return sorted(result,key=lambda e:version_key(e['version']),reverse=True)


def safe_extract(z, to):
 total=0
 for info in z.infolist():
  name=info.filename.replace('\\','/')
  parts=Path(name).parts
  if (name.startswith('/') or '..' in parts or not parts or '\x00' in name
      or len(parts)>32 or info.file_size>MAX_EXTRACT):
   raise ValueError('Unsafe ZIP entry rejected')
  unixmode=(info.external_attr >> 16) & 0o170000
  if unixmode==0o120000:raise ValueError('ZIP symlink entry rejected')
  total+=info.file_size
  if total>MAX_EXTRACT:raise ValueError('Expanded ZIP exceeds size limit')
  target=to.joinpath(*parts)
  if info.is_dir():target.mkdir(parents=True,exist_ok=True);continue
  target.parent.mkdir(parents=True,exist_ok=True)
  with z.open(info) as inp, open(target,'wb') as output:
   shutil.copyfileobj(inp,output)
  if info.external_attr >> 16 & 0o111: target.chmod(target.stat().st_mode | 0o755)


def install_zip(version, archive, expected_sha=None):
 archive=Path(archive)
 if expected_sha:
  h=hashlib.sha256()
  with archive.open('rb') as f:
   for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
  if h.hexdigest()!=expected_sha:raise ValueError('SHA-256 mismatch: release archive rejected')
 if version in registry_versions():return Path(registry_versions()[version])
 with tempfile.TemporaryDirectory(prefix='sh-release-') as td:
  target=Path(td)
  with zipfile.ZipFile(archive) as z:safe_extract(z,target)
  apps=[p for p in target.rglob('*.app') if p.is_dir() and p.parent.suffix!='.app']
  if len(apps)!=1:raise ValueError('Archive must contain exactly one .app bundle')
  return register(version,apps[0])


def update_available(releases):
 entries=registry_versions()
 return next((e for e in releases if e['version'] not in entries),None) if releases else None


def install_release(entry):
 if entry['version'] in registry_versions():return
 with tempfile.TemporaryDirectory(prefix='sh-download-') as td:
  archive=Path(td)/'release.zip';download(entry['url'],archive)
  install_zip(entry['version'],archive,entry['sha256'])


def launch(version,path):
 app=validate_app(path)
 env=os.environ.copy();env['STRAY_SHORES_DATA_DIR']=str(BASE/'versions'/version)
 candidate=app/'Contents'/'MacOS'/app.stem
 if not candidate.is_file():candidate=next(p for p in (app/'Contents'/'MacOS').iterdir() if p.is_file())
 subprocess.Popen([str(candidate)],env=env,cwd=str(app.parent),start_new_session=True,
                  stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)


def main():
 args=sys.argv[1:]
 if len(args)==3 and args[0]=='--register':print(register(args[1],args[2]));return
 if len(args)==2 and args[0]=='--launch':launch(args[1],registry_versions()[args[1]]);return
 if args==['--list']:
  for ver in sorted(registry_versions(),key=version_key,reverse=True):print(ver)
  return
 settings=load_settings()
 releases=[];error=''
 if settings.get('catalog_url'):
  try:
   releases=fetch_catalog(settings)
   newest=releases[0] if releases else None
   if newest and settings.get('auto_update',True) and newest['version'] not in registry_versions():
    # Installing a remotely published version requires a verified SHA256 archive.
    install_release(newest)
  except Exception as exc:error=str(exc)
 while True:
  entries=registry_versions()
  newest=next(iter(sorted(entries,key=version_key,reverse=True)),None)
  preferred=settings.get('preferred_version','')
  selected=preferred if preferred in entries else newest
  actions=[]
  if selected: actions.append('PLAY NOW — '+selected)
  actions+=['Versions — choose installed','Browse available releases','Import older release ZIP / .app',
            'Set GitHub repository','Set release catalog URL','Automatic updates: '+('ON' if settings.get('auto_update',True) else 'OFF'),
            'Use newest version by default','Quit']
  picked=choose('Stray Shores Launcher'+(' (update check failed: '+error[:100]+')' if error else ''),actions)
  if not picked or picked=='Quit':return
  try:
   if picked.startswith('PLAY NOW'):
    launch(selected,entries[selected]);return
   if picked=='Versions — choose installed':
    options=['PLAY '+v for v in sorted(entries,key=version_key,reverse=True)]
    selection=choose('Stray Shores Launcher v'+LAUNCHER_VERSION+' — Installed GAME versions',options)
    if selection:
     v=selection[5:];launch(v,entries[v]);settings['preferred_version']=v;write_json(SETTINGS,settings);return
   elif picked=='Browse available releases':
    if not releases and not settings.get('catalog_url'):message('Configure an HTTPS release catalog first. No official download server is bundled.')
    else:
     releases=fetch_catalog(settings)
     choices=[e['version']+(' (installed)' if e['version'] in entries else ' (download)') for e in releases]
     choice=choose('Available published versions',choices)
     if choice:
      e=next(x for x in releases if choice.startswith(x['version']+' ('))
      install_release(e);message('Installed '+e['version']+'. Select it from Versions to play.')
   elif picked=='Import older release ZIP / .app':
    path=choose_path()
    if path:
     version=ask('Version label (e.g. v81 or 0.1.0):','legacy')
     if version:
      if not VERSION_RE.fullmatch(version):raise ValueError('Invalid version label')
      if path.endswith('.zip'):install_zip(version,path)
      else:register(version,path)
   elif picked=='Set GitHub repository':
    repo=ask('GitHub repository (owner/repo), for example YOURNAME/stray-shores:',settings.get('github_repository',''))
    if repo is not None:
     if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,99}/[A-Za-z0-9][A-Za-z0-9_.-]{0,99}',repo):
      raise ValueError('Use an existing GitHub repository in the form owner/repo')
     settings['github_repository']=repo
     settings['catalog_url']='https://github.com/'+repo+'/releases/download/launcher-catalog/releases.json'
     write_json(SETTINGS,settings)
     error=''
     try:releases=fetch_catalog(settings)
     except Exception as exc:error=str(exc);releases=[]
   elif picked=='Set release catalog URL':
    url=ask('HTTPS URL of a trusted JSON release catalog (blank disables online updates):',settings.get('catalog_url',''))
    if url is not None:
     if url and (urllib.parse.urlparse(url).scheme!='https' or not urllib.parse.urlparse(url).netloc):
      raise ValueError('A full HTTPS URL is required')
     settings['catalog_url']=url;write_json(SETTINGS,settings)
     error='';releases=fetch_catalog(settings) if url else []
   elif picked.startswith('Automatic updates:'):
    settings['auto_update']=not settings.get('auto_update',True);write_json(SETTINGS,settings)
   elif picked=='Use newest version by default':
    settings['preferred_version']='';write_json(SETTINGS,settings)
  except Exception as exc:message('Operation failed: '+str(exc))

if __name__=='__main__':main()
