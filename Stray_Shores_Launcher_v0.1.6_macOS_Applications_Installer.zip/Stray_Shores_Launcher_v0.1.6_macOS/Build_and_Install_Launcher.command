#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

printf '\nStray Shores Launcher v0.1.6 — macOS installer\n'
printf 'Destination: /Applications/Stray Shores Launcher.app\n\n'

# The downloaded installer is a builder: it needs an existing Python 3 with Tk.
PY=""
for CANDIDATE in /Library/Frameworks/Python.framework/Versions/Current/bin/python3 /opt/homebrew/bin/python3 /usr/local/bin/python3; do
  if [ -x "$CANDIDATE" ] && "$CANDIDATE" -c 'import tkinter' >/dev/null 2>&1; then
    PY="$CANDIDATE";break
  fi
done
if [ -z "$PY" ]; then
  echo "ERROR: macOS Python 3 with Tkinter was not found."
  echo "Install Python 3 for macOS from https://www.python.org/downloads/macos/ and run again."
  read -r -p "Press Return to close..." _ || true
  exit 1
fi

printf 'Using Python: %s\n' "$PY"
"$PY" -m pip install --upgrade pyinstaller
"$PY" -m PyInstaller --noconfirm --clean --windowed --name 'Stray Shores Launcher' \
  --osx-bundle-identifier com.strayshores.launcher Launcher_GUI.py
APP="$PWD/dist/Stray Shores Launcher.app"
if [ ! -f "$APP/Contents/Info.plist" ] || [ ! -d "$APP/Contents/MacOS" ];then
  echo "ERROR: the standalone application was not built."
  read -r -p "Press Return to close..." _ || true
  exit 1
fi

# Ad-hoc signing is not Apple Developer ID signing or notarization.
/usr/bin/codesign --force --deep --sign - "$APP"
TARGET='/Applications/Stray Shores Launcher.app'

if [ -w /Applications ]; then
  /bin/rm -rf "$TARGET"
  /usr/bin/ditto "$APP" "$TARGET"
else
  printf '\nmacOS will request administrator permission to install in /Applications.\n'
  /usr/bin/osascript - "$APP" <<'APPLESCRIPT'
on run argv
    set sourceApp to item 1 of argv
    set targetApp to "/Applications/Stray Shores Launcher.app"
    set cmd to "/bin/rm -rf " & quoted form of targetApp & " && /usr/bin/ditto " & quoted form of sourceApp & " " & quoted form of targetApp
    do shell script cmd with administrator privileges
end run
APPLESCRIPT
fi

if [ ! -f "$TARGET/Contents/Info.plist" ] || [ ! -d "$TARGET/Contents/MacOS" ];then
  echo "ERROR: installation was not verified in /Applications."
  read -r -p "Press Return to close..." _ || true
  exit 1
fi

printf '\nSUCCESS — Installed in:\n%s\n\n' "$TARGET"
printf 'Finder will reveal the installed app.\n'
/usr/bin/open -R "$TARGET"
echo 'On first run, macOS may block an app without Apple notarization.'
echo 'If you trust this locally built app, use System Settings > Privacy & Security > Open Anyway.'
read -r -p "Press Return to close..." _ || true
