#!/bin/bash
set -Eeuo pipefail
cd "$(dirname "$0")"
ROOT="$PWD"
SRC="$ROOT/build-output/Stray Shores.app"
VER="0.1.0"
HOMEBASE="$HOME/Library/Application Support/Stray Shores"
DST="$HOMEBASE/installed_versions/$VER/Stray Shores.app"
if [[ ! -d "$SRC" ]]; then echo 'Build first using Build_Standalone_ARM64_on_Mac.command';exit 1;fi
plutil -lint "$SRC/Contents/Info.plist"
codesign --verify --deep --strict "$SRC"
"$SRC/Contents/MacOS/Stray Shores" --self-test
mkdir -p "$(dirname "$DST")" "$HOME/Applications"
if [[ -e "$DST" ]]; then
 BACK="$HOMEBASE/installed_versions/$VER/backup-$(date +%Y%m%d_%H%M%S).app"
 ditto "$DST" "$BACK"
 rm -rf "$DST"
fi
ditto "$SRC" "$DST"
if [[ -x /opt/homebrew/bin/python3 ]]; then PY=/opt/homebrew/bin/python3; else PY="$(command -v python3)";fi
"$PY" "$ROOT/Version_Launcher.py" --register "$VER" "$DST"
cp "$ROOT/Version_Launcher.py" "$HOMEBASE/Version_Launcher.py"
cat > "$HOME/Applications/Stray Shores Launcher.command" <<EOF
#!/bin/bash
if [[ -x /opt/homebrew/bin/python3 ]]; then PY=/opt/homebrew/bin/python3; else PY=\$(command -v python3); fi
exec "\$PY" "\$HOME/Library/Application Support/Stray Shores/Version_Launcher.py"
EOF
chmod +x "$HOME/Applications/Stray Shores Launcher.command"
echo "Installed version $VER at $DST"
echo 'Open ~/Applications/Stray Shores Launcher.command to select the game version.'
open "$HOME/Applications"
read -r -p 'Press Return to close...' _ || true
