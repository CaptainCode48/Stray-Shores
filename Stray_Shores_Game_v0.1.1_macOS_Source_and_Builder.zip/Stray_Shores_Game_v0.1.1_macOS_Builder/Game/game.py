import pygame, random, math, json, os, time, sys, hashlib, datetime
from mod_extensions import ModManager
from pathlib import Path
pygame.init()
# Declarative JSON mod packs are loaded locally; no arbitrary code execution.

W,H=1120,720
screen=pygame.display.set_mode((W,H)); pygame.display.set_caption('Stray Shores v0.1.1')
clock=pygame.time.Clock(); font=pygame.font.SysFont('arial',18); small=pygame.font.SysFont('arial',15); big=pygame.font.SysFont('arial',28,bold=True)
T=40; N=480; OLD_N=240
DATA_DIR=Path(os.environ.get('STRAY_SHORES_DATA_DIR') or ((Path.home()/'Library'/'Application Support'/'Stray Shores'/'versions'/'0.1.1') if sys.platform=='darwin' else Path(__file__).parent/'version_data'/'0.1.1'))
DATA_DIR.mkdir(parents=True,exist_ok=True)
# One-time non-destructive migration. Older root saves/mods remain untouched.
if not (DATA_DIR/'.legacy_import_checked').exists():
 try:
  import shutil as _ss_shutil
  legacy=Path.home()/'Library'/'Application Support'/'Stray Shores'
  if legacy!=DATA_DIR:
   for folder in ('saves','mods','backups','mod_signatures'):
    source=legacy/folder;target=DATA_DIR/folder
    if source.is_dir():_ss_shutil.copytree(source,target,dirs_exist_ok=True)
   for name in ('minigame_rewards.json','prize_claims.jsonl','settings.json'):
    source=legacy/name;target=DATA_DIR/name
    if source.is_file() and not target.exists():_ss_shutil.copy2(source,target)
  (DATA_DIR/'.legacy_import_checked').write_text('Legacy data copied without modifying originals.\n')
 except OSError:pass

SAVE_DIR=DATA_DIR/'saves'; SAVE_DIR.mkdir(exist_ok=True)
SAVE=SAVE_DIR/'slot_1.json'
HOUSING=['Homeless','Tent','Shack','Cabin','Cottage','House']
SEASONS=['Spring','Summer','Autumn','Winter']
ERAS=['Ancient','Medieval','Renaissance','Industrial','Modern','Digital','Rift Age']
# Every party shares one timeline. Milestones require research points, materials and coins.
ERA_COSTS=[(60,18,10,0,0,100),(130,32,20,2,0,450),(260,48,30,6,0,1300),(440,65,48,12,1,3500),(700,85,55,18,2,6800),(1050,110,75,26,5,14000)]
era=0;knowledge=0;research_remainder=0
# Era, wood, stone, scrap, ore, gems, coins, research points, cycle seconds, output item, output amount
PROJECTS=[
 ('Clay Kiln',0,10,8,0,0,0,110,20,55,'stone',2),
 ('Iron Forge',1,18,12,4,2,0,380,55,65,'ore',1),
 ('Printing Press',2,28,16,7,2,0,900,90,75,'knowledge',12),
 ('Steam Sawmill',3,38,24,10,6,0,2200,145,55,'wood',5),
 ('Greenhouse',4,42,26,12,7,1,3800,210,60,'food',4),
 ('Solar Station',5,54,32,18,10,2,7200,330,65,'scrap',3),
 ('Rift Condenser',6,70,45,23,15,4,14000,480,90,'gems',1)
]
workshops={};workshop_clock=0


def era_name():return ERAS[era]
def tech_gate(required):
 if era<required:
  msg('Technology locked! Reach '+ERAS[required]+' at the Research Hall.');return False
 return True

# Keep custom mods writable outside the app bundle (which may be read-only).
MOD_EXAMPLES=Path(__file__).with_name('mods')
MOD_DIR=DATA_DIR/'mods'
MOD_DIR.mkdir(parents=True,exist_ok=True)
# Copy the included example mod only on first launch, without overwriting user edits.
example_mod=Path(__file__).with_name('mods')/'example_fishing.json'
if example_mod.is_file() and not (MOD_DIR/'example_fishing.json').exists():
 try:
  import shutil
  shutil.copyfile(example_mod, MOD_DIR/'example_fishing.json')
 except OSError:pass
MOD_DEFAULT={'fish':{'minnow':{'weight':55,'value':8},'bass':{'weight':30,'value':22},'golden carp':{'weight':5,'value':130}},'jokes':['The fish filed a restraining order.'],'fish_cooldown':8,'fish_bucket_capacity':12}
MOD_LIST=[]  # Exact status of mods examined during the save's startup.
MOD_WARNINGS=[]
SUPPORTED_MOD_KEYS={'fish','jokes','fish_cooldown','fish_bucket_capacity'}
MOD_METADATA_KEYS={'name','description','author','version','mod_format','game_version_min','game_version_max','requires','incompatible_with','changes_save_format'}
# Versioned, data-only mod format; unknown gameplay keys or code are never run.
MOD_FORMAT=1

def validate_mod(data):
 if not isinstance(data,dict):return 'INVALID','JSON root must be an object',[]
 if data.get('changes_save_format') is True or data.get('overhaul') is True or data.get('replace_game') is True:
  return 'UNSAFE','Game-overhaul/save-format changes are not supported',[]
 if data.get('mod_format',1)!=MOD_FORMAT:
  return 'INCOMPATIBLE','Unsupported mod_format; expected 1',[]
 try:
  lo=int(data.get('game_version_min',0)); hi=int(data.get('game_version_max',10**6))
 except (TypeError,ValueError):return 'INCOMPATIBLE','Invalid game-version compatibility range',[]
 if not lo<=50<=hi:return 'INCOMPATIBLE',f'Requires game version {lo} through {hi}',[]
 if data.get('requires') or data.get('incompatible_with'):
  return 'INCOMPATIBLE','Mod dependencies/conflicts are not supported yet',[]
 unsupported=set(data)-SUPPORTED_MOD_KEYS-MOD_METADATA_KEYS
 if unsupported:return 'UNSUPPORTED','Unsupported fields: '+', '.join(sorted(unsupported))[:75],[]
 found=sorted(set(data)&SUPPORTED_MOD_KEYS)
 if not found:return 'UNSUPPORTED','No supported gameplay settings',[]
 if 'fish' in data:
  fish=data['fish']
  if not isinstance(fish,dict) or len(fish)>150:return 'INVALID','fish must be an object (max 150 types)',[]
  for name,entry in fish.items():
   if not isinstance(name,str) or len(name)>39 or not name or not isinstance(entry,dict) or set(entry)!={'weight','value'}:
    return 'INVALID','Fish need names and exact weight/value fields',[]
   weight,value=entry['weight'],entry['value']
   if type(weight) not in (int,float) or type(value) not in (int,float) or not (0<weight<=1000 and 0<=value<=100000):
    return 'INVALID','Fish weight or value outside supported range',[]
 if 'jokes' in data and (not isinstance(data['jokes'],list) or len(data['jokes'])>100 or any(not isinstance(x,str) or len(x)>130 for x in data['jokes'])):
  return 'INVALID','jokes must be a list of up to 100 short strings',[]
 if 'fish_cooldown' in data and (type(data['fish_cooldown']) not in (int,float) or not 1<=data['fish_cooldown']<=300):
  return 'INVALID','fish_cooldown must be between 1 and 300',[]
 if 'fish_bucket_capacity' in data and (type(data['fish_bucket_capacity']) is not int or not 1<=data['fish_bucket_capacity']<=100):
  return 'INVALID','fish_bucket_capacity must be an integer 1-100',[]
 return 'ACTIVE','Valid data-only mod',found

def read_mod_file(path):
 if path.stat().st_size>1024*1024:raise ValueError('File exceeds 1 MB limit')
 return json.loads(path.read_text(encoding='utf8'))

def load_mods():
 MOD_LIST.clear();MOD_WARNINGS.clear()
 cfg=json.loads(json.dumps(MOD_DEFAULT))
 MOD_DIR.mkdir(parents=True,exist_ok=True)
 example=MOD_EXAMPLES/'example_fishing.json'
 destination=MOD_DIR/'example_fishing.json'
 if not destination.exists() and example.is_file():
  import shutil
  shutil.copy2(example,destination)
 used_scalars={};used_fish={}
 candidates=sorted(list(MOD_DIR.glob('*.json')))+sorted(list((MOD_DIR/f'slot_{slot}').glob('*.json')))
 for folder in (MOD_DIR,MOD_DIR/f'slot_{slot}'):
  if folder.is_dir():
   for unknown in sorted(folder.iterdir()):
    if unknown.is_file() and unknown.suffix.lower() in ('.zip','.dylib','.so','.dll','.exe','.pak','.mod'):
     scope='Global' if folder==MOD_DIR else f'Slot {slot}'
     MOD_LIST.append({'name':unknown.name,'scope':scope,'status':'UNSAFE','features':'Binary executable mods blocked; use trusted Python plugins','path':str(unknown)})
     MOD_WARNINGS.append(f'{unknown.name}: UNSAFE - ignored')
 for path in candidates:
  scope='Global' if path.parent==MOD_DIR else f'Slot {slot}'
  try:
   data=read_mod_file(path)
   if data.get('mod_format')==2 or any(k in data for k in ('items','recipes','buildings','enemies','world_events')):continue
   status,detail,found=validate_mod(data)
   if status=='ACTIVE':
    collision=[]
    for key in ('fish_cooldown','fish_bucket_capacity'):
     if key in found and key in used_scalars:collision.append(key+' already set by '+used_scalars[key])
    for fish_name in data.get('fish',{}):
     if fish_name in used_fish:collision.append(fish_name+' already set by '+used_fish[fish_name])
    if collision:status='CONFLICT';detail='; '.join(collision)[:95]
   MOD_LIST.append({'name':path.name,'scope':scope,'status':status,'features':detail if status!='ACTIVE' else ', '.join(found),'path':str(path)})
   if status!='ACTIVE':
    MOD_WARNINGS.append(f'{path.name}: {status} - {detail}')
    continue
   if 'fish' in data:
    for name,entry in data['fish'].items():
     cfg['fish'][name]={'weight':entry['weight'],'value':int(entry['value'])}
     used_fish[name]=path.name
   if 'jokes' in data:cfg['jokes']+=data['jokes']
   if 'fish_cooldown' in data:cfg['fish_cooldown']=data['fish_cooldown'];used_scalars['fish_cooldown']=path.name
   if 'fish_bucket_capacity' in data:cfg['fish_bucket_capacity']=data['fish_bucket_capacity'];used_scalars['fish_bucket_capacity']=path.name
  except (OSError,ValueError,TypeError,UnicodeError) as exc:
   MOD_LIST.append({'name':path.name,'scope':scope,'status':'INVALID','features':str(exc)[:95],'path':str(path)})
   MOD_WARNINGS.append(f'{path.name}: INVALID - {str(exc)[:95]}')
 print('Mods checked:',[(m['name'],m['status']) for m in MOD_LIST])
 return cfg

def backup_before_mod_change():
 # Backup if the effective mod configuration has changed since the prior launch.
 # Backups remain outside the .app and are never loaded automatically.
 fingerprint=[]
 for item in MOD_LIST:
  source=Path(item['path'])
  try:sha=hashlib.sha256(source.read_bytes()).hexdigest()
  except OSError:sha='unreadable'
  fingerprint.append((item['scope'],item['name'],item['status'],sha))
 signature=hashlib.sha256(json.dumps(fingerprint,sort_keys=True).encode()).hexdigest()
 signatures=DATA_DIR/'mod_signatures';signatures.mkdir(parents=True,exist_ok=True)
 marker=signatures/f'slot_{slot}.txt'
 old=marker.read_text().strip() if marker.exists() else ''
 if SAVE.is_file() and old!=signature:
  backups=DATA_DIR/'backups'/f'slot_{slot}'
  backups.mkdir(parents=True,exist_ok=True)
  stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
  target=backups/f'slot_{slot}_before_mod_change_{stamp}.json'
  import shutil
  shutil.copy2(SAVE,target)
  MOD_WARNINGS.append('Save backup created before loading changed mods: '+target.name)
 marker.write_text(signature,encoding='utf8')
MOD=None  # Loaded after save slot selection, including slot-specific mods
# Local presentation preferences are separate from world save slots.
SETTINGS_PATH=DATA_DIR/'settings.json'
DEFAULT_SETTINGS={'show_fps':False,'show_minimap':True,'enemy_ai':'Normal','controller_deadzone':0.22,'screen_shake':True,'ui_scale':1,'volume':50}
try:
 SETTINGS={**DEFAULT_SETTINGS,**json.loads(SETTINGS_PATH.read_text())}
except (OSError,ValueError,TypeError):SETTINGS=DEFAULT_SETTINGS.copy()
def save_settings():SETTINGS_PATH.write_text(json.dumps(SETTINGS,indent=2))
PAUSE_OPTIONS=['Resume game','Show FPS','Show minimap','Enemy AI','Controller deadzone','Screen shake','UI scale','Sound volume','Mods for this save','Save world','Quit to desktop']
paused=False;pause_index=0;pause_held=False;pause_page='main';mod_index=0;last_pause_axis=0

def adjust_setting(index,delta=1):
 if index==1:SETTINGS['show_fps']=not SETTINGS['show_fps']
 elif index==2:SETTINGS['show_minimap']=not SETTINGS['show_minimap']
 elif index==3:
  levels=['Relaxed','Normal','Aggressive'];SETTINGS['enemy_ai']=levels[(levels.index(SETTINGS.get('enemy_ai','Normal'))+delta)%len(levels)]
 elif index==4:SETTINGS['controller_deadzone']=round(min(.5,max(.1,SETTINGS['controller_deadzone']+delta*.04)),2)
 elif index==5:SETTINGS['screen_shake']=not SETTINGS['screen_shake']
 elif index==6:SETTINGS['ui_scale']=max(1,min(2,SETTINGS['ui_scale']+delta))
 elif index==7:SETTINGS['volume']=max(0,min(100,SETTINGS['volume']+10*delta))
 save_settings()



COL={'grass':(74,149,77),'sand':(216,191,124),'water':(57,133,180),'forest':(35,103,60),'rock':(107,110,112),'path':(170,148,100)}
# Precomputed decorative terrain tiles. Nothing external to install or download.
# Different tiles use stable coordinates so the terrain does not flicker.
TILE_CACHE={}
def terrain_tile(kind,variant,season_name):
 key=(kind,variant,season_name)
 if key in TILE_CACHE:return TILE_CACHE[key]
 colors={'grass':(76,156,91),'sand':(220,190,129),'water':(50,133,175),'forest':(53,130,73),'rock':(111,117,126),'path':(158,132,96)}
 c=colors[kind]
 if season_name=='Winter' and kind!='water':c=(211,223,230) if kind in ('grass','forest','sand') else (161,172,184)
 elif season_name=='Autumn' and kind in ('grass','forest'):c=(143,137,78) if kind=='grass' else (130,104,63)
 tile_surf=pygame.Surface((T,T));tile_surf.fill(c)
 rng=random.Random(variant*347+len(kind)*4321)
 for j in range(14):
  a,b=rng.randrange(3,T-3),rng.randrange(4,T-4)
  tint=tuple(max(0,min(255,v+(11 if j%2 else -12))) for v in c)
  pygame.draw.circle(tile_surf,tint,(a,b),rng.choice((1,1,2,2,3)))
 if kind in ('grass','forest'):
  for j in range(4):
   a,b=rng.randrange(4,36),rng.randrange(4,36)
   pygame.draw.line(tile_surf,(53,116,70) if season_name!='Winter' else (194,206,215),(a,b),(a+2,b-4),1)
  if variant%13==0 and season_name!='Winter':
   pygame.draw.circle(tile_surf,(245,200,100),(32,9),3);pygame.draw.circle(tile_surf,(247,234,222),(32,9),1)
 elif kind=='sand':
  for j in range(4):pygame.draw.circle(tile_surf,(238,212,153),(rng.randrange(40),rng.randrange(40)),2)
 elif kind=='water':
  for j in range(4):
   a,b=rng.randrange(5,31),rng.randrange(5,36)
   pygame.draw.arc(tile_surf,(85,163,191),(a,b,13,6),.1,2.7,1)
 elif kind=='path':
  pygame.draw.line(tile_surf,(182,153,112),(5,8),(29,10),1)
 TILE_CACHE[key]=tile_surf
 return tile_surf

def draw_environment_details(sx,sy,x,y,kind,variant,season_name,anim):
 """Small deterministic props rendered over terrain; no image assets needed."""
 r=(x*92821+y*68917+variant*17)&255
 if kind=='grass' and season_name!='Winter':
  if r%13==0:
   for k in range(3):
    xx=sx+7+k*9; yy=sy+17+(r%11)
    pygame.draw.line(screen,(28,103,55),(xx,yy+5),(xx,yy-2),2)
    pygame.draw.circle(screen,((252,212,113) if k%2 else (227,144,199)),(xx,yy-3),3)
  elif r%19==0:
   pygame.draw.ellipse(screen,(61,126,57),(sx+7,sy+24,24,11))
   pygame.draw.ellipse(screen,(86,164,67),(sx+9,sy+20,20,12))
 elif kind=='sand':
  if r%9==0:
   pygame.draw.arc(screen,(240,229,177),(sx+9,sy+9,20,12),.3,2.6,2)
   pygame.draw.circle(screen,(170,131,91),(sx+28,sy+30),2)
 elif kind=='water':
  if r%4==0:
   shift=int(math.sin(anim*2.8+x*.6+y*.4)*4)
   pygame.draw.arc(screen,(121,215,232),(sx+8+shift,sy+13,18,8),.1,2.8,2)
   pygame.draw.line(screen,(83,172,205),(sx+10,sy+28),(sx+24,sy+28),1)
 elif kind=='rock' and r%5==0:
  pygame.draw.line(screen,(65,69,78),(sx+7,sy+29),(sx+16,sy+22),2)
  pygame.draw.line(screen,(65,69,78),(sx+16,sy+22),(sx+23,sy+26),2)

def draw_tree(sx,sy,variant,season_name):
 pygame.draw.ellipse(screen,(23,52,44),(sx+7,sy+26,31,10))
 pygame.draw.rect(screen,(91,72,48),(sx+18,sy+21,6,15))
 leaf=(39,105,70) if season_name in ('Spring','Summer') else (173,106,52) if season_name=='Autumn' else (77,115,107)
 pygame.draw.circle(screen,(26,77,57) if season_name!='Winter' else (57,86,83),(sx+20,sy+17),16)
 pygame.draw.circle(screen,leaf,(sx+13,sy+13),11)
 pygame.draw.circle(screen,tuple(min(255,n+19) for n in leaf),(sx+25,sy+11),11)
 pygame.draw.circle(screen,tuple(min(255,n+30) for n in leaf),(sx+18,sy+7),9)
 if variant%4==0 and season_name!='Winter':pygame.draw.circle(screen,(227,74,73),(sx+29,sy+14),2)

def draw_rock(sx,sy):
 pygame.draw.ellipse(screen,(65,76,81),(sx+7,sy+28,30,8))
 pygame.draw.polygon(screen,(91,101,109),[(sx+6,sy+29),(sx+16,sy+8),(sx+29,sy+12),(sx+36,sy+28)])
 pygame.draw.polygon(screen,(156,163,166),[(sx+16,sy+8),(sx+29,sy+12),(sx+23,sy+23),(sx+10,sy+24)])
 pygame.draw.line(screen,(186,191,187),(sx+16,sy+9),(sx+23,sy+14),2)

def draw_avatar(sx,sy,color,number,moving,anim):
 pygame.draw.ellipse(screen,(24,43,42),(sx-12,sy+12,26,10))
 swing=3 if moving and int(anim*9)%2 else -2 if moving else 0
 pygame.draw.line(screen,(42,55,68),(sx-5,sy+6),(sx-6+swing,sy+17),5)
 pygame.draw.line(screen,(42,55,68),(sx+5,sy+6),(sx+5-swing,sy+17),5)
 pygame.draw.rect(screen,color,(sx-11,sy-13,22,23),border_radius=6)
 pygame.draw.circle(screen,(240,198,157),(sx,sy-17),11)
 pygame.draw.arc(screen,(27,37,48),(sx-11,sy-28,22,13),.1,3,4)
 pygame.draw.circle(screen,(31,39,43),(sx-4,sy-18),2)
 pygame.draw.circle(screen,(31,39,43),(sx+4,sy-18),2)
 pygame.draw.rect(screen,(24,37,43),(sx+8,sy-5,9,13),border_radius=3)
 pygame.draw.rect(screen,(65,50,40),(sx-14,sy-9,6,18),border_radius=2)
 pygame.draw.line(screen,(255,242,207),(sx-5,sy-28),(sx+4,sy-29),2)
 pygame.draw.line(screen,(25,34,41),(sx-3,sy-12),(sx+7,sy-12),2)
 screen.blit(small.render(str(number),True,(255,255,255)),(sx-4,sy-10))

# Four connected-by-ocean exploration regions. The original 240x240 starter
# island is reconstructed at its EXACT original coordinates for save migration.
# Additional islands are separated by water: the existing raft/boat system matters.
random.seed(17)
terrain=[]
REGIONS=[('Starter Island',120,120,105,101),('Amber Wilds',352,108,91,93),('Frostwood Reach',347,351,103,100),('Sunken Keys',115,360,89,94)]
for y in range(N):
 row=[]
 for x in range(N):
  if x<OLD_N and y<OLD_N:
   angle=math.atan2(y-OLD_N/2,x-OLD_N/2)
   d=math.hypot(x-OLD_N/2,y-OLD_N/2)
   coast=105+7*math.sin(angle*7)+5*math.sin(angle*13+1.2)
   noise=(math.sin(x*.19+y*.07)+math.sin(y*.16-x*.11))*.5
   if d>coast:t='water'
   elif d>coast-6:t='sand'
   elif math.sin(x*.095)*math.cos(y*.085)+noise*.45>0.43:t='forest'
   elif math.sin(x*.21+y*.14)>1.08:t='rock'
   else:t='grass'
   if 14<d<90 and (math.sin(x*.075)+math.cos(y*.082)>1.88):t='water'
   if abs(x-120)<5 and abs(y-120)<5:t='path'
  else:
   t='water'
   for idx,(_,cx,cy,rx,ry) in enumerate(REGIONS[1:],start=1):
    ax=(x-cx)/rx;ay=(y-cy)/ry
    angle=math.atan2(ay,ax)
    edge=1+0.05*math.sin(angle*7+idx)+0.04*math.cos(angle*13-idx)
    dist=math.hypot(ax,ay)
    if dist<edge:
     noise=math.sin(x*.13+idx)*math.cos(y*.11-idx)
     t='sand' if dist>edge-.08 else ('rock' if noise>.70 else 'forest' if noise<-.12 else 'grass')
     if idx==2 and t=='grass':t='forest'
     if idx==3 and noise>.48:t='sand'
     break
  row.append(t)
 terrain.append(row)
random.seed()
places=[('BANK',117,117,(70,110,190)),('SHOP',122,117,(220,133,65)),('FARM',117,123,(148,103,52)),('BUILDER',123,123,(145,99,169)),('PRESTIGE',120,115,(205,170,65)),('ARENA',127,121,(180,70,80)),('CAMP',114,121,(105,87,65)),('TRADER',125,115,(90,160,155)),('ARCADE',120,126,(180,85,160)),('DOCK',111,125,(58,150,184)),('HOUSING',119,129,(173,111,84)),('EXPEDITION',127,127,(74,151,125)),('GEAR',124,130,(94,122,180)),('RESEARCH',130,116,(88,116,156)),('INVENTOR',134,123,(88,153,165)),('CONTRACTS',130,130,(184,117,68)),('FORGE',135,118,(198,94,51)),('EXPANSION',111,129,(97,172,187)),('EXCHANGE',138,125,(68,194,177)),('CASINO',138,129,(192,91,153)),('BUSINESS',132,135,(183,150,85)),('VILLAGE',136,139,(103,174,118)),('ARMY',141,137,(153,107,108)),('COUNCIL',135,143,(177,145,105)),('PUBLIC WORKS',131,142,(86,160,173))]
# v0.1.1 regional markets are intentionally walkable, persistent outposts.
# All are inside their respective landmass and become accessible after purchase.
ISLAND_MARKETS={
 'Amber Wilds':(350,108,'Amber Bazaar','timber','ore'),
 'Frostwood Reach':(347,350,'Frost Exchange','ore','food'),
 'Sunken Keys':(116,359,'Tide Market','fish','gems'),
}
ISLAND_FANTASY={
 'Amber Wilds':(361,116,'GROVE SPIRIT'),
 'Frostwood Reach':(355,360,'FROST WARDEN'),
 'Sunken Keys':(122,366,'TIDE ORACLE'),
}
for region, (xx,yy,title,*_) in ISLAND_MARKETS.items():
 places.append((title,xx,yy,(181,133,72)))
for region,(xx,yy,title) in ISLAND_FANTASY.items():
 places.append((title,xx,yy,(126,86,171)))

# A fledgling village does not start with an enormous commercial district.
STARTER_SHOPS={'CAMP','SHOP','FARM','BUILDER','VILLAGE','RESEARCH'}
EARLY_SHOPS={'DOCK','HOUSING','TRADER','FORGE','EXPANSION','COUNCIL'}
MIDDLE_SHOPS={'BANK','PRESTIGE','ARENA','GEAR','CONTRACTS','ARMY','PUBLIC WORKS','BUSINESS'}
LATE_SHOPS={'ARCADE','EXCHANGE','CASINO','INVENTOR'}
def shop_available(name):
 for region,(_,_,title,*_) in ISLAND_MARKETS.items():
  if name==title:return list(ISLAND_MARKETS).index(region)+1 in unlocked_regions
 for region,(_,_,title) in ISLAND_FANTASY.items():
  if name==title:return list(ISLAND_FANTASY).index(region)+1 in unlocked_regions
 if name in STARTER_SHOPS:return True
 if name in EARLY_SHOPS:return era>=1 or housing_capacity()>0 or built_count('farmstead')>0
 if name=='BANK':return any(str(part).startswith(('built:bank:', 'bank')) for _,_,part in structures) if 'structures' in globals() else False
 if name in MIDDLE_SHOPS:return era>=2 or (housing_capacity()>=3 and staff_count('farmer')>=1)
 if name in LATE_SHOPS:return era>=3
 return True

for _,x,y,_ in places:
 for yy in range(y-1,y+2):
  for xx in range(x-1,x+2): terrain[yy][xx]='grass'
# Fixed points of interest scattered across the world, discovered by exploration.
# Fewer easy reward markers. Navigation and trading now drive expeditions.
landmarks=[(90,95,'RELIC'),(160,160,'CHEST'),(376,75,'CHEST'),(364,309,'RELIC'),(146,374,'RELIC'),(402,382,'CHEST')]
supply_caches=[(83,104),(355,164)]
# Discoverable oddities are interactive world mechanics, not free treasure.
ODDITIES=[('SINKHOLE',293,350),('GIANT FOOTPRINT',170,63),('CROOKED SIGN',74,371),('CRACKED GEYSER',371,78),('MAGNETIC FIELD',326,163),('MUD PIT',386,324),('GLASS BEACH',148,394),('LOST ELEVATOR',314,375),('GLOWING CRATER',89,351)]

# Strange choice-driven sites: interaction makes the world less predictable.
BUILTIN_ENCOUNTERS=[
 {'id':'lever','label':'DO NOT PULL','position':[100,135],'cooldown':90,'choices':[
  {'text':'Pull the red lever','effect':'teleport','strength':8,'message':'The ground flips. You are somewhere else now.'},
  {'text':'Kick the control box','effect':'damage','strength':18,'message':'The lever kicks back. Unfair engineering.'},
  {'text':'Back away slowly','effect':'message','strength':0,'message':'You survive a terrible decision by not making it.'}]},
 {'id':'talking_stone','label':'ARGUING BOULDER','position':[150,102],'cooldown':65,'choices':[
  {'text':'Argue with the rock','effect':'exhaust','strength':24,'message':'The boulder wins the argument. You are exhausted.'},
  {'text':'Offer it legal advice','effect':'lose_coins','strength':90,'message':'The rock bills you for its time.'},
  {'text':'Ask for directions','effect':'teleport','strength':5,'message':'Its directions were suspiciously literal.'}]},
 {'id':'abandoned_controls','label':'UNLABELED MACHINE','position':[162,142],'cooldown':120,'choices':[
  {'text':'Push every button','effect':'storm','strength':0,'message':'You have accidentally scheduled terrible weather.'},
  {'text':'Hit it with your weapon','effect':'break_weapon','strength':30,'message':'Your weapon loses the argument with machinery.'},
  {'text':'Unplug the machine','effect':'message','strength':0,'message':'There is no plug. It appears offended.'}]},
 {'id':'hollow_log','label':'HOLLOW LOG','position':[85,145],'cooldown':50,'choices':[
  {'text':'Crawl inside','effect':'teleport','strength':6,'message':'There is far too much tunnel inside this log.'},
  {'text':'Yell HELLO','effect':'damage','strength':12,'message':'Something yells back directly into your ear.'},
  {'text':'Leave the log alone','effect':'message','strength':0,'message':'The log files a complaint about your lack of curiosity.'}]}
]

# Traveling dealers are separate from the village's legitimate trader.
shady_dealers=[('SNEAKY SAL',178,145),('MYSTERY MO',346,131),('DODGY DEE',365,343),('CAPTAIN SKETCH',108,383)]
WILDLIFE=[(92,110,'deer'),(168,134,'deer'),(151,167,'boar'),(352,116,'fox'),(380,160,'deer'),(354,357,'boar'),(391,338,'fox'),(112,367,'turtle'),(148,383,'fox'),(95,340,'turtle')]
CONTRACT_TYPES=[('Timber Delivery','wood',14,340),('Mason Order','stone',12,330),('Scrap Salvage','scrap',8,420),('Emergency Rations','food',5,300),('Smelter Supply','ore',4,460),('Seed Shipment','seed',8,270)]
REGION_MAPS=[('Starter Island',120,120,95,90),('Amber Wilds',355,130,60,125),('Frostwood Reach',361,365,64,170),('Sunken Keys',125,372,62,140)]
# Region permits are shared across the whole save; water stays navigable but
# landing, building and teleporting onto locked land is disallowed.
EXPANSION_COSTS=[('Amber Wilds',1800,8,4),('Frostwood Reach',4800,18,10),('Sunken Keys',9800,28,18)]
unlocked_regions=[0]
def land_region(x,y):
 if not (0<=x<world_limit and 0<=y<world_limit) or terrain[int(y)][int(x)]=='water':return -1
 for index,(_,cx,cy,rx,ry) in enumerate(REGIONS[1:],1):
  ax=(x-cx)/rx;ay=(y-cy)/ry
  if (x>=OLD_N or y>=OLD_N) and math.hypot(ax,ay)<1.18:return index
 return 0
def land_available(x,y):
 rid=land_region(x,y)
 return rid<0 or rid in unlocked_regions
def expansion_options():
 result=[]
 for index,(name,cost,wood,stone) in enumerate(EXPANSION_COSTS,1):
  state='OWNED' if index in unlocked_regions else 'NEXT' if index==max(unlocked_regions)+1 else 'LOCKED: buy preceding island'
  result.append(f'{name}: {cost}c + {wood} wood + {stone} stone [{state}]')
 return result


# Equipment is owned by the shared party stockpile until picked up and equipped.
EQUIPMENT={
 'Leather Armour':('armour',1,0.12,'Ancient'),
 'Chainmail':('armour',2,0.25,'Medieval'),
 'Plate Armour':('armour',3,0.36,'Renaissance'),
 'Rope Belt':('belt',0,0,'Ancient'),
 'Sword Belt':('belt',0,0,'Medieval'),
 'Tactical Belt':('belt',0,0,'Modern'),
 'Ring of Embers':('ring',0,0,'Medieval'),
 'Ring of Tides':('ring',0,0,'Renaissance'),
 'Ring of Echoes':('ring',0,0,'Digital'),
}
GEAR_NAMES=list(EQUIPMENT)
GEAR_PRICES=[(200,2,0),(600,4,1),(1700,7,3),(150,2,0),(450,3,1),(1200,6,2),(500,3,1),(800,4,2),(2100,8,4)]
GEAR_ERA=[0,1,2,0,1,4,1,2,5]
# Secret blueprints: hide, ingot, flux, crystal dust, volatile mineral, complexity.
# "Volatile mineral" is a fictional game resource, not a real-world recipe.
FORGE_RECIPES={
 'Leather Armour':(3,0,1,0,0,1),
 'Chainmail':(1,5,2,0,0,2),
 'Plate Armour':(1,9,3,0,0,3),
 'Rope Belt':(1,0,1,0,0,1),
 'Sword Belt':(2,2,2,0,0,2),
 'Tactical Belt':(2,5,3,0,0,3),
 'Ring of Embers':(0,2,2,1,1,3),
 'Ring of Tides':(0,3,2,2,0,3),
 'Ring of Echoes':(0,5,4,3,0,4),
 'Sword':(0,4,1,0,0,2),
 'Bow':(2,2,1,0,0,2),
 'Rifle':(0,8,4,1,0,4),
 'Pickaxe':(0,5,1,0,0,2),
 'Axe':(1,4,1,0,0,2),
 'Compass':(0,3,2,1,0,3),
 'Spark Drill':(0,7,3,1,2,5),
}
FORGE_ERA={name:GEAR_ERA[j] for j,name in enumerate(GEAR_NAMES)}
FORGE_ERA.update({'Sword':1,'Bow':1,'Rifle':3,'Pickaxe':1,'Axe':1,'Compass':2,'Spark Drill':5})
FORGE_NAMES=list(FORGE_RECIPES)
FORGE_MATERIALS=['hide','ingot','flux','crystal_dust','volatile_mineral']
forge_built=False
forge_condition=100
forge_skill=0
forge_attempts=0
forge_discovered=[]
forge_timing=None
FORGE_MAX=12

def forge_options(p):
 target=p.get('forge_target',0)%len(FORGE_NAMES)
 name=FORGE_NAMES[target];known=name in forge_discovered
 guess=(list(p.get('forge_guess',[]))+[0]*5)[:5]
 rows=[f'Build forge (22 stone, 12 wood, 5 scrap, 800c): {"BUILT" if forge_built else "NOT BUILT"}',
       f'Repair forge (3 ingots, 2 flux, 260c): {forge_condition}/100',
       f'Blacksmith practice: {forge_skill} | trials: {forge_attempts}',
       f'Blueprint: {name} [{ERAS[FORGE_ERA[name]]}] {"DISCOVERED" if known else "UNKNOWN"}',
       'Previous blueprint','Next blueprint']
 rows += [f'{material.replace("_"," ")}: carried {p.get(material,0)} | shared {shared_items.get(material,0)}' for material in FORGE_MATERIALS]
 for j,material in enumerate(FORGE_MATERIALS):
  rows.extend((f'{material.replace("_"," ")}: {guess[j]}  (+1)',f'{material.replace("_"," ")}: {guess[j]}  (-1)'))
 rows += ['FORGE / TEST EXPERIMENT - consume ingredients','Inspect recipe journal']
 if known:rows[3]+=' | '+', '.join(f'{k} {n}' for k,n in zip(FORGE_MATERIALS,FORGE_RECIPES[name][:5]) if n)
 return rows

def forge_action(p,k,i):
 global forge_built,forge_condition,forge_skill,forge_attempts,forge_timing
 if k==0:
  if forge_built:msg('Your forge already exists.')
  elif p['wallet']>=800 and all(p.get(key,0)>=n for key,n in [('stone',22),('wood',12),('scrap',5)]):
   p['wallet']-=800;p['stone']-=22;p['wood']-=12;p['scrap']-=5;forge_built=True;msg('Forge built. Discover recipes and master multiple strikes.')
  else:msg('Requires 22 stone, 12 wood, 5 scrap and 800 coins.')
 elif k==1:
  if not forge_built:msg('Build the forge first.')
  elif forge_condition>=100:msg('Forge is already fully repaired.')
  elif p.get('ingot',0)>=3 and p.get('flux',0)>=2 and p['wallet']>=260:
   p['ingot']-=3;p['flux']-=2;p['wallet']-=260;forge_condition=min(100,forge_condition+55);msg('Repaired the forge.')
  else:msg('Repair: 3 ingots, 2 flux and 260 coins.')
 elif k==2:msg(f'Practice: {forge_skill}. Difficult recipes demand more accurately timed strikes.')
 elif k in (4,5):
  p['forge_target']=(p.get('forge_target',0)+(1 if k==5 else -1))%len(FORGE_NAMES)
  p['forge_guess']=[0]*5;msg('Selected '+FORGE_NAMES[p['forge_target']]+'.')
 elif 6<=k<=10:
  material=FORGE_MATERIALS[k-6]
  msg(material.replace('_',' ').title()+' must be gathered; the forge does not sell ingredients.')
 elif 11<=k<=20:
  j=(k-11)//2;delta=1 if (k-11)%2==0 else -1
  guess=(list(p.get('forge_guess',[]))+[0]*5)[:5]
  guess[j]=max(0,min(FORGE_MAX,guess[j]+delta));p['forge_guess']=guess
 elif k==22:
  name=FORGE_NAMES[p.get('forge_target',0)%len(FORGE_NAMES)]
  if name in forge_discovered:msg(name+': '+', '.join(f'{key}={n}' for key,n in zip(FORGE_MATERIALS,FORGE_RECIPES[name][:5])))
  else:msg(f'{name}: unknown. Experiment with five ingredient amounts (0-{FORGE_MAX}); failures reveal partial clues.')
 elif k==21:
  if forge_timing:msg('Finish the current forging sequence first.');return
  if not forge_built:msg('Build the forge first.');return
  if forge_condition<=0:msg('Forge broken. Repair it first.');return
  name=FORGE_NAMES[p.get('forge_target',0)%len(FORGE_NAMES)]
  if era<FORGE_ERA[name]:msg('Unlocked in '+ERAS[FORGE_ERA[name]]+'.');return
  correct=list(FORGE_RECIPES[name][:5]);guess=(list(p.get('forge_guess',[]))+[0]*5)[:5]
  if name in forge_discovered:guess=correct.copy();p['forge_guess']=guess.copy()
  if not any(guess):msg('The forge needs an experimental mixture.');return
  if any(p.get(material,0)<n for material,n in zip(FORGE_MATERIALS,guess)):
   msg('Missing ingredients. Hunt, mine, or withdraw them from shared storage.');return
  for material,n in zip(FORGE_MATERIALS,guess):p[material]-=n
  forge_attempts+=1;p['forge_attempts_personal']=p.get('forge_attempts_personal',0)+1
  if p['forge_attempts_personal']>=10:unlock_achievement(p,'craftsperson')
  forge_skill=min(30,forge_skill+1)
  forge_condition=max(0,forge_condition-random.randint(2,5))
  if guess!=correct:
   types=sum((v>0)==(n>0) for v,n in zip(guess,correct))
   exact=sum(v==n for v,n in zip(guess,correct))
   # Unstable mineral in a mismatched mixture may trigger a fantasy furnace blast.
   if guess[4]>0 and (guess[4]!=correct[4]) and random.random()<min(.70,.20+.08*guess[4]):
    forge_failure('explosion',p,name,guess)
   elif random.random()<.32:
    forge_failure('partial',p,name,guess)
   else:forge_failure('total',p,name,guess)
   msg(f'Clues: {types}/5 ingredient types, {exact}/5 quantities correct.')
  else:
   if name not in forge_discovered:forge_discovered.append(name);msg('Exact '+name+' recipe discovered!')
   complexity=FORGE_RECIPES[name][5]
   stages=min(6,2+complexity)
   forge_timing={'player':i,'name':name,'pos':0.,'speed':.76+complexity*.12,
                 'target':random.uniform(.28,.73),'width':max(.055,.20-complexity*.025+forge_skill*.002),
                 'stage':1,'stages':stages,'volatile':correct[4],
                 'spent':dict(zip(FORGE_MATERIALS,guess))}
   msg(f'{name}: {stages} timed strikes required. Press E/Enter/controller A in each green zone!')
  if forge_condition==0:msg('The forge broke down. Repair it before another attempt.')

def forge_failure(kind,p,name,spent):
 global forge_condition
 if kind=='partial':
  # Recover a small fraction of the spent materials, with no free resource creation.
  returned=[]
  for material,amount in zip(FORGE_MATERIALS,spent):
   n=amount//2
   if n:p[material]=p.get(material,0)+n;returned.append(f'{n} {material}')
  forge_condition=max(0,forge_condition-3)
  msg('PARTIAL FAILURE: '+name+' ruined; salvaged '+(', '.join(returned) if returned else 'nothing')+'.')
 elif kind=='explosion':
  forge_condition=max(0,forge_condition-random.randint(25,45))
  fx,fy=135*T,118*T
  affected=0
  for player in players:
   if math.hypot(player['x']-fx,player['y']-fy)<8*T:
    player['hp']=max(1,player['hp']-random.randint(8,24));unlock_achievement(player,'blast');affected+=1
  msg(f'BOOM! Unstable minerals blasted the forge (-condition) and hit {affected} nearby players. Batch lost!')
 else:
  forge_condition=max(0,forge_condition-6)
  msg('TOTAL FAILURE: '+name+' destroyed. No materials recoverable.')

def forge_strike():
 global forge_timing,forge_condition
 if not forge_timing:return
 timing=forge_timing
 distance=abs(timing['pos']-timing['target'])
 if distance<=timing['width']/2:
  if timing['stage']<timing['stages']:
   timing['stage']+=1;timing['pos']=0
   timing['target']=random.uniform(.28,.73)
   timing['speed']+=.09
   timing['width']=max(.045,timing['width']-.012)
   msg(f'Good strike! {timing["stage"]-1}/{timing["stages"]} completed. Keep going!')
  else:
   name=timing['name'];owner=timing['player'];forge_timing=None
   if name in gear_stock:gear_stock[name]+=1;msg(name+' completed! Added to the shared armoury.')
   else:
    player=players[owner]
    effects={'Sword':('weapon',1),'Bow':('weapon',2),'Rifle':('weapon',3),
             'Pickaxe':('pickaxe',1),'Axe':('axe',1),'Compass':('compass',1),'Spark Drill':('pickaxe',2)}
    key,value=effects[name];player[key]=max(player.get(key,0),value)
    if key=='weapon':player['weapon_condition']=100;player['fake_weapon_name']=''
    msg(f'{name} forged! Equipped by P{owner+1}.')
   save()
 else:
  name=timing['name'];owner=players[timing['player']]
  spent=[timing['spent'].get(key,0) for key in FORGE_MATERIALS]
  if timing['volatile'] and random.random()<.55:outcome='explosion'
  else:outcome=random.choices(['total','partial'],weights=[70,30])[0]
  forge_timing=None
  forge_failure(outcome,owner,name,spent);save()

gear_stock={name:0 for name in GEAR_NAMES}
gear_board_open=False
# Board: three rows of three equipment types, then one row per player
# (armour, belt, ring); cells are always in the same location.
def gear_cells():
 cells=[('stock',name) for name in GEAR_NAMES]
 for index in range(len(players)):
  for slot in ('armour','belt','ring'):cells.append(('equip',index,slot))
 return cells

def gear_move(player,direction):
 cells=gear_cells();n=len(cells);pos=player.get('gear_cursor',0)%n
 col=pos%3;row=pos//3
 dx,dy=direction
 col=(col+dx)%3;row=(row+dy)%((n+2)//3)
 pos=row*3+col
 while pos>=n:pos-=3
 player['gear_cursor']=pos

def gear_use(player,index):
 cells=gear_cells();cell=cells[player.get('gear_cursor',0)%len(cells)]
 held=player.get('gear_held','')
 if cell[0]=='stock':
  item=cell[1]
  if held:
   gear_stock[held]=gear_stock.get(held,0)+1
   player['gear_held']=''
   msg(f'P{index+1} returned {held} to shared equipment.')
  elif gear_stock.get(item,0)>0:
   gear_stock[item]-=1;player['gear_held']=item
   msg(f'P{index+1} picked up {item}. Choose a player equipment slot.')
  else:msg('No equipment in this shared stock slot.')
 else:
  target=players[cell[1]];slot=cell[2];old=target.get(slot,'')
  if held and EQUIPMENT[held][0]!=slot:
   msg(f'{held} cannot go in a {slot} slot.');return
  target[slot]=held;player['gear_held']=old
  if held:msg(f'P{cell[1]+1} equipped {held} in the {slot} slot.')
  elif old:msg(f'P{index+1} picked up P{cell[1]+1}\'s {old}.')
  else:msg('Empty slot. Pick up equipment from shared stock first.')
 save()

def gear_close():
 global gear_board_open
 for i,p in enumerate(players):
  held=p.get('gear_held','')
  if held:
   gear_stock[held]=gear_stock.get(held,0)+1;p['gear_held']=''
 gear_board_open=False
 save()


MARKET_NAMES=('MUD','GOB','VOID')
stock_prices={'MUD':130,'GOB':235,'VOID':410}
stock_history={k:[v] for k,v in stock_prices.items()}
market_clock=0.0
players=[]; monsters=[]; portals=[]; structures=[]; crops={}; orchards={}; farm_soils={}; shared_items={}; storage_boxes={}; logs=[]; weather='Sunny'; season='Spring'; weather_timer=0; season_timer=0; tick=0; event_clock=0; hazard_kind=''; hazard_seconds=0; hazard_center=[120,120]; controllers=[]
caves={} # rock-tile key -> excavation progress, reinforcement and stability
for i in range(pygame.joystick.get_count()):
 j=pygame.joystick.Joystick(i); j.init(); controllers.append(j)

def newplayer(i):
 return dict(x=(119+i)*T+20,y=120*T+20,hp=100,maxhp=100,energy=100,hunger=90,thirst=100,bucket=0,bucket_water=0,fish_bucket=0,fish_caught={},water_bottles=1,water_filled=1,boots=0,compass=0,treasures=[],luck=0,fish_cd=0,forage_cd=0,sprint=100,torches=0,ore=0,gems=0,snow_blocks=0,wooden_shield=0,wallet=250,bank=0,cap=1500,wood=5,stone=3,seed=3,food=2,life=1,weapon=0,prestige=0,level=1,xp=0,dir=(0,1),cd=0,invuln=0,interact=0,menu=None,selection=0,controller=i-2 if i>=2 else -1,explored=[],housing=0,bedroll=0,blanket=0,backpack=0,scrap=0,home_tile=None,home_furnish=0,rental='',rent_until=0,hammock=0,tree_tent=0,campfires=0,quinzee=0,igloo=0,treehouse=0,custom_rooms=0,custom_walls=0,custom_roofs=0,temperature=65,raft=0,boat=0,aboard=False,tarps=0,sleeping_bags=0,bivy_sack=0,bivy_prototype=0,bivy_leak=False,pillow=0,cushion=0,foam_pad=0,sleep_kit='bedroll',bivy_on=False,sleep_quality=0,sanity=75,carving_tool=0,carve_pattern='spiral',craft_shape='chair',craft_material='wood',craft_style='plain',craft_fabric='none',water_collectors=0,water_reserve=0,firewood=0,craft_bench=0,inside=False,home_comfort=0,inventory_slots=5,thermal_coat=0,canteen=0,field_kit=0,sail=0,pickaxe=0,axe=0,map_beacon=0,solar_lamp=0,stats={'wood':0,'stone':0,'fish':0,'monsters':0,'explore':0},quests_claimed=[],weapon_condition=100,caches_found=[],hotbar_selection=0,maps_owned=[],armour='',belt='',ring='',gear_cursor=0,gear_held='',hide=0,ingot=0,flux=0,crystal_dust=0,volatile_mineral=0,forge_target=0,forge_guess=[0,0,0,0,0],dealer_visits=0,play_seconds=0.0,idle_seconds=0.0,npc_encounters=0,contract_rank=0,animal_visits=[],fake_weapon_name='',portal_gun=0,portal_condition=100,portal_charges=0,portal_cd=0,portal_stabilizer=0,portable_scanner=0,achievements=[],stocks={},business_owned=False,business_profit=0,business_clock=0.0,casino_losses=0,cave_tile=None,cave_digs=0,ice_holes_opened=0,flint_steel=0,arcade_unlocks=[])
# Title and save slots. JSON files may be dropped on any save's mod box.
# A drop is copied into that save's writable data folder. No rebuild required.
import shutil
slot=1;confirm_delete=False;selected_screen='title';notice='';notice_until=0;tutorial_page=0
MODE_OPTIONS=['Survival','Creative']; DIFFICULTIES=['Peaceful','Easy','Normal','Hard','Nightmare']
MAP_THEMES=['Classic Islands','Woodland','Highlands']; MAP_SIZES=[240,360,480]
LIGHTING=['Bright','Standard','Moody']
NEW_SETUP={'mode':'Survival','difficulty':'Normal','map':'Classic Islands','map_size':480,'lighting':'Standard'}
world_options=NEW_SETUP.copy();setup_row=0;setup_slot=1
wallet_path=DATA_DIR/'minigame_rewards.json'
def read_rewards():
 try:
  v=json.loads(wallet_path.read_text());return max(0,min(100000,int(v.get('tokens',0))))
 except (ValueError,OSError,TypeError):return 0
def read_prize_items():
 try:
  obj=json.loads(wallet_path.read_text()).get('items',{})
  return {k:max(0,min(1000,int(v))) for k,v in obj.items() if k in ('wood','food','scrap','stone','gems','torches') and isinstance(v,int)}
 except (OSError,ValueError,TypeError):return {}
prize_items=read_prize_items()
CHEST_RARITIES=('Worn','Wooden','Ironbound','Gilded','Mythic')
def read_chests():
 try:
  obj=json.loads(wallet_path.read_text())
  raw=obj.get('chests',{})
  if isinstance(raw,int):return {'Wooden':max(0,min(1000,raw))}
  if isinstance(raw,dict):return {r:max(0,min(1000,int(raw.get(r,0)))) for r in CHEST_RARITIES}
 except (OSError,ValueError,TypeError):pass
 return {}
def read_exclusive():
 try:
  obj=json.loads(wallet_path.read_text()).get('exclusive',[])
  return [x for x in obj if x in ('Arcade Crown','Arcade Compass','Carnival Banner','Silver Arcade Mask','Golden Arcade Cape','Money Tree')][:100] if isinstance(obj,list) else []
 except (OSError,ValueError,TypeError):return []
prize_chests=read_chests();prize_exclusive=read_exclusive()
CHEST_EXCLUSIVES=('Arcade Crown','Arcade Compass','Carnival Banner','Silver Arcade Mask','Golden Arcade Cape')
# Most chests are useless. Rarer chests improve the odds, not guarantee a prize.
CHEST_TABLE={
 'Worn':(.82,.94,.985), 'Wooden':(.72,.88,.97),
 'Ironbound':(.58,.79,.95), 'Gilded':(.42,.67,.90),
 'Mythic':(.30,.55,.82)}
# Roll: junk, minor resources, tokens, exclusive cosmetic/exploration unlock.
def open_prize_chest(rarity):
 global minigame_points
 if rarity not in CHEST_RARITIES or prize_chests.get(rarity,0)<=0:return f'No {rarity} chests. Win minigames to earn more.'
 prize_chests[rarity]-=1
 roll=random.random();junk,resources,tokens=CHEST_TABLE[rarity]
 if roll<junk:
  message=random.choice(('An expired coupon. Worthless.','One soggy sock. Unwearable.','A decorative pebble. Not even shiny.','A certificate of absolutely nothing.','A broken plastic spoon.','A rubber duck with zero gameplay effect.'))
 elif roll<resources:
  gift=random.choice(('wood','food','scrap','stone','gems','torches'))
  amount=1 if gift=='gems' else random.randint(1,4)
  prize_items[gift]=prize_items.get(gift,0)+amount
  message=f'{amount} {gift} added to prize vault. Choose a save to claim.'
 elif roll<tokens:
  amount=random.randint(12,45) * (1+CHEST_RARITIES.index(rarity))
  minigame_points+=amount
  message=f'{amount} tokens added to prize vault.'
 else:
  item=random.choice(CHEST_EXCLUSIVES)
  if item not in prize_exclusive:prize_exclusive.append(item);message=f'EXCLUSIVE: {item}! Stored in prize vault.'
  else:message=f'Duplicate {item}. Completely useless this time.'
 write_rewards(minigame_points)
 return f'{rarity} chest: {message}'

def write_rewards(value):
 wallet_path.write_text(json.dumps({'tokens':max(0,int(value)),'items':prize_items,'chests':prize_chests,'exclusive':prize_exclusive},indent=2),encoding='utf8')

# Rewards are stored outside every world until the player explicitly assigns them.
# A claim transfers ONLY the selected entry into ONE existing Endless save.
VAULT_JOURNAL=DATA_DIR/'prize_claims.jsonl'
vault_index=0;vault_target=1;chest_index=1
def vault_entries():
 entries=[]
 if minigame_points>0:entries.append(('tokens','Arcade tokens',minigame_points))
 entries.extend(('item',item,n) for item,n in sorted(prize_items.items()) if n>0)
 entries.extend(('unlock',name,1) for name in prize_exclusive)
 return entries

def claim_vault_entry(index,target):
 global minigame_points
 entries=vault_entries()
 if not entries:return 'The prize vault is empty.'
 if not 0<=index<len(entries):return 'Select a vault reward.'
 path=SAVE_DIR/f'slot_{target}.json'
 if not path.is_file():return f'Create and save Endless slot {target} first.'
 try:
  world=json.loads(path.read_text(encoding='utf8'))
  ps=world.get('players',[])
  if not isinstance(ps,list) or not ps or not isinstance(ps[0],dict):return 'Save has no valid player.'
  kind,name,value=entries[index];player=ps[0]
  if kind=='tokens':
   moved=min(value,25);player['wallet']=int(player.get('wallet',0))+moved*3
  elif kind=='item':
   moved=min(value,5);player[name]=int(player.get(name,0))+moved
  else:
   owned=player.setdefault('arcade_unlocks',[])
   if name in owned:return f'{name} is already unlocked in slot {target}. Pick another save.'
   owned.append(name);moved=1
  # Complete save write BEFORE deducting from vault.
  backup=path.with_suffix('.prize-backup')
  shutil.copy2(path,backup)
  tmp=path.with_suffix('.claim-tmp');tmp.write_text(json.dumps(world),encoding='utf8');tmp.replace(path)
  if kind=='tokens':minigame_points-=moved
  elif kind=='item':
   prize_items[name]-=moved
   if not prize_items[name]:del prize_items[name]
  else:prize_exclusive.remove(name)
  write_rewards(minigame_points)
  with VAULT_JOURNAL.open('a',encoding='utf8') as journal:journal.write(json.dumps({'slot':target,'type':kind,'name':name,'amount':moved})+'\n')
  return f'Claimed {moved} {name} into Endless slot {target}. Remaining prizes are safe.'
 except (OSError,TypeError,ValueError,KeyError) as exc:return f'Claim failed: {str(exc)[:65]}'

minigame_points=read_rewards();mini_game=0;mini_round=0;mini_status='';mini_deadline=0.0;mini_target=0;mini_score=0
MINI_NAMES=['Reflex Strike','Number Guess','Lucky Crates']
def mini_begin():
 global mini_round,mini_status,mini_deadline,mini_target,mini_score
 mini_round=1;mini_score=0;mini_status='';mini_target=random.randrange(1,5)
 mini_deadline=time.monotonic()+random.uniform(1.2,2.8)
def mini_action(answer):
 global mini_round,mini_status,mini_deadline,mini_target,mini_score,minigame_points,prize_chests
 if mini_round<=0:return
 now=time.monotonic()
 if mini_game==0:
  good=now>=mini_deadline and now<mini_deadline+0.7 and answer==1
  mini_status='Perfect strike!' if good else 'Missed the timing window.'
 elif mini_game==1:
  good=answer==mini_target;mini_status='Correct guess!' if good else f'Nope. The number was {mini_target}.'
 else:
  good=answer==mini_target;mini_status='Treasure crate!' if good else 'Empty crate. Better luck next time.'
 if good:mini_score+=1
 if mini_round>=5:
  payout=mini_score*12
  minigame_points+=payout
  if mini_score>=3:
   rarity=random.choices(CHEST_RARITIES,weights=(49,30,14,6,1))[0]
   prize_chests[rarity]=prize_chests.get(rarity,0)+1
   mini_status+=f' Won a {rarity} chest! Open it at the arcade.'
   if mini_score==5 and random.random()<0.002 and 'Money Tree' not in prize_exclusive:
    prize_exclusive.append('Money Tree');mini_status+=' MONEY TREE jackpot! Claim it from the prize vault.'
   gift=random.choice(('wood','food','scrap','stone','gems','torches'))
   quantity=1 if gift in ('gems','torches') else random.randint(2,5)
   prize_items[gift]=prize_items.get(gift,0)+quantity
   mini_status+=f' Bonus prize: {quantity} {gift}!'
  write_rewards(minigame_points)
  mini_status+=f'  Set complete: +{payout} prize tokens. Redeem on a save!'
  mini_round=0
 else:
  mini_round+=1;mini_target=random.randrange(1,5);mini_deadline=now+random.uniform(1.1,2.4)

def world_setup_adjust(delta):
 key=('difficulty','map','map_size','lighting','mode')[setup_row]
 items={'difficulty':DIFFICULTIES,'map':MAP_THEMES,'map_size':MAP_SIZES,'lighting':LIGHTING,'mode':MODE_OPTIONS}[key]
 idx=items.index(world_options[key]);world_options[key]=items[(idx+delta)%len(items)]

TUTORIAL_PAGES=[
 ('WELCOME TO STRAY SHORES',[
  'Start a new world with a tiny settlement and only a few shops.',
  'You begin in the Ancient Age; technology must be researched.',
  'Choose Endless or Minigames after Start Game.',
  'New Endless saves configure difficulty, map, size, lighting and Creative/Survival.',
  'Minigame prize tokens and items can be redeemed into one Endless save.',
  'Your first goal in Survival: food, fresh water, a safe place to sleep.',
  'This tutorial does not create or change a save file.']),
 ('MOVING AND INTERACTING',[
  'Player 1: WASD move | E interact | Space attack | R eat.',
  'Player 2: Arrow keys move | Enter interact | Right Shift attack.',
  'Players 3 and 4: game controllers (connect before starting).',
  'Keep the party together: everyone shares one camera.',
  'Press Esc during gameplay to pause or inspect your mods.']),
 ('STAY ALIVE',[
  'Keep HUNGER and THIRST high; rest helps recover health.',
  'Summer heat makes thirst drop faster; winter burns hunger.',
  'Nights are dangerous. Campfires, caves and houses help.',
  'Find or craft a sleeping place before dark.',
  'Cold, exhaustion, dehydration and starvation can kill.']),
 ('VILLAGERS AND SHELTER',[
  'Your three initial villagers have no homes and need meals.',
  'Visit VILLAGE to check health, sleep, thirst and morale.',
  'Assign each villager a bed, or hire a paid bed organizer.',
  'Farmers and other workers expect food and fair wages.',
  'Neglected villagers may stop working or leave.']),
 ('BUILDING AND RESOURCES',[
  'F3 opens building mode: select pieces with 1-8.',
  'Page Up/Down changes construction catalog pages.',
  'Gather wood, stone, clay, sand, ore and plant fibres.',
  'Process planks, bricks, nails and other building parts.',
  'The world grows as you buy new island regions.']),
 ('MINING AND FORGING',[
  'Find rocky ground and excavate a cave using C (P1).',
  'Inside a cave, E opens deeper mining actions.',
  'Bring lighting: craft torches and flint-and-steel.',
  'At the forge, guess ingredients and exact quantities.',
  'Correct recipes still require several timed strikes.']),
 ('BOATS, RIVERS AND WINTER',[
  'Build a raft or boat to explore coasts and waterways.',
  'Rivers can be crossed by bridge, raft or wading.',
  'Wading gets you wet, which can be dangerous when cold.',
  'Frozen water needs a cut or drilled ice hole for fishing.',
  'Long journeys require food, water and preparation.']),
 ('SETTLEMENT AND TECHNOLOGY',[
  'Visit RESEARCH to advance through seven eras.',
  'Unlock farms, taverns, workshops, power and machines.',
  'Maintain services and pay workers; unrest has consequences.',
  'Later eras unlock advanced tools, vehicles and portal guns.',
  'Your decisions can reshape the settlement over time.']),
 ('INVENTORY, MODS AND SAVES',[
  'Tab opens P1 inventory; shared stock can supply the party.',
  'Equip armour, belts and rings individually for each player.',
  'Choose a save slot after START GAME; five slots exist.',
  'Drop compatible JSON mods beside a save on the slot screen.',
  'Esc > Mods for this save shows mod compatibility statuses.']),
 ('YOU ARE READY',[
  'Begin by finding food and water, then make shelter.',
  'Check on the villagers before starting big projects.',
  'Explore carefully, especially after sunset.',
  'Achievements are useless. You have been warned.',
  'Press Enter to return to the title screen.'])
]
MAJOR_UPDATES=[('v0.1.1 — Islands, Markets & Fantasy', ['New regional market stalls in Amber Wilds, Frostwood Reach and Sunken Keys.', 'Distinct trade goods, supplies, port investment and standing.', 'Grove Spirit, Frost Warden and Tide Oracle encounters and lasting quest rewards.']), ('v0.1.0 — New baseline', ['In-game major update history and version-selecting launcher.', 'Per-version saves and mods, allowing older builds to stay usable.']), ('World & society', ['Large islands, local multiplayer, crafting, housing, village roles and governance.', 'Technology eras, machines, expeditions, trading, storms and caves.']), ('Farming & preservation', ['Crops, fruit orchards, soil water and N/P/K nutrients, disease and care.', 'Food spoilage, salting, smokehouses, cellars, ice houses and organizer NPC.']), ('Workshops & shelter', ['Hands-on pottery, kilns, glazing, metal casting and glassmaking.', 'Custom furniture, carving, bedding, sleeping bags and prototype/proper bivies.']), ('Rewards & challenges', ['Five treasure chest classes: Worn, Wooden, Ironbound, Gilded and Mythic.', 'Prize vault, rare Money Tree jackpot, slow cash harvest and achievement.'])]
CHANGELOG_RECT=pygame.Rect(369,540,382,54)
TITLE_START_RECT=pygame.Rect(242,381,302,76)
TITLE_TUTORIAL_RECT=pygame.Rect(575,381,302,76)
SLOT_ROW_Y=[174+n*79 for n in range(5)]

def pill(surface,rect,fill,stroke=(90,133,165),radius=13,width=2):
 pygame.draw.rect(surface,fill,rect,border_radius=radius)
 pygame.draw.rect(surface,stroke,rect,width,border_radius=radius)

def text_at(s,x,y,color=(236,243,249),ft=None):
 screen.blit((ft or font).render(str(s),True,color),(x,y))

def slot_mod_folder(n):
 target=MOD_DIR/f'slot_{n}'
 target.mkdir(parents=True,exist_ok=True)
 return target

def import_mod(src,n):
 # Mods are declarative JSON only; never load Python or executable files.
 path=Path(src)
 if path.suffix.lower()!='.json' or not path.is_file() or path.stat().st_size>1024*1024:
  return 'Drop .json packs here; install trusted .py plugins through Finder.'
 try:
  obj=read_mod_file(path)
  status,reason,_=validate_mod(obj)
  if status!='ACTIVE':return f'Rejected {status.lower()} mod: {reason[:75]}'
  dst=slot_mod_folder(n)/path.name
  if path.resolve()!=dst.resolve():shutil.copy2(path,dst)
  return f'Installed {path.name} for slot {n}. Restart this save to apply.'
 except (OSError,ValueError,UnicodeError) as exc:
  return f'Invalid mod: {str(exc)[:95]}'

def drop_slot_at(mouse_y):
 for n,y in enumerate(SLOT_ROW_Y,1):
  if y<=mouse_y<y+67:return n
 return slot

while selected_screen!='players':
 for event in pygame.event.get():
  if event.type==pygame.QUIT:pygame.quit();raise SystemExit
  if event.type==pygame.KEYDOWN:
   if selected_screen=='title':
    if event.key in (pygame.K_RETURN,pygame.K_SPACE):selected_screen='mode_select'
    elif event.key==pygame.K_t:selected_screen='tutorial';tutorial_page=0
    elif event.key==pygame.K_c:selected_screen='updates';updates_page=0
    elif event.key==pygame.K_ESCAPE:pygame.quit();raise SystemExit
   elif selected_screen=='updates':
    if event.key==pygame.K_ESCAPE:selected_screen='title'
    elif event.key in (pygame.K_RIGHT,pygame.K_DOWN,pygame.K_PAGEDOWN,pygame.K_SPACE):updates_page=min(len(MAJOR_UPDATES)-1,updates_page+1)
    elif event.key in (pygame.K_LEFT,pygame.K_UP,pygame.K_PAGEUP):updates_page=max(0,updates_page-1)
   elif selected_screen=='tutorial':
    if event.key==pygame.K_ESCAPE:selected_screen='title'
    elif event.key in (pygame.K_RIGHT,pygame.K_DOWN,pygame.K_SPACE,pygame.K_PAGEDOWN):tutorial_page=min(len(TUTORIAL_PAGES)-1,tutorial_page+1)
    elif event.key in (pygame.K_LEFT,pygame.K_UP,pygame.K_PAGEUP):tutorial_page=max(0,tutorial_page-1)
    elif event.key==pygame.K_RETURN:
     if tutorial_page==len(TUTORIAL_PAGES)-1:selected_screen='title'
     else:tutorial_page+=1
   elif selected_screen=='mode_select':
    if event.key in (pygame.K_ESCAPE,):selected_screen='title'
    elif event.key in (pygame.K_UP,pygame.K_DOWN,pygame.K_LEFT,pygame.K_RIGHT):mini_game=(mini_game+(-1 if event.key in (pygame.K_UP,pygame.K_LEFT) else 1))%2
    elif event.key in (pygame.K_RETURN,pygame.K_SPACE):
     if mini_game==0:selected_screen='slots'
     else:selected_screen='minigame_select';mini_game=0
   elif selected_screen=='minigame_select':
    if event.key==pygame.K_o:notice=open_prize_chest(CHEST_RARITIES[chest_index]);mini_status=notice
    elif event.key==pygame.K_LEFT:chest_index=(chest_index-1)%len(CHEST_RARITIES)
    elif event.key==pygame.K_RIGHT:chest_index=(chest_index+1)%len(CHEST_RARITIES)
    elif event.key==pygame.K_ESCAPE:selected_screen='mode_select';mini_game=1
    elif event.key in (pygame.K_LEFT,pygame.K_UP):mini_game=(mini_game-1)%3
    elif event.key in (pygame.K_RIGHT,pygame.K_DOWN):mini_game=(mini_game+1)%3
    elif event.key in (pygame.K_RETURN,pygame.K_SPACE):selected_screen='minigame_play';mini_begin()
   elif selected_screen=='minigame_play':
    if event.key==pygame.K_ESCAPE:selected_screen='minigame_select'
    elif event.key in (pygame.K_1,pygame.K_2,pygame.K_3,pygame.K_4):mini_action(event.key-pygame.K_1+1)
    elif event.key in (pygame.K_SPACE,pygame.K_RETURN) and mini_round==0:selected_screen='minigame_select'
    elif event.key in (pygame.K_SPACE,pygame.K_RETURN) and mini_game==0:mini_action(1)
   elif selected_screen=='vault':
    if event.key==pygame.K_ESCAPE:selected_screen='slots'
    elif event.key==pygame.K_UP:vault_index=max(0,vault_index-1)
    elif event.key==pygame.K_DOWN:vault_index=min(max(0,len(vault_entries())-1),vault_index+1)
    elif event.key==pygame.K_LEFT:vault_target=5 if vault_target==1 else vault_target-1
    elif event.key==pygame.K_RIGHT:vault_target=1 if vault_target==5 else vault_target+1
    elif event.key in (pygame.K_RETURN,pygame.K_SPACE):notice=claim_vault_entry(vault_index,vault_target);vault_index=min(vault_index,max(0,len(vault_entries())-1))
   elif selected_screen=='setup':
    if event.key==pygame.K_ESCAPE:selected_screen='slots'
    elif event.key in (pygame.K_UP,pygame.K_DOWN):setup_row=(setup_row+(-1 if event.key==pygame.K_UP else 1))%6
    elif event.key in (pygame.K_LEFT,pygame.K_RIGHT) and setup_row<5:world_setup_adjust(-1 if event.key==pygame.K_LEFT else 1)
    elif event.key in (pygame.K_RETURN,pygame.K_SPACE):
     if setup_row==5:selected_screen='players'
     else:world_setup_adjust(1)
   else:
    if event.key in (pygame.K_UP,pygame.K_LEFT):slot=5 if slot==1 else slot-1;confirm_delete=False
    elif event.key in (pygame.K_DOWN,pygame.K_RIGHT):slot=1 if slot==5 else slot+1;confirm_delete=False
    elif event.key==pygame.K_DELETE:
     if confirm_delete:
      f=SAVE_DIR/f'slot_{slot}.json'
      if f.exists():f.unlink()
      notice=f'Slot {slot} save deleted; mods remain installed.';confirm_delete=False
     else:confirm_delete=True;notice=f'Press Delete again to erase slot {slot}.'
    elif event.key==pygame.K_ESCAPE:selected_screen='title';confirm_delete=False
    elif event.key in (pygame.K_RETURN,pygame.K_SPACE):
     selected_screen='players' if (SAVE_DIR/f'slot_{slot}.json').exists() else 'setup'
    elif event.key==pygame.K_v:selected_screen='vault';vault_index=0;vault_target=slot
  elif event.type==pygame.MOUSEBUTTONDOWN and event.button==1:
   mx,my=event.pos
   if selected_screen=='title':
    if TITLE_START_RECT.collidepoint(mx,my):selected_screen='mode_select';mini_game=0
    elif TITLE_TUTORIAL_RECT.collidepoint(mx,my):selected_screen='tutorial';tutorial_page=0
    elif CHANGELOG_RECT.collidepoint(mx,my):selected_screen='updates';updates_page=0
   elif selected_screen=='mode_select':
    if pygame.Rect(100,238,920,140).collidepoint(mx,my):selected_screen='slots'
    elif pygame.Rect(100,393,920,140).collidepoint(mx,my):selected_screen='minigame_select';mini_game=0
   elif selected_screen=='minigame_select':
    if pygame.Rect(120,590,875,45).collidepoint(mx,my):notice=open_prize_chest(CHEST_RARITIES[chest_index]);mini_status=notice
    for j in range(3):
     if pygame.Rect(120,220+j*115,875,95).collidepoint(mx,my):mini_game=j;selected_screen='minigame_play';mini_begin()
   elif selected_screen=='minigame_play':
    if pygame.Rect(110,550,880,90).collidepoint(mx,my) and mini_round==0:selected_screen='minigame_select'
    elif mini_game==0:mini_action(1)
    else:
     for j in range(4):
      if pygame.Rect(145+j*212,285,170,105).collidepoint(mx,my):mini_action(j+1)
   elif selected_screen=='vault':
    if pygame.Rect(850,610,170,42).collidepoint(mx,my):selected_screen='slots'
    elif pygame.Rect(100,610,250,42).collidepoint(mx,my):notice=claim_vault_entry(vault_index,vault_target)
   elif selected_screen=='setup':
    for j in range(6):
     if pygame.Rect(128,180+j*68,870,58).collidepoint(mx,my):
      setup_row=j
      if j==5:selected_screen='players'
      else:world_setup_adjust(1)
   elif selected_screen=='updates':
    if pygame.Rect(105,598,180,55).collidepoint(mx,my):selected_screen='title'
    elif pygame.Rect(847,598,180,55).collidepoint(mx,my):updates_page=min(len(MAJOR_UPDATES)-1,updates_page+1)
    elif pygame.Rect(620,598,180,55).collidepoint(mx,my):updates_page=max(0,updates_page-1)
   elif selected_screen=='tutorial':
    if pygame.Rect(105,598,180,55).collidepoint(mx,my):selected_screen='title'
    elif pygame.Rect(847,598,180,55).collidepoint(mx,my):tutorial_page=min(len(TUTORIAL_PAGES)-1,tutorial_page+1)
    elif pygame.Rect(620,598,180,55).collidepoint(mx,my):tutorial_page=max(0,tutorial_page-1)
   else:
    for n,y in enumerate(SLOT_ROW_Y,1):
     if y<=my<y+67:
      slot=n;confirm_delete=False
      if 750<=mx<=1063:
       notice=f'Slot {n}: drag a JSON file onto this box (or use Finder).'
      elif 100<=mx<=733:selected_screen='players' if (SAVE_DIR/f'slot_{n}.json').exists() else 'setup'
      break
  elif event.type==pygame.DROPFILE:
   if selected_screen=='slots':
    # SDL DROPFILE may not always expose final mouse coordinates on macOS;
    # use the current selected save slot if the pointer is not over a row.
    pos=pygame.mouse.get_pos();n=drop_slot_at(pos[1])
    notice=import_mod(event.file,n)
 if selected_screen=='title':
  screen.fill((14,27,44))
  for j in range(23):
   pygame.draw.circle(screen,(21+int(j*.7),48+int(j*1.2),71+int(j*.9)),(int((j*173)%W),int((j*131)%H)),12+(j%7)*9,2)
  pygame.draw.ellipse(screen,(40,102,110),(125,515,870,150))
  pygame.draw.ellipse(screen,(71,140,94),(230,495,670,137))
  text_at('STRAY SHORES',290,178,(255,221,129),pygame.font.SysFont('arial',66,bold=True))
  text_at('Build civilizations. Survive the night. Make questionable decisions.',213,282,(199,216,231))
  pill(screen,TITLE_START_RECT,(48,126,116),(130,216,183),19,3)
  text_at('START GAME',300,399,(247,248,236),big)
  pill(screen,TITLE_TUTORIAL_RECT,(56,82,134),(139,177,237),19,3)
  text_at('TUTORIAL',659,399,(247,248,236),big)
  pill(screen,CHANGELOG_RECT,(53,78,104),(148,189,220),12,2)
  text_at('MAJOR UPDATES (C)',455,555,(239,245,255),font)
  text_at('v0.1.0  |  Enter: Start  |  T: Tutorial  |  C: Updates  |  Esc: Quit',270,624,(180,197,211),small)
 elif selected_screen=='updates':
  screen.fill((13,28,46))
  title,lines=MAJOR_UPDATES[updates_page]
  text_at('MAJOR UPDATES  /  STRAY SHORES',270,70,(253,220,128),big)
  text_at(f'{updates_page+1} / {len(MAJOR_UPDATES)}',500,131,(164,211,218),font)
  pill(screen,pygame.Rect(90,177,938,367),(29,55,76),(112,159,190),18,2)
  text_at(title,121,217,(255,224,143),big)
  yy=287
  for line in lines:
   # Split long lines so they fit inside this screen.
   import textwrap
   for part in textwrap.wrap(line, width=78):
    text_at('- '+part,133,yy,(230,239,247),small);yy+=33
   yy+=22
  text_at('Esc: back    Left/Right: previous/next entry',340,610,(198,218,232),font)
  pill(screen,pygame.Rect(105,598,180,55),(56,78,99),(142,173,193))
  text_at('BACK',169,612,(242,243,248),font)
  pill(screen,pygame.Rect(620,598,180,55),(56,82,134),(139,177,237))
  text_at('PREVIOUS',654,613,(238,243,248),font)
  pill(screen,pygame.Rect(847,598,180,55),(48,126,116),(130,216,183))
  text_at('NEXT',909,613,(238,243,248),font)
 elif selected_screen=='mode_select':
  screen.fill((13,29,44));text_at('CHOOSE YOUR GAME MODE',305,92,(250,218,118),big)
  pill(screen,pygame.Rect(100,238,920,140),(30,77,73),(105,189,155),18,3)
  text_at('ENDLESS',145,266,(252,242,218),big)
  text_at('Build, survive, and advance your civilization in one of five saved worlds.',145,317,(211,231,222))
  pill(screen,pygame.Rect(100,393,920,140),(61,54,91),(155,127,197),18,3)
  text_at('MINIGAMES',145,418,(252,242,218),big)
  text_at('Short challenges earn tokens you can redeem in a single Endless world.',145,473,(214,204,235))
  text_at('Click an option  |  Esc: title',368,626,(184,207,220))
 elif selected_screen=='minigame_select':
  screen.fill((18,29,49));text_at('MINIGAME ARCADE',390,76,(250,215,122),big)
  text_at(f'Tokens: {minigame_points} | Stored items: {sum(prize_items.values())} | Chests: {sum(prize_chests.values())}',215,140,(154,222,174))
  text_at('Chest: '+CHEST_RARITIES[chest_index]+'  (Left/Right to change rarity)',215,171,(236,206,144),small)
  text_at('Inventory: '+', '.join(f'{r}:{prize_chests.get(r,0)}' for r in CHEST_RARITIES),215,191,(184,203,226),small)
  for j,name in enumerate(MINI_NAMES):
   pill(screen,pygame.Rect(120,220+j*115,875,95),(44,66,92),(143,173,206),16)
   text_at(name,160,245+j*115,(247,239,215),big)
  pill(screen,pygame.Rect(120,590,875,45),(77,61,102),(200,157,235),10)
  text_at('OPEN SELECTED CHEST (O) | Mostly junk | Vault prizes stay unclaimed',175,601,(248,227,173),font)
  text_at(notice[:105] if notice else 'Win 3+ rounds to earn a chest. Rare collectibles only come from chests.',145,651,(188,214,227),small)
 elif selected_screen=='vault':
  screen.fill((16,30,44));text_at('PRIZE VAULT — KEEP OR CLAIM',292,52,(250,218,137),big)
  text_at(f'Destination save: SLOT {vault_target}  (Left/Right to change)',140,107,(179,225,207))
  text_at('Up/Down: select | Enter: claim selected reward | Esc: back',135,145,(197,214,229),small)
  entries=vault_entries()
  for j,(kind,name,amount) in enumerate(entries[max(0,vault_index-7):max(0,vault_index-7)+9],max(0,vault_index-7)):
   y=200+(j-max(0,vault_index-7))*43
   pill(screen,pygame.Rect(110,y,890,36),(65,79,93) if j==vault_index else (29,52,71),(237,195,112) if j==vault_index else (67,105,128),5)
   text_at(f'{kind.upper()} | {name}  x{amount}',125,y+6,(248,239,208) if j==vault_index else (199,216,227),small)
  if not entries:text_at('Nothing to claim. Your vault will keep future rewards.',210,240,(191,216,226))
  text_at(notice[:110] if notice else 'Only the selected reward moves. The rest stay in your vault.',112,578,(242,203,153),small)
  pill(screen,pygame.Rect(100,610,250,42),(48,123,102),(110,194,163));text_at('CLAIM SELECTED',122,620,(245,249,241),small)
  pill(screen,pygame.Rect(850,610,170,42),(58,70,91),(137,164,186));text_at('BACK',910,620,(245,249,241),small)
 elif selected_screen=='minigame_play':
  screen.fill((24,33,49));text_at(MINI_NAMES[mini_game],365,85,(249,217,121),big)
  text_at(f'Round: {mini_round or 5}/5   Wins: {mini_score}   Prize tokens: {minigame_points}',235,160,(215,230,242))
  if mini_round:
   if mini_game==0:
    remain=mini_deadline-time.monotonic()
    text_at('STRIKE! Press Space or click when the signal turns GREEN.',153,284,(237,242,245),font)
    shade=(73,180,112) if -.7<=remain<=0 else (189,75,70) if remain<-.7 else (194,143,77)
    pill(screen,pygame.Rect(380,350,360,105),shade,(228,219,188),15,3)
    text_at('STRIKE NOW' if -.7<=remain<=0 else 'WAIT...' if remain>0 else 'TOO LATE',452,385,(255,255,248),big)
   else:
    text_at('Choose a number from 1 to 4:' if mini_game==1 else 'Pick a mystery crate:',320,247,(223,233,243),font)
    for j in range(4):
     pill(screen,pygame.Rect(145+j*212,285,170,105),(65,84,118),(156,182,217),15)
     text_at(str(j+1),209+j*212,317,(255,230,153),big)
  else:text_at('Challenge completed! Press Enter for the games menu.',215,345,(157,236,191),font)
  text_at(mini_status[:110],110,510,(252,199,146),small)
  text_at('Esc returns to minigame selection.',357,650,(184,207,219),small)
 elif selected_screen=='setup':
  screen.fill((14,32,48));text_at(f'NEW ENDLESS WORLD — SLOT {slot}',284,82,(252,217,117),big)
  rows=[('Difficulty',world_options['difficulty']),('Map',world_options['map']),('Map size',str(world_options['map_size'])+' x '+str(world_options['map_size'])),('Lighting',world_options['lighting']),('Rules',world_options['mode']),('CREATE WORLD','Continue to player selection')]
  for j,(label,value) in enumerate(rows):
   rect=pygame.Rect(128,180+j*68,870,58)
   pill(screen,rect,(37,78,91) if j==setup_row else (33,54,76),(126,197,165) if j==setup_row else (87,124,157),10,2)
   text_at(label,155,193+j*68,(245,236,207),font)
   text_at(value,525,193+j*68,(167,231,203),font)
  text_at('Up/Down select | Left/Right change | Enter confirm | Esc back',214,650,(189,214,226),small)
 elif selected_screen=='tutorial':
  screen.fill((14,27,44))
  title,lines=TUTORIAL_PAGES[tutorial_page]
  text_at('STRAY SHORES  /  BEGINNER TUTORIAL',202,55,(255,221,129),big)
  text_at(f'LESSON {tutorial_page+1} OF {len(TUTORIAL_PAGES)}',85,138,(147,202,208),small)
  pill(screen,pygame.Rect(78,169,964,375),(25,48,69),(86,142,174),18,2)
  text_at(title,112,204,(250,220,132),big)
  for idx,line in enumerate(lines):
   pygame.draw.circle(screen,(110,194,184),(121,275+idx*48),5)
   text_at(line,143,259+idx*48,(226,235,242),font)
  pill(screen,pygame.Rect(105,598,180,55),(64,75,93),(142,173,193))
  text_at('BACK TO TITLE',120,613,(238,243,248),small)
  pill(screen,pygame.Rect(620,598,180,55),(56,82,134),(139,177,237))
  text_at('PREVIOUS',654,613,(238,243,248),font)
  pill(screen,pygame.Rect(847,598,180,55),(48,126,116),(130,216,183))
  text_at('NEXT',911,613,(238,243,248),font)
  text_at('Left/Right: pages  |  Enter: next  |  Esc: title',332,674,(175,202,218),small)
 else:
  screen.fill((16,32,49))
  text_at('CHOOSE YOUR WORLD',330,71,(251,221,121),big)
  text_at('Select save. Drop JSON packs here; trusted Python plugins via Finder.',215,115,(202,219,230))
  for n,y in enumerate(SLOT_ROW_Y,1):
   f=SAVE_DIR/f'slot_{n}.json';desc='New world'
   if f.exists():
    try:
     saved=json.loads(f.read_text());desc=f"{len(saved.get('players',[]))} players | {len(saved.get('structures',[]))} buildings"
    except (OSError,ValueError,TypeError):desc='Unreadable save'
   outline=(242,201,107) if slot==n else (79,116,148)
   pill(screen,pygame.Rect(92,y,642,67),(31,57,74),outline)
   text_at(f'SLOT {n}',114,y+9,(246,224,155) if slot==n else (226,239,246),font)
   text_at(desc,238,y+10,(173,201,212),small)
   text_at('Click to play',238,y+34,(145,181,191),small)
   mod_count=len(list(slot_mod_folder(n).glob('*.json')))
   pill(screen,pygame.Rect(749,y,318,67),(35,72,86),(99,188,171))
   text_at('DROP .JSON MODS HERE',775,y+10,(217,243,237),font)
   other_count=sum(1 for ff in slot_mod_folder(n).iterdir() if ff.is_file() and ff.suffix.lower() in ('.py','.zip','.dylib','.so','.dll','.exe','.pak','.mod'))
   text_at(f'Slot {n}: {mod_count} data packs'+(f' | {other_count} code/other files' if other_count else ''),775,y+36,(246,151,129) if other_count else (154,207,196),small)
  text_at('Up/Down: select | Enter: play | Delete twice: erase | Esc: title',215,650,(200,218,228),small)
  text_at(f'Prize vault: {minigame_points} tokens, {len(vault_entries())} reward types | V: claim to chosen save',124,619,(148,225,176),small)
  if notice:text_at(notice[:100],130,682,(255,200,139),small)
 pygame.display.flip();clock.tick(30)

SAVE=SAVE_DIR/f'slot_{slot}.json'
# Slots created in previous versions use their historical rules; new ones use the setup panel.
if SAVE.exists():
 try:
  previous_cfg=json.loads(SAVE.read_text()).get('world_options',{})
  world_options={**NEW_SETUP,**{k:v for k,v in previous_cfg.items() if k in NEW_SETUP}}
 except (OSError,ValueError,TypeError):world_options=NEW_SETUP.copy()
else:world_options=world_options.copy()
world_limit=int(world_options['map_size'])
MOD=load_mods()
# Executable plugins receive normal user privileges; make a recovery point first.
# Do this before import, not merely after checking the mod list.
if SAVE.is_file():
 try:
  import shutil
  safe_dir=DATA_DIR/'backups'/f'slot_{slot}'
  safe_dir.mkdir(parents=True,exist_ok=True)
  stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
  shutil.copy2(SAVE,safe_dir/f'slot_{slot}_before_plugins_{stamp}.json')
 except OSError as exc:print('WARNING: pre-plugin save backup failed:',exc)
EXT_MODS=ModManager(DATA_DIR,slot,52);EXT_MODS.load()
MOD_LIST.extend(EXT_MODS.statuses)
backup_before_mod_change()
try:saved_count=int(json.loads(SAVE.read_text()).get('player_count',1))
except (OSError,ValueError,TypeError):saved_count=1
count=max(1,min(4,saved_count))
selecting=True
while selecting:
 for event in pygame.event.get():
  if event.type==pygame.QUIT:pygame.quit();raise SystemExit
  if event.type==pygame.KEYDOWN:
   if event.key in (pygame.K_LEFT,pygame.K_DOWN):count=max(1,count-1)
   if event.key in (pygame.K_RIGHT,pygame.K_UP):count=min(4,count+1)
   if event.key in (pygame.K_RETURN,pygame.K_SPACE):selecting=False
 screen.fill((22,40,53))
 screen.blit(big.render(f'STRAY SHORES v78 - SLOT {slot} - PLAYER SELECT',True,(255,215,105)),(140,175))
 screen.blit(big.render(f'Players:  <   {count}   >',True,(235,240,245)),(370,280))
 screen.blit(font.render(f'Keyboard: {min(count,2)}  |  Controllers needed: {max(0,count-2)}  |  Connected: {len(controllers)}',True,(220,225,230)),(230,345))
 screen.blit(font.render('Left/Right: choose   Enter: start',True,(220,225,230)),(350,395))
 pygame.display.flip();clock.tick(30)
players=[newplayer(i) for i in range(count)]
for p in players:
 for mod_item in EXT_MODS.items:p.setdefault(mod_item,0)
for i,p in enumerate(players):p['controller']=i-2 if i>=2 else -1
if count>2 and len(controllers)<count-2:print('Warning: connect more controllers for P3/P4')
data={}  # Empty new save slots must not reference an undefined data variable.
try:
 data=json.loads(SAVE.read_text())
 old_map_size=int(data.get('world_size',OLD_N))
 for i,loaded in enumerate(data.get('players',[])):
  if i<len(players):
   players[i].update({k:v for k,v in loaded.items() if k in players[i] and k not in ('menu','controller','cd','interact','invuln','dir','gear_held')})
   if old_map_size!=N and old_map_size>0:
    players[i]['explored']=[(int(v)//old_map_size)*N+(int(v)%old_map_size) for v in players[i].get('explored',[]) if 0<=int(v)<old_map_size**2]
 structures=data.get('structures',[]);crops=data.get('crops',{});orchards.update(data.get('orchards',{}));farm_soils.update(data.get('farm_soils',{}));shared_items=data.get('shared_items',{});storage_boxes=data.get('storage_boxes',{});forge_built=bool(data.get('forge_built',False));forge_condition=max(0,min(100,int(data.get('forge_condition',100))));forge_skill=max(0,min(30,int(data.get('forge_skill',0))));forge_attempts=max(0,int(data.get('forge_attempts',0)));forge_discovered[:]=[name for name in data.get('forge_discovered',[]) if name in FORGE_RECIPES];gear_stock.update({k:max(0,int(v)) for k,v in data.get('gear_stock',{}).items() if k in gear_stock and isinstance(v,int)});season=data.get('season','Spring');season_timer=float(data.get('season_timer',0));weather=data.get('weather','Sunny');era=int(data.get('era',6 if any(q.get('portal_gun') for q in players) else 4 if any(q.get('weapon',0)>=3 for q in players) else 0));era=max(0,min(6,era));knowledge=int(data.get('knowledge',0));research_remainder=int(data.get('research_remainder',0));workshops=data.get('workshops',{});workshop_clock=float(data.get('workshop_clock',0));event_clock=float(data.get('event_clock',0));hazard_kind=data.get('hazard_kind','');hazard_seconds=float(data.get('hazard_seconds',0));hazard_center=data.get('hazard_center',[120,120]);caves.update({k:v for k,v in data.get('caves',{}).items() if isinstance(k,str) and isinstance(v,dict) and 0<=int(v.get('progress',0))<=5});stock_prices.update({k:max(1,min(100000,int(v))) for k,v in data.get('stock_prices',{}).items() if k in MARKET_NAMES and isinstance(v,(int,float))});market_clock=float(data.get('market_clock',0))
except (OSError,ValueError,TypeError):pass

# New save terrain styling; old maps retain the Classic Islands world.
if world_options['map']!='Classic Islands':
 for yy in range(min(world_limit,N)):
  for xx in range(min(world_limit,N)):
   kind=terrain[yy][xx]
   if kind in ('grass','forest','rock'):
    wave=math.sin(xx*.17)*math.cos(yy*.12)
    if world_options['map']=='Woodland' and wave>.07:terrain[yy][xx]='forest'
    elif world_options['map']=='Highlands' and wave>.32:terrain[yy][xx]='rock'
# Rewards remain in the persistent prize vault until deliberately claimed from save selection.
# v55 settlement data: backwards-compatible default values for older save slots.
settlement_treasury=max(0,int(data.get('settlement_treasury',0))) if isinstance(data,dict) else 0
villagers=[v for v in data.get('villagers',[]) if isinstance(v,dict) and v.get('job') in ('idle','farmer','tavern keeper','guard','engineer','organizer')] if isinstance(data,dict) else []
# This applies only to brand-new saves. Nobody begins with housing or employment.
if not isinstance(data,dict) or not data:
 villagers=[{'name':name,'job':'idle','wage':0,'morale':65,'hunger':75,'trained':0,'striking':False,'homeless':True,'unpaid_cycles':0} for name in ('Ada','Bram','Cora')]
for villager in villagers:
 villager.setdefault('hunger',80)
 villager.setdefault('hp',100)
 villager.setdefault('sleep',65)
 villager.setdefault('thirst',80)
 villager.setdefault('bed',None)
 villager.setdefault('unpaid_cycles',0)
 villager.setdefault('homeless',True)
 villager.setdefault('morale',65)
 villager.setdefault('striking',False)

ice_holes=set(data.get('ice_holes',[]) if isinstance(data,dict) else [])
settlement_clock=max(0,float(data.get('settlement_clock',0))) if isinstance(data,dict) else 0.0
food_age=max(0,int(data.get('food_age',0))) if isinstance(data,dict) else 0
preservation_log=str(data.get('preservation_log','No stored goods yet.'))[:180] if isinstance(data,dict) else 'No stored goods yet.'
army_training=max(0,int(data.get('army_training',0))) if isinstance(data,dict) else 0
vehicles=[v for v in data.get('vehicles',[]) if isinstance(v,dict) and v.get('kind') in ('tank','plane','drone')] if isinstance(data,dict) else []
settlement_log=str(data.get('settlement_log',''))[:150] if isinstance(data,dict) else ''
# Governance state is independent of player combat prestige or inventory.
government={'system':'chiefdom','ruler':0,'forced_labor':False,'servants':0,'laws':['customary law'],'unrest':8,'legitimacy':65,'election_clock':0.0,'rebellions':0,'overthrows':0,'history':[],'labor_cycles':0,'labor_policy_age':0,'opinion_clock':0.0,'factions':{'estate_owners':0,'reformers':0},'last_labor_yield':0}
if isinstance(data,dict) and isinstance(data.get('government'),dict):
 government.update({k:v for k,v in data['government'].items() if k in government})
government['ruler']=max(0,min(len(players)-1,int(government.get('ruler',0))))
government['servants']=max(0,min(20,int(government.get('servants',0))))
government['unrest']=max(0,min(100,int(government.get('unrest',8))))
government['legitimacy']=max(0,min(100,int(government.get('legitimacy',65))))
government['factions']={**{'estate_owners':0,'reformers':0},**(government.get('factions',{}) if isinstance(government.get('factions'),dict) else {})}

# Civic infrastructure: saved independently from individual player inventory.
CIVIC_DEFAULT={'sanitation':0,'fire_service':0,'roads':0,'clinic':0,'health':85,'fires':0,'illnesses':0,'incidents':0,'clock':0.0,'recent':'The settlement is functioning, for now.'}
civic=CIVIC_DEFAULT.copy()
if isinstance(data,dict) and isinstance(data.get('civic'),dict):
 for key,value in data['civic'].items():
  if key in civic and isinstance(value,type(civic[key])):civic[key]=value
for key in ('sanitation','fire_service','roads','clinic'):civic[key]=max(0,min(3,int(civic[key])))
civic['health']=max(0,min(100,int(civic['health'])))

# Regional economies and one-time fantasy discoveries survive save/reload.
regional_trade={k:max(0,min(100,int(v))) for k,v in (data.get('regional_trade',{}) if isinstance(data,dict) else {}).items() if k in ISLAND_MARKETS and isinstance(v,(int,float))}
fantasy_quests={k:bool(v) for k,v in (data.get('fantasy_quests',{}) if isinstance(data,dict) else {}).items() if k in ISLAND_FANTASY}

# Migration: earlier saves might contain people/buildings on outer islands.
# For a brand-new save, data remains {}, preventing a NameError at startup.
# Those regions remain accessible so loading cannot strand a player.
try:
 if isinstance(data,dict):
  if 'unlocked_regions' in data:
   unlocked_regions[:]=sorted({0,*[int(v) for v in data['unlocked_regions'] if int(v) in (1,2,3)]})
  else:
   reached={land_region(int(q['x']//T),int(q['y']//T)) for q in players}
   reached.update(land_region(int(x),int(y)) for x,y,*_ in structures)
   unlocked_regions[:]=sorted({0,*[v for v in reached if v>0]})
except (ValueError,TypeError,KeyError):
 unlocked_regions[:]=[0]

# Expand from the EXPANSION office next to the DOCK.
# Achievements are deliberately cosmetic: no XP, coins, items, multipliers, or perks.
ACHIEVEMENTS=[
 ('money_tree','Money comes from trees?!','Plant your arcade-prize Money Tree.'),
 ('professional_homeless','Professionally Homeless','Start your adventure with absolutely no property.'),
 ('first_fish','Suspiciously Fishy','Catch your first fish. It refuses to testify.'),
 ('lumber','Certified Tree Annoyance','Collect at least 25 wood over your career.'),
 ('stone','Rock Enthusiast','Collect at least 20 stone over your career.'),
 ('first_kill','Goose Negotiator','Defeat your first hostile creature.'),
 ('first_home','Landlord Material','Acquire a permanent home.'),
 ('treehouse','Above the Housing Market','Build a treehouse.'),
 ('igloo','Ice Estate','Construct an igloo.'),
 ('boating','Floaty McFloatface','Own a raft or boat.'),
 ('scammed','I Can Fix This Deal','Purchase something suspicious enough to regret.'),
 ('portal','Reality Has Left the Chat','Own a portal gun.'),
 ('rich','Coin Collector, Not Investor','Carry 5,000 coins at once.'),
 ('broke','Financially Questionable','Have 10 or fewer coins.'),
 ('explorer','Cartography Enjoyer','Explore at least 500 tiles.'),
 ('island_hopper','Frequent Floater','Set foot on an outer island.'),
 ('craftsperson','Unlicensed Metallurgist','Attempt ten forge experiments.'),
 ('blast','Safety Goggles Optional','Get caught in a forge explosion.'),
 ('fashion','Drip Certified','Equip armour, a belt, and a ring.'),
 ('prestige','Square One Again','Prestige at least once.'),
 ('bad_day','Mildly Inconvenienced','Survive with fewer than 20 health points.'),
 ('geysir','Steam Powered Regret','Get scalded by a cracked geyser.'),
 ('magnets','Magnetic Personality','Investigate the magnetic field.'),
 ('mud','Mud Appreciation Society','Fall into a mud pit.'),
 ('glass','Barefoot Engineering','Investigate the glass beach.'),
 ('elevator','Going Down','Trust an obviously broken elevator.'),
 ('crater','Absolutely Normal Crater','Touch a suspicious glowing crater.'),
 ('odd_three','Professional Sightseer','Investigate three strange sites.'),
 ('odd_six','Curiosity Is Expensive','Investigate six strange sites.'),
 ('time_five','Apparently We Live Here','Spend 5 minutes playing. Get a life. Or do not.'),
 ('time_thirty','Clock Enthusiast','Spend 30 minutes of active gameplay.'),
 ('time_two_hours','Commitment Issues','Spend 2 hours inside this ridiculous game.'),
 ('waste_time','Professional Time Waster','Stand idle for 5 minutes. What an achievement.'),
 ('inspector','Code Violation Enthusiast','Have a run-in with the roaming building inspector.'),
 ('tourist','Unpaid Tour Guide','Talk to a thoroughly confused tourist.'),
 ('counterfeit','Unsolicited Sales Pitch','Meet the wandering counterfeit salesman.'),
 ('mechanic','Warranty Void','Talk to the itinerant mechanic.'),
 ('casino_broke','The House Always Wins','Lose at least 1,000 coins at the casino.'),
 ('stock_crash','Buy High, Sell Low','Sell shares at a loss. Financial genius.'),
 ('business','Corporate Overlord','Operate a profitable business. Absolutely no award money.'),
]
ACH_LOOKUP={a:(b,c) for a,b,c in ACHIEVEMENTS}
ach_toasts=[]
ach_view=False
ach_player=0
ach_page=0

def unlock_achievement(p,code):
 if code not in ACH_LOOKUP:return
 owned=p.setdefault('achievements',[])
 if code in owned:return
 owned.append(code)
 idx=next((i for i,q in enumerate(players) if q is p),0)
 title,desc=ACH_LOOKUP[code]
 ach_toasts.append({'title':f'P{idx+1}: {title}','desc':desc,'until':pygame.time.get_ticks()+4700})
 del ach_toasts[:-5]
 logs.append(f'ACHIEVEMENT P{idx+1}: {title} (reward: absolutely nothing)');del logs[:-7]

def check_achievements():
 for i,p in enumerate(players):
  if any(v.get('species')=='Money Tree' and v.get('owner',0)==i for v in orchards.values()):unlock_achievement(p,'money_tree')
  if p.get('housing',0)==0:unlock_achievement(p,'professional_homeless')
  if sum(p.get('fish_caught',{}).values()) or p.get('stats',{}).get('fish',0):unlock_achievement(p,'first_fish')
  if p.get('stats',{}).get('wood',0)>=25:unlock_achievement(p,'lumber')
  if p.get('stats',{}).get('stone',0)>=20:unlock_achievement(p,'stone')
  if p.get('stats',{}).get('monsters',0)>=1:unlock_achievement(p,'first_kill')
  if p.get('housing',0)>=1:unlock_achievement(p,'first_home')
  if p.get('treehouse',0):unlock_achievement(p,'treehouse')
  if p.get('igloo',0):unlock_achievement(p,'igloo')
  if p.get('raft',0) or p.get('boat',0):unlock_achievement(p,'boating')
  if p.get('fake_weapon_name'):unlock_achievement(p,'scammed')
  if p.get('portal_gun'):unlock_achievement(p,'portal')
  if p.get('wallet',0)>=5000:unlock_achievement(p,'rich')
  if p.get('wallet',0)<=10:unlock_achievement(p,'broke')
  if len(explored_sets[i])>=500:unlock_achievement(p,'explorer')
  tx,ty=int(p['x']//T),int(p['y']//T)
  if (tx>=240 or ty>=240) and 0<=tx<N and 0<=ty<N and terrain[ty][tx]!='water':unlock_achievement(p,'island_hopper')
  if p.get('armour') and p.get('belt') and p.get('ring'):unlock_achievement(p,'fashion')
  if p.get('prestige',0)>0:unlock_achievement(p,'prestige')
  if 0<p.get('hp',100)<20:unlock_achievement(p,'bad_day')
  if p.get('play_seconds',0)>=300:unlock_achievement(p,'time_five')
  if p.get('play_seconds',0)>=1800:unlock_achievement(p,'time_thirty')
  if p.get('play_seconds',0)>=7200:unlock_achievement(p,'time_two_hours')
  if p.get('idle_seconds',0)>=300:unlock_achievement(p,'waste_time')

def draw_achievement_journal():
 shade=pygame.Surface((W,H),pygame.SRCALPHA);shade.fill((4,9,19,231));screen.blit(shade,(0,0))
 pygame.draw.rect(screen,(28,43,59),(100,44,920,636),border_radius=17)
 pygame.draw.rect(screen,(122,166,187),(100,44,920,636),2,border_radius=17)
 p=players[ach_player];owned=set(p.get('achievements',[]))
 screen.blit(big.render(f'ACHIEVEMENTS  -  PLAYER {ach_player+1}   ({len(owned)}/{len(ACHIEVEMENTS)})',True,(247,215,125)),(135,69))
 screen.blit(small.render(f'F4 / ESC close | Left/Right or 1-4 player | PgUp/PgDn pages ({ach_page+1}/{(len(ACHIEVEMENTS)+29)//30}) | No rewards.',True,(189,207,219)),(135,107))
 for j,(code,title,description) in enumerate(ACHIEVEMENTS[ach_page*30:(ach_page+1)*30]):
  col=j//10;row=j%10;x=125+col*302;y=144+row*51
  is_unlocked=code in owned
  if is_unlocked:pygame.draw.rect(screen,(42,77,71),(x-6,y-3,291,46),border_radius=6)
  title_line=('★ ' if is_unlocked else '○ ')+title
  desc_line=description if is_unlocked else 'LOCKED: '+description
  if len(title_line)>30:title_line=title_line[:28]+'...'
  if len(desc_line)>39:desc_line=desc_line[:36]+'...'
  screen.blit(small.render(title_line,True,(252,218,136) if is_unlocked else (145,163,179)),(x,y))
  screen.blit(small.render(desc_line,True,(184,224,212) if is_unlocked else (125,141,153)),(x+4,y+23))

def draw_achievement_toast():
 now=pygame.time.get_ticks()
 ach_toasts[:]=[a for a in ach_toasts if a['until']>now]
 for j,item in enumerate(ach_toasts[-3:]):
  x=W-362;y=245+j*80
  pygame.draw.rect(screen,(27,44,59),(x,y,342,72),border_radius=10)
  pygame.draw.rect(screen,(237,195,98),(x,y,342,72),2,border_radius=10)
  screen.blit(font.render('★ '+item['title'],True,(250,220,135)),(x+12,y+9))
  screen.blit(small.render(item['desc'][:51],True,(218,231,231)),(x+14,y+38))

# v55: Constructible, connected machines. All resources and power are in-game only.
# Generation/consumption is calculated each active second; this is intentionally a
# small, deterministic local-grid model rather than a full electrical simulator.
MACHINES={
 'solar panel':{'era':5,'cost':{'glass':7,'wiring':6,'circuits':2,'ingot':3},'gen':5,'use':0},
 'wind turbine':{'era':3,'cost':{'planks':5,'gears':3,'ingot':4,'wiring':2},'gen':3,'use':0},
 'fuel generator':{'era':3,'cost':{'ingot':6,'gears':4,'scrap':6,'wiring':3},'gen':9,'use':0},
 'battery bank':{'era':4,'cost':{'ingot':5,'wiring':6,'circuits':2,'glass':2},'gen':0,'use':0},
 'water purifier':{'era':4,'cost':{'glass':4,'wiring':3,'gears':2,'concrete':2},'gen':0,'use':3},
 'electric furnace':{'era':4,'cost':{'bricks':6,'concrete':3,'wiring':4,'gears':3},'gen':0,'use':5},
 'irrigation pump':{'era':4,'cost':{'gears':4,'wiring':4,'concrete':3},'gen':0,'use':2},
 'security floodlight':{'era':4,'cost':{'glass':3,'wiring':4,'ingot':2},'gen':0,'use':2},
 'weather station':{'era':5,'cost':{'glass':3,'wiring':4,'circuits':3},'gen':0,'use':1},
}
machine_states={};machine_clock=0.0
if isinstance(data,dict):
 machine_states.update({str(k):v for k,v in data.get("machine_states",{}).items() if isinstance(v,dict)})
 machine_clock=max(0.0,min(1.0,float(data.get("machine_clock",0))))

def machine_at(p):
 found=[]
 for a,b,kind in structures:
  if kind.startswith('built:'):
   name=kind.split(':')[1]
   if name in MACHINES and near(p,a,b,2.3):found.append((math.hypot(p['x']-(a+.5)*T,p['y']-(b+.5)*T),a,b,name))
 return min(found,default=None)

def machine_options(p):
 result=machine_at(p)
 if not result:return ['No nearby machines']
 _,x,y,name=result;state=machine_states.setdefault(f'{x},{y}',{'on':True,'condition':100,'fuel':0,'progress':0})
 return [f'{name.upper()} | {"ON" if state["on"] else "OFF"} | {state["condition"]}% condition',
         'Switch power ON/OFF','Repair (2 scrap, 1 ingot)','Refuel generator (2 firewood)',
         f'Inspect: fuel {state.get("fuel",0)}, progress {int(state.get("progress",0))}s']

def machine_choose(p,k):
 result=machine_at(p)
 if not result:msg('No nearby machine.');return
 _,x,y,name=result;state=machine_states.setdefault(f'{x},{y}',{'on':True,'condition':100,'fuel':0,'progress':0})
 if k==1:state['on']=not state['on'];msg(name.title()+' switched '+('ON' if state['on'] else 'OFF'))
 elif k==2:
  cost={'scrap':2,'ingot':1}
  if has_construction(p,cost):spend_construction(p,cost);state['condition']=min(100,state['condition']+45);msg('Repaired '+name+'.')
 elif k==3:
  if name!='fuel generator':msg('This machine does not use firewood.')
  elif has_construction(p,{'firewood':2}):spend_construction(p,{'firewood':2});state['fuel']+=45;msg('Generator has 45 more seconds of fuel.')
 else:msg(name.title()+f': condition {state["condition"]}%, stored fuel {state.get("fuel",0)}, progress {int(state.get("progress",0))}s.')

def tick_machines(seconds):
 # Machines connect when within 8 world tiles; battery banks can buffer energy.
 nodes=[]
 for x,y,kind in structures:
  if not kind.startswith('built:'):continue
  name=kind.split(':')[1]
  if name not in MACHINES:continue
  state=machine_states.setdefault(f'{x},{y}',{'on':True,'condition':100,'fuel':0,'progress':0,'charge':0})
  nodes.append((x,y,name,state))
 visited=set()
 for idx,node in enumerate(nodes):
  if idx in visited:continue
  group=[];stack=[idx];visited.add(idx)
  while stack:
   a=stack.pop();group.append(nodes[a]);ax,ay,_,_=nodes[a]
   for j,(bx,by,_,_) in enumerate(nodes):
    if j not in visited and (ax-bx)**2+(ay-by)**2<=64:
     visited.add(j);stack.append(j)
  batteries=[st for x,y,n,st in group if n=='battery bank' and st.get('on',True) and st['condition']>0]
  power=0
  for x,y,n,st in group:
   if not st.get('on',True) or st['condition']<=0:continue
   if n=='solar panel':power+=1 if weather in ('Storm','Rain','Snow','Cloudy') else 5
   elif n=='wind turbine':power+=5 if weather in ('Storm','Windy') else 3
   elif n=='fuel generator' and st.get('fuel',0)>0:
    power+=9;st['fuel']=max(0,st['fuel']-seconds)
   if n in ('solar panel','wind turbine','fuel generator') and random.random()<.003*seconds:st['condition']=max(0,st['condition']-1)
  available=power+sum(min(st.get('charge',0),4) for st in batteries)
  consumers=sorted([(x,y,n,st) for x,y,n,st in group if MACHINES[n]['use']>0],key=lambda a:(a[2]!='security floodlight',a[2]))
  spent=0
  for x,y,n,st in consumers:
   need=MACHINES[n]['use']
   st['powered']=False
   if not st.get('on',True) or st['condition']<=0 or available<need:continue
   st['powered']=True
   available-=need;spent+=need;st['progress']=st.get('progress',0)+seconds
   period={'water purifier':25,'electric furnace':35,'irrigation pump':40,'security floodlight':999999,'weather station':65}[n]
   if st['progress']>=period:
    st['progress']-=period
    if n=='water purifier':shared_items['water_bottles']=shared_items.get('water_bottles',0)+1;msg('Purifier delivered a bottle of clean water.')
    elif n=='electric furnace':shared_items['ingot']=shared_items.get('ingot',0)+1;msg('Electric furnace produced a metal ingot.')
    elif n=='irrigation pump':shared_items['food']=shared_items.get('food',0)+1;msg('Irrigation helped grow food.')
    elif n=='weather station':msg('Weather station reports: '+weather+'. Probably accurate.')
   if random.random()<.008*seconds:st['condition']=max(0,st['condition']-1)
  battery_draw=max(0,spent-power)
  for st in batteries:
   draw=min(st.get('charge',0),battery_draw);st['charge']=st.get('charge',0)-draw;battery_draw-=draw
  surplus=max(0,power-spent)
  for st in batteries:
   fill=min(100-st.get('charge',0),surplus);st['charge']=st.get('charge',0)+fill;surplus-=fill

def msg(s): logs.append(s); del logs[:-7]
def save():
 tmp=SAVE.with_suffix('.tmp');tmp.write_text(json.dumps({'world_size':N,'world_options':world_options,'unlocked_regions':unlocked_regions,'player_count':len(players),'players':[{k:v for k,v in p.items() if k not in ('menu','controller','cd','interact','invuln','dir','gear_held')} for p in players], 'structures':structures,'carving_art':carving_art,'pottery_wheel_built':pottery_wheel_built,'material_arts':material_arts,'caves':caves,'crops':crops,'orchards':orchards,'farm_soils':farm_soils,'shared_items':shared_items,'storage_boxes':storage_boxes,'gear_stock':gear_stock,'forge_built':forge_built,'forge_condition':forge_condition,'forge_skill':forge_skill,'forge_attempts':forge_attempts,'forge_discovered':forge_discovered,'season':season,'season_timer':season_timer,'weather':weather,'era':era,'knowledge':knowledge,'research_remainder':research_remainder,'workshops':workshops,'workshop_clock':workshop_clock,'event_clock':event_clock,'hazard_kind':hazard_kind,'hazard_seconds':hazard_seconds,'hazard_center':hazard_center,'stock_prices':stock_prices,'market_clock':market_clock,'regional_trade':regional_trade,'fantasy_quests':fantasy_quests,'machine_states':machine_states,'machine_clock':machine_clock,'settlement_treasury':settlement_treasury,'villagers':villagers,'ice_holes':sorted(ice_holes),'settlement_clock':settlement_clock,'food_age':food_age,'preservation_log':preservation_log,'army_training':army_training,'vehicles':vehicles,'settlement_log':settlement_log,'government':government,'civic':civic}));tmp.replace(SAVE)

# Each player has five carried item-type slots (stacks of the same item use one slot).
# Existing versions' loose items are migrated to shared supplies on first load.
ITEMS=('wood','stone','scrap','seed','food','ore','gems','snow_blocks','torches','life','water_bottles','tarps','sleeping_bags','firewood','hide','ingot','flux','crystal_dust','volatile_mineral','fiber','clay','sand','limestone','planks','lashings','nails','bricks','mortar','glass','concrete','wiring','gears','circuits','grain','beer','charcoal','leather','cloth','fuel','flint','copper_ore','iron_ore','coal','silver_ore','gold_ore','unlit_torches','bivy_sack','bivy_prototype','pillow','cushion','foam_pad','salt','preserved_food','smoked_food','pickles','cheese','butter','ice_blocks','milk')
ITEMS=ITEMS+tuple(item for item in EXT_MODS.items if item not in ITEMS)
for p in players:
 for item in EXT_MODS.items:p.setdefault(item,0)
RECIPES_EXTRA={
 'storage chest':(8,2,0,0),'large chest':(15,5,3,100),'supply bucket':(3,0,2,0),
 'backpack':(8,0,4,120),'woven satchel':(3,0,0,0),'expedition backpack':(12,2,6,250),'lantern':(3,1,2,80),'rain barrel':(8,3,2,0),
 'water filter':(4,3,4,100),'garden bed':(6,2,0,0),'camp stove':(7,3,2,150),
 'watchtower':(14,8,3,250),'rope bridge':(10,0,4,0),'sleeping cot':(6,0,3,0),
 'thermal coat':(3,0,6,180),'canteen':(2,1,3,100),'field kit':(4,2,4,160),
 'sail':(5,0,5,140),'pickaxe':(5,4,2,140),'axe':(7,1,2,140),
 'map beacon':(7,3,4,200),'solar lamp':(4,2,3,200)}

# Construction supplies are made from resources found in the world, not sold as finished buildings.
# (name, required era, required inputs, output quantity)
MATERIAL_PROCESS=[
 ('Weave lashings',0,{'fiber':3},2,'lashings'),
 ('Saw planks',0,{'wood':4},3,'planks'),
 ('Fire bricks',0,{'clay':3,'wood':2},2,'bricks'),
 ('Make mortar',1,{'limestone':2,'sand':2},3,'mortar'),
 ('Forge nails',1,{'ingot':1,'scrap':1},5,'nails'),
 ('Make glass',2,{'sand':4,'limestone':1,'wood':2},2,'glass'),
 ('Mix concrete',3,{'stone':3,'limestone':2,'sand':2},4,'concrete'),
 ('Machine gears',3,{'ingot':2,'scrap':2},2,'gears'),
 ('Draw wiring',4,{'ingot':1,'scrap':3},3,'wiring'),
 ('Assemble circuits',5,{'wiring':2,'scrap':3,'crystal_dust':1},2,'circuits'),
]
# Every free-placement structure has realistic-ish supporting supplies in addition
# to the original wood/stone/scrap/ore/gem recipe. Era restrictions still apply.
BUILD_EXTRAS={
 'bank':{'bricks':12,'mortar':8,'nails':16,'glass':4,'planks':8},
 'floor':{'planks':1},'wall':{'planks':1,'lashings':1},
 'roof':{'planks':2,'lashings':1},'door':{'planks':1,'lashings':1},
 'window':{'glass':1,'planks':1},'bridge':{'planks':3,'lashings':2},
 'campfire':{'clay':1},'storage chest':{'planks':3,'lashings':1},
 'reed hut':{'fiber':6,'lashings':3},'palisade':{'planks':3,'lashings':2},
 'watch fire':{'clay':2,'lashings':1},'stone altar':{'limestone':3},
 'market stall':{'planks':4,'nails':3,'fiber':2},
 'stone tower':{'bricks':6,'mortar':4,'nails':3},
 'drawbridge':{'planks':6,'nails':6,'gears':2},
 'barracks':{'bricks':5,'mortar':4,'planks':7,'nails':8},
 'clocktower':{'bricks':8,'mortar':6,'gears':3,'glass':2},
 'glasshouse':{'glass':10,'nails':8,'planks':7},
 'stone fountain':{'mortar':5,'bricks':3},
 'observatory':{'glass':8,'gears':4,'bricks':7,'mortar':5},
 'steam engine':{'gears':9,'nails':10,'bricks':5},
 'smokestack':{'bricks':12,'mortar':7,'concrete':6},
 'rail track':{'nails':6,'planks':5,'gears':1},
 'factory':{'concrete':20,'bricks':14,'gears':12,'nails':20,'glass':6},
 'electric lamp':{'wiring':3,'glass':2,'nails':2},
 'radio mast':{'concrete':9,'wiring':8,'gears':3},
 'water pump':{'gears':6,'wiring':4,'concrete':5},
 'hangar':{'concrete':16,'nails':24,'glass':7,'wiring':5},
 'solar array':{'glass':12,'wiring':12,'circuits':5},
 'data tower':{'concrete':13,'wiring':15,'circuits':10},
 'drone pad':{'concrete':16,'wiring':8,'circuits':6},
 'neon beacon':{'glass':8,'wiring':7,'circuits':4},
 'rift arch':{'concrete':20,'circuits':12,'wiring':18,'glass':10},
 'energy pylon':{'concrete':9,'circuits':10,'wiring':12},
 'hover platform':{'concrete':17,'circuits':14,'gears':8},
 'rift monument':{'concrete':24,'circuits':18,'glass':16,'wiring':18},
}
# The traditional builder menu and owned housing/businesses need the same supplies.
LEGACY_EXTRAS={'woven satchel':{'fiber':6,'lashings':2},'backpack':{'leather':3,'cloth':2,'lashings':4},'expedition backpack':{'leather':6,'cloth':5,'nails':4,'lashings':6},'house':{'bricks':3,'planks':3,'nails':4},'tower':{'bricks':4,'mortar':3},
 'bench':{'planks':3,'lashings':2},'collector':{'clay':2,'lashings':2},
 'furniture':{'planks':3,'nails':2}}
HOUSING_EXTRAS={2:{'fiber':5,'lashings':2},3:{'planks':8,'nails':4,'bricks':3,'mortar':2},
 6:{'planks':12,'nails':9,'bricks':6,'mortar':4},
 7:{'planks':16,'nails':12,'bricks':10,'mortar':7,'glass':3},
 8:{'planks':25,'nails':20,'bricks':15,'mortar':10,'glass':6,'concrete':8,'wiring':4}}

def available_construction(p,key):
 return max(0,int(p.get(key,0)))+max(0,int(shared_items.get(key,0)))

def cost_text(costs):
 return ', '.join(f'{count} {key}' for key,count in costs.items() if count>0) or 'nothing'

def has_construction(p,costs):
 missing={key:count-available_construction(p,key) for key,count in costs.items() if available_construction(p,key)<count}
 if missing:msg('Missing building materials: '+cost_text(missing));return False
 return True

def spend_construction(p,costs):
 # Called only after a successful has_construction check; use the player's pack first.
 for key,amount in costs.items():
  taken=min(amount,max(0,int(p.get(key,0))))
  p[key]=p.get(key,0)-taken
  remaining=amount-taken
  if remaining:
   shared_items[key]=shared_items.get(key,0)-remaining
   if shared_items[key]<=0:shared_items.pop(key,None)

def material_options():
 return [f'{title} ({ERAS[req]}): {cost_text(inputs)} -> {amount} {product}'
         for title,req,inputs,amount,product in MATERIAL_PROCESS]

def process_material(p,k):
 if not 0<=k<len(MATERIAL_PROCESS):return
 title,req,inputs,amount,product=MATERIAL_PROCESS[k]
 if era<req:msg(f'{title} requires {ERAS[req]} age.');return
 if not has_construction(p,inputs):return
 spend_construction(p,inputs)
 pickup(p,product,amount)
 xp(p,5)
 msg(f'{title}: created {amount} {product}. Materials processed, not purchased.')

def filled_slots(p):
 return sum(1 for item in ITEMS if p.get(item,0)>0)
def pack_capacity(p):
 return p.get('inventory_slots',5)+(2 if p.get('belt')=='Rope Belt' else 0)

def deposit(p,item,qty,store=shared_items):
 qty=min(qty,max(0,int(p.get(item,0))))
 if qty<=0:return False
 if item not in store and len(store)>=int(store.get('_max_types',999)):
  msg('Container is full. It cannot contain your ambitions.');return False
 p[item]-=qty;store[item]=store.get(item,0)+qty
 return True

def withdraw(p,item,qty,store=shared_items):
 if item not in ITEMS:return False
 if p.get(item,0)<=0 and filled_slots(p)>=pack_capacity(p):
  msg('All carry slots full. Deposit a different item first.');return False
 qty=min(qty,max(0,int(store.get(item,0))))
 if qty<=0:return False
 store[item]-=qty
 if store[item]==0:del store[item]
 p[item]=p.get(item,0)+qty
 return True

def pickup(p,item,qty):
 if item not in ITEMS:return
 if p.get(item,0)>0 or filled_slots(p)<pack_capacity(p):p[item]=p.get(item,0)+qty
 else:
  shared_items[item]=shared_items.get(item,0)+qty
  msg(f'Your pack was full. {qty} {item} went into shared supplies.')

def storage_at(p):
 return next((f'{x},{y}' for x,y,kind in structures if kind.startswith(('chest','bucket_store')) and near(p,x,y,1.6)),None)

# A shared stockpile is accessible to every player, while carried items obey pack slots.
# QTY is per-player UI state only; values are persisted harmlessly in older save schemas.
TRANSFER_AMOUNTS=('ONE','FIVE','ALL')
def transfer_qty(p, available):
 mode=p.get('transfer_mode','ALL')
 return min(available,1 if mode=='ONE' else 5 if mode=='FIVE' else available)

def carry_menu(p):
 result=[f'PACK  {filled_slots(p)}/{p.get("inventory_slots",5)} types | SHARED {sum(max(0,shared_items.get(it,0)) for it in ITEMS)} units',
         f'TRANSFER SIZE: {p.get("transfer_mode","ALL")}  (select to cycle 1 / 5 / ALL)',
         '--- DEPOSIT TO PARTY STOCKPILE ---']
 result += [f'Deposit {item} x{p.get(item,0)}' for item in ITEMS if p.get(item,0)>0]
 result += ['--- WITHDRAW FROM PARTY STOCKPILE ---']
 result += [f'Withdraw {item} x{shared_items.get(item,0)}' for item in ITEMS if shared_items.get(item,0)>0]
 result += ['--- TEAMMATES (NEARBY) ---']
 result += [f'Give {item} to nearest player' for item in ITEMS if p.get(item,0)>0]
 result += [f'Borrow {item} from nearest player' for item in ITEMS if any(q is not p and q.get(item,0)>0 for q in players)]
 result += ['Open nearby chest/bucket','Upgrade pack (+1 slot, 400c)','Back']
 return result

def container_menu(p):
 key=storage_at(p)
 if not key:return ['No chest or bucket nearby','Back']
 store=storage_boxes.setdefault(key,{'_max_types':12})
 entries=[f'Storage {sum(1 for k,v in store.items() if k != "_max_types" and v>0)}/{store.get("_max_types",12)} types',
          f'TRANSFER SIZE: {p.get("transfer_mode","ALL")}  (select to cycle 1 / 5 / ALL)']
 entries += [f'Store {item} x{p.get(item,0)}' for item in ITEMS if p.get(item,0)>0]
 entries += [f'Take {item} x{store.get(item,0)}' for item in ITEMS if store.get(item,0)>0]
 entries += ['Back']
 return entries

def inventory_choice(p,i):
 name=p['menu'];opts=options(name,p)
 if not opts:return
 label=opts[min(p['selection'],len(opts)-1)]
 if label.startswith('TRANSFER SIZE:'):
  modes=TRANSFER_AMOUNTS;p['transfer_mode']=modes[(modes.index(p.get('transfer_mode','ALL'))+1)%3]
  msg('Transfer amount: '+p['transfer_mode'])
 elif label.startswith(('PACK ','Storage ','No chest','---')):msg(label)
 elif label.startswith('Deposit '):
  item=label.split()[1];qty=transfer_qty(p,p.get(item,0))
  if deposit(p,item,qty):msg(f'P{i+1} deposited {qty} {item} into shared supplies.')
 elif label.startswith('Withdraw '):
  item=label.split()[1];qty=transfer_qty(p,shared_items.get(item,0))
  if withdraw(p,item,qty):msg(f'P{i+1} withdrew {qty} {item} from shared supplies.')
 elif label.startswith(('Give ','Borrow ')):
  giving=label.startswith('Give ');item=label.split()[1]
  candidates=[(j,q) for j,q in enumerate(players) if j!=i and math.hypot(q['x']-p['x'],q['y']-p['y'])<180 and (giving or q.get(item,0)>0)]
  if not candidates:msg('No nearby teammate with whom to trade.')
  else:
   j,q=min(candidates,key=lambda jq:math.hypot(jq[1]['x']-p['x'],jq[1]['y']-p['y']))
   source,target=(p,q) if giving else (q,p)
   if not source.get(item,0):msg('No items available to transfer.')
   elif not target.get(item,0) and filled_slots(target)>=pack_capacity(target):msg('Recipient has no free pack slots.')
   else:
    qty=transfer_qty(p,source[item]);source[item]-=qty;target[item]=target.get(item,0)+qty
    msg(f'P{i+1} {"gave" if giving else "borrowed"} {qty} {item} {"to" if giving else "from"} P{j+1}.')
 elif label.startswith(('Store ','Take ')):
  key=storage_at(p)
  if key:
   store=storage_boxes.setdefault(key,{'_max_types':12});item=label.split()[1]
   qty=transfer_qty(p,p.get(item,0) if label.startswith('Store ') else store.get(item,0))
   if label.startswith('Store '):success=deposit(p,item,qty,store)
   else:success=withdraw(p,item,qty,store)
   if success:msg(f'P{i+1} {"stored" if label.startswith("Store ") else "took"} {qty} {item}.')
 elif label.startswith('Open nearby'):
  if storage_at(p):p['menu']='CONTAINER';p['selection']=0
  else:msg('Stand next to a chest or supply bucket.')
 elif label.startswith('Upgrade pack'):
  if p['inventory_slots']>=30:msg('30 slots is the maximum.')
  elif buy(p,400):p['inventory_slots']+=1;msg(f'Pack expanded to {p["inventory_slots"]} slots!')
 elif label=='Back':p['menu']=None;save();return
 if p['menu']:p['selection']=min(p['selection'],max(0,len(options(p['menu'],p))-1))
 save()

def craft_extra(p,kind,i):
 wood,stone,scrap,cost=RECIPES_EXTRA[kind]
 extras=LEGACY_EXTRAS.get(kind,{})
 if not has_construction(p,extras):return
 if any(p.get(r,0)<n for r,n in [('wood',wood),('stone',stone),('scrap',scrap),('wallet',cost)]):
  msg(f'Need {wood} wood, {stone} stone, {scrap} scrap, {cost} coins.');return
 if kind not in ('storage chest','large chest','supply bucket','woven satchel') and not (p.get('craft_bench') or bench_near(p)):
  msg('Advanced crafting requires a workbench.');return
 spend_construction(p,extras)
 for r,n in [('wood',wood),('stone',stone),('scrap',scrap),('wallet',cost)]:p[r]-=n
 x,y=tile(p)
 tag='chest' if kind in ('storage chest','large chest') else 'bucket_store' if kind=='supply bucket' else kind.replace(' ','_')
 if kind not in ('backpack','woven satchel','expedition backpack'):structures.append([x,y,tag+str(i+1)])
 if kind in ('storage chest','large chest','supply bucket'):
  storage_boxes[f'{x},{y}']={'_max_types':4 if kind=='supply bucket' else 24 if kind=='large chest' else 12}
 if kind in ('backpack','woven satchel','expedition backpack'):
  slots={'backpack':3,'woven satchel':2,'expedition backpack':5}[kind]
  p['inventory_slots']=min(30,p['inventory_slots']+slots)
 if kind=='lantern':p['torches']+=1
 if kind=='water filter':p['water_reserve']=p.get('water_reserve',0)+4
 if kind=='sleeping cot':p['home_comfort']+=12
 if kind in ('thermal coat','canteen','field kit','sail','pickaxe','axe','map beacon','solar lamp'):
  field=kind.replace(' ','_');p[field]=1
  if kind=='canteen':p['water_bottles']+=2
  if kind=='field kit':p['life']+=1
  if kind=='solar lamp':p['torches']+=1
 xp(p,18);msg(f'P{i+1} crafted {kind}. The inspector goose is impressed.')

# Migrate old saves into five carried slots; preserve excess in team supplies.
for _p in players:
 _p.setdefault('stats',{'wood':0,'stone':0,'fish':0,'monsters':0,'explore':0})
 _p.setdefault('quests_claimed',[])
 _p.setdefault('inventory_slots',5)
 for _item in ITEMS:
  if filled_slots(_p)<=pack_capacity(_p):break
  if _p.get(_item,0)>0:
   shared_items[_item]=shared_items.get(_item,0)+_p[_item];_p[_item]=0

def coin(p,n): p['wallet']+=int(n*(1+.1*p['prestige']))
def xp(p,n):
 global knowledge,research_remainder
 research_remainder+=max(0,int(n))
 knowledge+=research_remainder//8
 research_remainder%=8
 p['xp']+=n
 while p['xp']>=p['level']*35:
  p['xp']-=p['level']*35; p['level']+=1; p['maxhp']+=5; p['hp']=p['maxhp']; msg('LEVEL UP! Your brain gained a wrinkle.')
def tile(p): return int(p['x']//T),int(p['y']//T)
def near(p,x,y,r=2): return math.hypot(p['x']-(x+.5)*T,p['y']-(y+.5)*T)<r*T

def crop_time():
 return 28 if season=='Spring' else 32 if season=='Summer' else 38 if season=='Autumn' else 50



# Persistent soil biology. Values range 0-100; no crop can thrive indefinitely without inputs.
def soil_at(key):
 if key not in farm_soils:farm_soils[key]={'water':60,'n':65,'p':65,'k':65,'last':time.time(),'disease':0}
 soil=farm_soils[key]
 for k in ('water','n','p','k','disease'):
  soil[k]=max(0,min(100,float(soil.get(k,0))))
 return soil

def farm_soil_tick():
 now=time.time()
 planted=set(crops)|set(orchards)
 for key in planted:
  soil=soil_at(key)
  hours=min(72,max(0,now-soil.get('last',now))/3600)
  soil['last']=now
  if not hours:continue
  # Rain is useful, heat and plant uptake cause drying. One tick of care is not permanent.
  rainfall=(9 if weather in ('Rain','Storm') else 0)*hours
  drying=(3.5 if weather=='Heatwave' else 2.0 if season=='Summer' else 1.2)*hours
  soil['water']=max(0,min(100,soil['water']+rainfall-drying))
  plant=orchards.get(key)
  nrate=0.55 if plant and plant.get('species')=='Money Tree' else 0.30
  soil['n']=max(0,soil['n']-hours*nrate)
  soil['p']=max(0,soil['p']-hours*.18)
  soil['k']=max(0,soil['k']-hours*.20)
  if plant:
   health=plant.get('health',100)
   dryness=soil['water']<20
   deficiency=min(soil['n'],soil['p'],soil['k'])<15
   if dryness or deficiency:
    health-=hours*(3 if plant.get('species')=='Money Tree' else 1.8)
   elif soil['water']>35 and min(soil['n'],soil['p'],soil['k'])>30:
    health+=hours*.22
   plant['health']=max(0,min(100,health))
  elif key in crops and (soil['water']<12 or soil['n']<8):
   # Crops suffer heavily under severe soil stress.
   soil['disease']=min(100,soil['disease']+hours*2)

def soil_good(key):
 q=soil_at(key)
 return q['water']>=25 and min(q['n'],q['p'],q['k'])>=18 and q['disease']<85

def soil_report(key):
 q=soil_at(key)
 return f"moisture {q['water']:.0f}, N {q['n']:.0f}, P {q['p']:.0f}, K {q['k']:.0f}, disease {q['disease']:.0f}"

# Persistent player-planted orchards. Plantable anywhere on unlocked dry, empty land.
def orchard_plant(p,species,owner):
 x,y=tile(p);key=f'{x},{y}'
 if not (0<=x<N and 0<=y<N) or not land_available(x,y) or terrain[y][x]=='water':msg('Plant on unlocked dry land.');return False
 if key in orchards or key in crops or any(a==x and b==y for a,b,_ in structures):msg('This spot is already occupied.');return False
 if any(math.hypot(x-a,y-b)<1.5 for _,a,b,_ in places):msg('Too close to a village building.');return False
 orchards[key]={'pos':[x,y],'species':species,'owner':owner,'planted':time.time(),'harvested':0,'health':100,'pruned':0};soil_at(key)
 return True

MONEY_TREE_GROW_SECONDS=24*60*60  # a full real-world day before the first harvest
MONEY_TREE_REGROW_SECONDS=12*60*60  # twelve real-world hours between cash harvests

def orchard_ready(tree):
 age=time.time()-tree.get('planted',time.time())
 last=time.time()-tree.get('harvested',0)
 species=tree.get('species','Apple')
 if tree.get('health',100)<40 or not soil_good(f"{tree['pos'][0]},{tree['pos'][1]}"):return False
 if species=='Herbs':return age>=55 and last>=45
 if species=='Money Tree':return age>=MONEY_TREE_GROW_SECONDS and (not tree.get('harvested',0) or last>=MONEY_TREE_REGROW_SECONDS)
 if season=='Winter':return False
 return age>=150 and last>=95 and (season in ('Summer','Autumn') or species=='Pear')

def orchard_decay():
 farm_soil_tick()
 now=time.time()
 for tree in orchards.values():
  last=tree.get('last_care',now);dt=min(3600,max(0,now-last));tree['last_care']=now
  if season=='Winter' and tree['species'] not in ('Money Tree','Herbs'):continue
  risk=.0003 if weather in ('Rain','Storm') else .00008
  if tree['species']=='Money Tree':risk*=1.5
  if tree.get('pruned',0) and now-tree['pruned']<500:risk*=.5
  if random.random()<min(.25,risk*dt):tree['health']=max(10,tree.get('health',100)-random.randint(2,8))

def seasonal_weather():
 table={'Spring':['Sunny','Rain','Rain','Fog','Storm'],'Summer':['Sunny','Sunny','Heatwave','Rain','Storm'],'Autumn':['Sunny','Fog','Rain','Storm','Windy'],'Winter':['Sunny','Fog','Snow','Snow','Storm']}
 return random.choice(table.get(season,['Sunny']))

def tile_color(kind):
 base=COL[kind]
 if season=='Winter':
  winter={'grass':(210,220,232),'forest':(180,193,205),'sand':(230,231,235),'rock':(150,155,162),'path':(198,198,205),'water':(125,165,205)}
  return winter.get(kind,base)
 if season=='Autumn':
  autumn={'grass':(130,133,78),'forest':(146,92,43),'sand':(210,184,120),'rock':(117,110,103),'path':(168,136,92),'water':(64,126,166)}
  return autumn.get(kind,base)
 if season=='Spring':
  spring={'grass':(84,166,84),'forest':(43,120,63),'water':(71,143,191)}
  return spring.get(kind,base)
 return base

def death(p,i):
 p['aboard']=False;p['inside']=False;p['cave_tile']=None
 if p['life']>0:
  p['life']-=1; p['hp']=p['maxhp']; p['invuln']=4; msg(f'P{i+1}: Life saver activated! Death got ratioed.'); return
 if world_options['mode']=='Creative':
  p['hp']=p['maxhp'];return
 lost=p['wallet']//2;p['wallet']-=lost
 for k in ('wood','stone','food','seed','scrap','ore','ingot','flint','coal','torches'):
  p[k]=max(0,p.get(k,0)-p.get(k,0)//3)
 p['x'],p['y']=((p['home_tile'][0]+.5)*T,(p['home_tile'][1]+.5)*T) if p['home_tile'] and p['housing']>=2 else (120*T,120*T); p['hp']=p['maxhp']; p['invuln']=4
 msg(f'P{i+1} died! Lost {lost} coins and supplies. Skill issue.')

def menu_for(p,name):
 p['menu']=name; p['selection']=0

def use_hotbar(p,i,slotno):
 p['hotbar_selection']=slotno
 if slotno==0:
  if p['food']<=0:msg('No food. Your stomach submitted a complaint.');return
  p['food']-=1;p['hunger']=min(100,p.get('hunger',90)+45);p['hp']=min(p['maxhp'],p['hp']+30);p['energy']=min(100,p['energy']+25);msg(f'P{i+1} ate food. The chef was a raccoon.')
 elif slotno==1:
  water_action(p,i)
 elif slotno==2:
  if p['life']>0:msg(f'P{i+1} has {p["life"]} life saver(s). They activate automatically.')
  else:msg('No life savers. Avoid becoming monster lunch.')
 elif slotno==3:
  if p.get('firewood',0) and campfire_near(p):msg('Campfire has fuel. Stay close for warmth.')
  else:msg('Find a campfire and stock firewood to stay warm.')
 else:menu_for(p,'INVENTORY')

def cache_action(p,i):
 for x,y in supply_caches:
  if near(p,x,y,1.1):
   key=f'{x},{y}'
   if key in p['caches_found']:msg('Already searched this cache. The squirrels cleaned it out.');return True
   p['caches_found'].append(key)
   loot=random.choice(['food','wood','stone','scrap','ore','gems'])
   qty=random.randint(1,4) if loot!='gems' else 1
   pickup(p,loot,qty);gain=random.randint(25,130);coin(p,gain);xp(p,12)
   msg(f'P{i+1} found a supply cache: {qty} {loot} and {gain} coins!')
   save();return True
 return False

def wildlife_action(p,i):
 global knowledge
 for key,tree in orchards.items():
  x,y=tree['pos'];sx=x*T+ox;sy=y*T+oy
  if not (-30<sx<W+30 and -30<sy<H+30):continue
  species=tree['species'];health=tree.get('health',100)
  if species=='Herbs':
   pygame.draw.circle(screen,(68,149,67),(sx+20,sy+22),9);continue
  pygame.draw.rect(screen,(103,67,42),(sx+17,sy+20,6,19))
  canopy=(194,155,38) if species=='Money Tree' else (86,115,66) if health<35 else (48,135,67)
  pygame.draw.circle(screen,canopy,(sx+20,sy+16),15)
  if orchard_ready(tree):
   color=(244,195,44) if species=='Money Tree' else (233,69,53) if species in ('Apple','Peach') else (201,190,81) if species=='Pear' else (121,72,169)
   for dx,dy in ((-7,-1),(5,3),(1,-8)):
    if species=='Money Tree':
     # Banknotes hang on little stems, rather than resembling fruit.
     px=int(sx+20+dx);py=int(sy+16+dy)
     pygame.draw.line(screen,(87,65,31),(px,py-5),(px,py),1)
     pygame.draw.rect(screen,(83,185,95),(px-5,py,11,6))
     pygame.draw.line(screen,(27,93,41),(px-4,py+2),(px+4,py+2),1)
    else:pygame.draw.circle(screen,color,(sx+20+dx,sy+16+dy),3)
 for ax,ay,kind in WILDLIFE:
  if not near(p,ax,ay,1.5):continue
  ident=f'{ax},{ay}'
  if ident in p.get('animal_visits',[]):
   msg(f'{kind.title()} has already met you. It needs personal space.');return True
  p.setdefault('animal_visits',[]).append(ident)
  result=random.random()
  if kind=='turtle':
   knowledge+=12;xp(p,8);msg(f'P{i+1} observed a turtle. +12 research. It taught you absolutely nothing quickly.')
  elif result<.45:
   if kind in ('deer','boar') and p.get('weapon',0)>0:
    pickup(p,'hide',random.randint(1,3));pickup(p,'food',1);xp(p,6);msg(f'P{i+1} hunted a {kind} and collected hide and food.')
   else:
    pickup(p,'food',2);xp(p,6);msg(f'P{i+1} found food near a {kind}. Nobody knows what was in that sandwich.')
  elif result<.8:
   knowledge+=16;xp(p,9);msg(f'P{i+1} studied a {kind}. +16 research. Science now has antlers.')
  else:
   p['energy']=max(0,p['energy']-10);msg(f'The {kind} chased P{i+1} into a bush. -10 energy. Embarrassing.')
  save();return True
 return False

def contract_options(p):
 completed=int(p.get('contract_rank',0))
 rows=[]
 for j in range(3):
  title,item,amount,reward=CONTRACT_TYPES[(completed+j)%len(CONTRACT_TYPES)]
  rows.append(f'{title}: deliver {amount} {item} for {reward}c')
 return rows+['Contracts rotate when completed; resources come from your carried inventory']

def island_event():
 global hazard_kind,hazard_seconds,hazard_center
 choices=['earthquake','strange_fog','lightning_storm','merchant_strike','animal_stampede','quiet_day']
 hazard_kind=random.choice(choices)
 hazard_seconds=45 if hazard_kind not in ('quiet_day','merchant_strike') else 28
 # Target a party-adjacent sector, so the event can actually matter.
 target=random.choice(players);tx,ty=tile(target)
 hazard_center=[min(N-1,max(0,tx+random.randint(-5,5))),min(N-1,max(0,ty+random.randint(-5,5)))]
 texts={'earthquake':'EARTHQUAKE! The ground shakes; exposed travelers risk falling debris.',
        'strange_fog':'STRANGE FOG rolls in. Navigation slows and thirst rises.',
        'lightning_storm':'LIGHTNING STORM! Avoid open ground or shelter indoors.',
        'merchant_strike':'MERCHANT STRIKE! All shady dealers have closed temporarily.',
        'animal_stampede':'ANIMAL STAMPEDE! Wildlife moves through the region.',
        'quiet_day':'An eerie calm settles across the islands. The seagulls are organizing.'}
 msg('WORLD EVENT: '+texts[hazard_kind])

def oddity_action(p,i):
 global weather
 for name,x,y in ODDITIES:
  if not near(p,x,y,1.8):continue
  last=p.setdefault('oddities_cooldowns',{}).get(name,0)
  if time.time()-last<90:
   msg(f'{name}: Nothing changed. Come back later; the weirdness is on cooldown.');return True
  p['oddities_cooldowns'][name]=time.time()
  if name not in p.setdefault('oddities_seen',[]):p['oddities_seen'].append(name)
  if len(p['oddities_seen'])>=3:unlock_achievement(p,'odd_three')
  if len(p['oddities_seen'])>=6:unlock_achievement(p,'odd_six')
  if name=='SINKHOLE':
   p['energy']=max(0,p['energy']-random.randint(12,27));msg('The ground drops! You scramble out, exhausted.')
  elif name=='GIANT FOOTPRINT':msg('A gigantic footprint points toward the sea. Whatever made it is still out there.')
  elif name=='CROOKED SIGN':msg('CROOKED SIGN: "SAFE SHORTCUT" points directly into the water. Suspicious.')
  elif name=='CRACKED GEYSER':
   p['hp']=max(1,p['hp']-random.randint(8,17));p['thirst']=max(0,p['thirst']-9)
   unlock_achievement(p,'geysir');msg('The geyser erupts! Hot steam burns your hands and dries you out. Great idea.')
  elif name=='MAGNETIC FIELD':
   p['weapon_condition']=max(0,p.get('weapon_condition',100)-random.randint(8,22))
   unlock_achievement(p,'magnets');msg('Your metal equipment sticks to a magnetic rock. Weapon durability damaged.')
  elif name=='MUD PIT':
   p['energy']=max(0,p['energy']-random.randint(18,35));p['sprint']=max(0,p.get('sprint',100)-35)
   unlock_achievement(p,'mud');msg('You sink waist-deep in mud. Escape costs energy and sprint stamina.')
  elif name=='GLASS BEACH':
   p['hp']=max(1,p['hp']-random.randint(3,11))
   unlock_achievement(p,'glass');msg('Sharp glass crunches beneath your boots. Your health suffers.')
  elif name=='LOST ELEVATOR':
   p['energy']=max(0,p['energy']-25);p['hp']=max(1,p['hp']-random.randint(5,14))
   unlock_achievement(p,'elevator');msg('The elevator goes down three feet then stops. The stairs have resigned.')
  elif name=='GLOWING CRATER':
   p['temperature']=min(105,p.get('temperature',65)+15)
   if random.random()<.5:
    p['hp']=max(1,p['hp']-13);msg('The crater gives off intense heat. You take damage.')
   else:msg('The crater hums in a key scientists have never heard. Your temperature rises.')
   unlock_achievement(p,'crater')
  save();return True
 return False

# Fictional market, with intentional downward drift and frequent abrupt crashes.
# No real-world assets, currency, or online transactions.
def update_stocks(dt):
 global market_clock
 market_clock+=dt
 if market_clock<3.5:return
 market_clock-=3.5
 for symbol in MARKET_NAMES:
  price=stock_prices[symbol]
  change=random.uniform(-.38,.26)
  if random.random()<.16:change-=random.uniform(.3,.7)
  stock_prices[symbol]=max(1,min(100000,round(price*(1+change))))
  history=stock_history[symbol];history.append(stock_prices[symbol]);del history[:-24]
 if random.random()<.25:msg('EXCHANGE: Flash crash! Brokers insist this is completely normal.')

def stock_options(p):
 lines=['Fictional shares fluctuate EVERY 3.5 seconds; trading fees are 12% per side.']
 for symbol in MARKET_NAMES:
  price=stock_prices[symbol];held=p.get('stocks',{}).get(symbol,0)
  lines.extend([f'{symbol} {price}c | own {held} | BUY 1 (+12% fee)',f'{symbol} {price}c | own {held} | SELL 1 (-12% fee)'])
 return lines

def do_stock_trade(p,k):
 if k==0:return
 symbol=MARKET_NAMES[(k-1)//2]
 buy_side=(k-1)%2==0
 price=stock_prices[symbol]
 holdings=p.setdefault('stocks',{})
 if buy_side:
  total=math.ceil(price*1.12)
  if p['wallet']<total:msg(f'Need {total} coins to buy {symbol}.');return
  p['wallet']-=total;holdings[symbol]=holdings.get(symbol,0)+1
  p.setdefault('stock_costs',{}).setdefault(symbol,[]).append(total)
  msg(f'Bought 1 {symbol} for {total} coins including fees. Good luck.')
 else:
  if holdings.get(symbol,0)<=0:msg('You have no shares to sell.');return
  proceeds=max(0,math.floor(price*.88));holdings[symbol]-=1;p['wallet']+=proceeds
  costs=p.setdefault('stock_costs',{}).setdefault(symbol,[])
  basis=costs.pop(0) if costs else price
  if proceeds<basis:unlock_achievement(p,'stock_crash')
  msg(f'Sold 1 {symbol} for {proceeds} coins. Net result: {proceeds-basis:+d} coins.')

def business_options(p):
 if not p.get('business_owned'):return ['Open dubious souvenir stand (2200c + 12 wood + 5 scrap)','A profitable business unlocks the inspector and mechanic.']
 return [f'Souvenir stand: net profit {p.get("business_profit",0)}c | daily overhead included',
         'Operate stand: pay 60c costs, earn a random sale (may lose money)',
         'Close business permanently (no refund)']

def casino_options(p):
 return ['House edge is enormous. These games use fictional coins only.',
         'Rigged coin flip: 100c wager (35% chance to win 180c)',
         'Triple dice: 250c wager (17% chance to win 750c)',
         'Glitter slots: 500c wager (6% chance to win 2200c)',
         'The Unfair Wheel: 1000c wager (3% chance to win 5000c)']

# Roaming NPCs: deliberately inconvenient rather than a repeatable source of rewards.
ROAMING_NPC_DEFS=[
 ('INSPECTOR',116,135,(243,197,79)),
 ('LOST TOURIST',132,116,(94,192,245)),
 ('COUNTERFEIT SALESMAN',137,131,(198,104,210)),
 ('WANDERING MECHANIC',109,114,(111,212,146)),
]
roaming_npcs=[{'name':name,'x':(x+.5)*T,'y':(y+.5)*T,'home':[x,y],
               'color':list(color),'direction':random.random()*math.tau,'turn':random.uniform(2,5),
               'cooldown':0.0} for name,x,y,color in ROAMING_NPC_DEFS]

def npc_unlocked(npc):
 name=npc['name']
 if name=='LOST TOURIST':return True
 if name=='COUNTERFEIT SALESMAN':return any(p.get('housing',0)>=2 or p.get('treehouse') for p in players)
 if name=='INSPECTOR':return any(p.get('housing',0)>=4 or p.get('business_profit',0)>=350 for p in players)
 if name=='WANDERING MECHANIC':return any(p.get('business_profit',0)>=350 for p in players)
 return False

def tick_roaming_npcs(seconds):
 if seconds<=0:return
 for npc in roaming_npcs:
  if not npc_unlocked(npc):continue
  npc['cooldown']=max(0,npc['cooldown']-seconds)
  npc['turn']-=seconds
  if npc['turn']<=0:
   npc['direction']=random.random()*math.tau
   npc['turn']=random.uniform(1.5,4.5)
  # Stay on walkable starter island and within walking distance of the starting village.
  nx=npc['x']+math.cos(npc['direction'])*32*seconds
  ny=npc['y']+math.sin(npc['direction'])*32*seconds
  tx,ty=int(nx//T),int(ny//T)
  hx,hy=npc['home']
  if 0<=tx<OLD_N and 0<=ty<OLD_N and terrain[ty][tx]!='water' and math.hypot(nx/T-hx,ny/T-hy)<18:
   npc['x'],npc['y']=nx,ny
  else:
   npc['direction']+=math.pi
   npc['turn']=1

def roaming_npc_action(p,i):
 for npc in roaming_npcs:
  if not npc_unlocked(npc):continue
  if math.hypot(p['x']-npc['x'],p['y']-npc['y'])>75:continue
  if npc['cooldown']>0:
   msg(f'{npc["name"]}: Not now. I have other people to inconvenience.');return True
  npc['cooldown']=24.0
  p['npc_encounters']=p.get('npc_encounters',0)+1
  name=npc['name']
  if name=='INSPECTOR':
   unlock_achievement(p,'inspector')
   if structures and random.random()<.6:
    fine=min(p['wallet'],random.randint(15,80));p['wallet']-=fine
    msg(f'BUILDING INSPECTOR: Unapproved window placement! P{i+1} fined {fine} coins.')
   else:msg('BUILDING INSPECTOR: Everything looks suspiciously legal. I will return.')
  elif name=='LOST TOURIST':
   unlock_achievement(p,'tourist');p['energy']=max(0,p['energy']-5)
   msg('TOURIST: Where is the beach? We are literally on an island. -5 energy answering questions.')
  elif name=='COUNTERFEIT SALESMAN':
   unlock_achievement(p,'counterfeit')
   msg('SALESMAN: My invisible bridge is HALF PRICE! No refunds. No bridge either.')
  else:
   unlock_achievement(p,'mechanic')
   if p.get('weapon',0) and p.get('weapon_condition',100)<70:
    # An unsolicited repair can go wrong. No free upgrading.
    damage=random.randint(3,14);p['weapon_condition']=max(0,p['weapon_condition']-damage)
    msg(f'MECHANIC: I fixed the squeak. Your weapon lost {damage} condition. Warranty void.')
   else:msg('MECHANIC: I diagnose a severe shortage of unnecessary moving parts.')
  save();return True
 return False

def draw_roaming_npcs(ox,oy):
 for npc in roaming_npcs:
  if not npc_unlocked(npc):continue
  x=int(npc['x']+ox);y=int(npc['y']+oy)
  if x<-65 or y<-65 or x>W+65 or y>H+65:continue
  color=tuple(npc['color'])
  pygame.draw.ellipse(screen,(21,43,42),(x-13,y+11,26,8))
  pygame.draw.rect(screen,color,(x-10,y-9,20,24),border_radius=5)
  pygame.draw.circle(screen,(234,193,149),(x,y-16),10)
  pygame.draw.rect(screen,(51,58,68),(x-11,y-28,22,6),border_radius=3)
  text=small.render(npc['name'],True,(250,233,171))
  pygame.draw.rect(screen,(23,36,46),(x-text.get_width()//2-5,y-53,text.get_width()+10,19),border_radius=4)
  screen.blit(text,(x-text.get_width()//2,y-52))

def all_encounters():
 return BUILTIN_ENCOUNTERS+EXT_MODS.encounters

def encounter_action(p,i):
 if p.get('menu') or p.get('inside') or p.get('aboard'):return False
 for site in all_encounters():
  x,y=site['position']
  if not land_available(x,y) or not near(p,x,y,1.7):continue
  # Keep per-player cooldowns in the save file.
  elapsed=p.setdefault('encounter_cooldowns',{}).get(site['id'],0)
  if time.time()<elapsed:
   msg(site['label']+': still recovering from your last visit.');return True
  p['encounter_id']=site['id'];p['menu']='ENCOUNTER';p['selection']=0
  msg('Encounter: '+site['label']+'. Pick an option.');return True
 return False

def encounter_choose(p,i,k):
 global weather
 site=next((a for a in all_encounters() if a['id']==p.get('encounter_id')),None)
 if site is None:return
 if not 0<=k<len(site['choices']):return
 option=site['choices'][k]
 p.setdefault('encounter_cooldowns',{})[site['id']]=time.time()+site['cooldown']
 effect=option['effect'];n=option['strength']
 if effect=='damage':p['hp']=max(1,p['hp']-n)
 elif effect=='exhaust':p['energy']=max(0,p['energy']-n)
 elif effect=='break_weapon':p['weapon_condition']=max(0,p.get('weapon_condition',100)-n)
 elif effect=='lose_coins':p['wallet']=max(0,p['wallet']-min(p['wallet'],n))
 elif effect=='storm':weather='Storm'
 elif effect=='teleport':
  x,y=tile(p);possible=[]
  for xx in range(max(0,x-n),min(N,x+n+1)):
   for yy in range(max(0,y-n),min(N,y+n+1)):
    if 2<math.hypot(xx-x,yy-y)<=max(3,n) and terrain[yy][xx]!='water' and land_available(xx,yy):
     if all(math.hypot((xx+.5)*T-q['x'],(yy+.5)*T-q['y'])<=310 for q in players if q is not p):possible.append((xx,yy))
  if possible:
   xx,yy=random.choice(possible);p['x']=(xx+.5)*T;p['y']=(yy+.5)*T
 msg('P'+str(i+1)+' / '+site['label']+': '+option['message'])
 p['menu']=None;p['encounter_id']='';save()

def action(p,i):
 if machine_at(p):menu_for(p,'MACHINE');return
 if encounter_action(p,i):return
 if roaming_npc_action(p,i):return
 if oddity_action(p,i):return
 if wildlife_action(p,i):return
 if cache_action(p,i):return
 if p.get('inside') and p.get('cave_tile'):
  menu_for(p,'MINE');return
 if p['menu'] or p.get('inside') or p.get('aboard'): return
 for lx,ly,kind in landmarks:
  if near(p,lx,ly,1.5):
   ident=f'{lx},{ly}'
   if ident in p['treasures']:msg('Already looted. The treasure chest is filing for bankruptcy.');return
   p['treasures'].append(ident)
   if kind=='CHEST':
    amount=random.randint(180,650);coin(p,amount);xp(p,30);msg(f'P{i+1} opened an ancient chest: {amount} coins! A skeleton demanded royalties.')
   else:
    pickup(p,'gems',random.randint(1,3));xp(p,55);msg(f'P{i+1} discovered a lost shrine! Gems and XP acquired. The statue winked.')
   save();return
 for name,dx,dy in shady_dealers:
  if near(p,dx,dy,2):
   if hazard_kind=='merchant_strike' and hazard_seconds>0:msg('SHOP CLOSED: Shady merchants are on strike. Even the scams have labor rights.');return
   menu_for(p,'SHADY');return
 if any(str(kind).startswith(('built:bank:', 'bank')) and near(p,bx,by,2.2) for bx,by,kind in structures):menu_for(p,'BANK');return
 if any(str(v).startswith('built:'+b+':') and near(p,x,y,2.6) for x,y,v in structures for b in PRESERVATION_BUILDINGS):menu_for(p,'PRESERVE');return
 if storage_at(p):menu_for(p,'CONTAINER');return
 if p['home_tile'] and near(p,*p['home_tile'],1.4):
  rest_at_shelter(p);return
 for name,x,y,_ in places:
  if shop_available(name) and near(p,x,y,2.2): menu_for(p,name); return
 x,y=tile(p); key=f'{x},{y}'
 if key in crops:
  if time.time()-crops[key]>=crop_time():
   del crops[key]; coin(p,random.randint(30,75)); xp(p,8); msg(f'P{i+1} harvested crops. Capitalism photosynthesized.')
  else: msg('Not ripe yet. The potato has a schedule.'); return
 if terrain[y][x]=='sand' and random.random()<.32:
  pickup(p,'salt',random.randint(1,2));msg('Gathered salt crust near the shore. Preserve food before it spoils.')
 if terrain[y][x]=='forest':
  if random.random()<.72:pickup(p,'fiber',random.randint(1,3));msg('Collected plant fibres for ropes and lashings.')
  amount=random.randint(1,3)+(2 if p.get('axe') else 0);pickup(p,'wood',amount);p['stats']['wood']+=amount;xp(p,3)
  if random.random()<.17:pickup(p,'scrap',1); msg(f'P{i+1} chopped wood. The tree filed a complaint.')
 elif terrain[y][x]=='rock':
  if random.random()<.50:pickup(p,'limestone',random.randint(1,2));msg('Mined limestone for mortar and concrete.')
  if random.random()<.38:pickup(p,'clay',1);msg('Found a pocket of workable clay.')
  amount=random.randint(1,3)+(2 if p.get('pickaxe') else 0);pickup(p,'stone',amount);p['stats']['stone']+=amount;xp(p,3)
  if random.random()<.28:pickup(p,'ore',1);msg(f'P{i+1} found valuable ore!')
  if random.random()<(.30 if p.get('pickaxe') else .18):pickup(p,'ingot',1);msg('Found a workable metal chunk while mining! +1 ingot.')
  if random.random()<.21:pickup(p,'flint',1);msg('Found a sharp piece of flint.')
  if random.random()<.24:pickup(p,'flux',1);msg('Collected flux mineral from the stone seam.')
  if random.random()<.055:pickup(p,'crystal_dust',1);msg('Found rare crystal grains! +1 crystal dust.')
  if random.random()<.065:pickup(p,'volatile_mineral',1);msg('Found unstable mineral fragments. Handle carefully near the forge!')
  elif random.random()<.05:pickup(p,'gems',1);msg(f'P{i+1} found a GEM! The rock had expensive fillings.')
  else:msg(f'P{i+1} mined stone. Geology is crying.')
 elif terrain[y][x]=='sand':
  pickup(p,'sand',random.randint(1,3));msg('Collected sand for glass, mortar and concrete.')
  if random.random()<.30:pickup(p,'clay',1);msg('Found clay under the beach sand.')
  if random.random()<.38:pickup(p,'scrap',1);msg('Found scrap metal. A seagull claims copyright.')
  n=random.randint(5,65); coin(p,n); xp(p,2); msg(f'P{i+1} searched beach: {n} coins. Sand sold separately.')
 else:
  if season=='Winter' and terrain[y][x] in ('grass','sand','path'):
   found=random.randint(1,2);pickup(p,'snow_blocks',found);xp(p,2);msg(f'P{i+1} packed {found} snow block(s). A future quinzhee approves.')
  else:
   n=random.randint(3,35)
   if random.random()<.2: msg(f'P{i+1} begged a shrub. It blocked you.')
   else: coin(p,n); xp(p,2); msg(f'P{i+1} found {n} coins. Suspiciously convenient.')

def cave_action(p,i):
 """Excavate a rocky shelter by hand or with a pickaxe; C enters/exits or digs."""
 if p.get('menu') or p.get('aboard'):
  msg('Put away menus and leave the boat before cave work.');return
 if p.get('inside'):
  if p.get('cave_tile'):
   p['inside']=False;p['cave_tile']=None
   msg(f'P{i+1} left the cave. Check whether night has ended.');save()
  else:msg('Leave your house using the interior key first.')
  return
 x,y=tile(p)
 nearby=[]
 for dx,dy in ((0,0),(1,0),(-1,0),(0,1),(0,-1)):
  xx,yy=x+dx,y+dy
  if 0<=xx<N and 0<=yy<N and land_available(xx,yy) and terrain[yy][xx]=='rock':
   nearby.append((xx,yy))
 if not nearby:
  msg('No rock face nearby. Find rocky terrain to carve a cave.');return
 xx,yy=min(nearby,key=lambda q:(q[0]-x)**2+(q[1]-y)**2)
 key=f'{xx},{yy}'
 data=caves.setdefault(key,dict(progress=0,stability=65,reinforced=False,depth=0,vein=0))
 if data['progress']>=5:
  p['inside']=True;p['cave_tile']=key
  msg(f'P{i+1} entered the cave. Monsters cannot reach you inside. C to leave.');save();return
 if p['energy']<8:
  msg('Too exhausted to dig. Eat or rest before excavating.');return
 # Excavation is costly even with a pickaxe; unskilled digging may injure you.
 p['energy']=max(0,p['energy']-(9 if p.get('pickaxe') else 16))
 if p.get('pickaxe') and p.get('weapon_condition',100)>0:p['weapon_condition']=max(0,p['weapon_condition']-1)
 p['cave_digs']=p.get('cave_digs',0)+1
 if random.random()<(.035 if p.get('pickaxe') else .095):
  damage=random.randint(4,13);p['hp']-=damage
  msg(f'Loose rocks fall! P{i+1} loses {damage} HP. Digging is not a free hobby.')
  if p['hp']<=0:death(p,i)
 else:
  data['progress']+=1
  msg(f'Cave excavation: {data["progress"]}/5. '+('You have opened a shelter entrance!' if data['progress']==5 else 'Keep digging.'))
 save()

def reinforce_cave(p,i):
 """Use wood and stone to support a finished cave; all players benefit."""
 if p.get('aboard') or p.get('inside'):msg('Reinforce the cave from outside.');return
 x,y=tile(p)
 choices=[(k,v) for k,v in caves.items() if v.get('progress',0)>=5 and math.hypot(int(k.split(',')[0])-x,int(k.split(',')[1])-y)<=1.6]
 if not choices:msg('Find an excavated cave entrance first.');return
 k,v=choices[0]
 if v.get('reinforced'):msg('This cave already has strong wooden supports.');return
 # Draw from personal and shared resources with existing construction mechanics.
 costs={'wood':8,'stone':4,'planks':3}
 if not has_construction(p,costs):
  msg('Cave supports need 8 wood, 4 stone, and 3 planks (personal or shared).');return
 spend_construction(p,costs)
 v['reinforced']=True;v['stability']=100
 msg('Cave reinforced with wooden props and stone bracing. Collapse risk greatly reduced.');save()

def shelter_name(p):
 if p.get('rental') and time.time()<p.get('rent_until',0):
  return 'Rented '+p['rental'].title()
 if p['housing']>0:return HOUSING[p['housing']]
 if p.get('cave_tile') and p.get('inside'):return 'Excavated Cave'
 if p.get('treehouse'):return 'Treehouse'
 if p.get('igloo'):return 'Igloo'
 if p.get('quinzee'):return 'Quinzee'
 if p.get('tree_tent'):return 'Tree Tent'
 if p.get('hammock'):return 'Hammock'
 if p.get('bedroll'):return 'Bedroll'
 return HOUSING[p['housing']]

# V67: furniture workshop. Shapes, materials, upholstery and finish combine into
# dozens of distinct variants. Recipe costs scale with the chosen materials.
FURN_SHAPES=('chair','table','stool','shelf','cot','bench','cabinet')
FURN_MATERIALS=('wood','stone','metal','reclaimed')
FURN_STYLES=('plain','carved','rustic','polished','painted')
FURN_FABRICS=('none','cloth','leather')
SLEEP_RECIPES={
 'bivy_prototype':{'cloth':2,'lashings':1,'tarps':1},
 'bivy_sack':{'cloth':9,'lashings':5,'leather':4,'tarps':3,'hide':2},
 'sleeping_bags':{'cloth':4,'fiber':5,'lashings':1},
 'pillow':{'cloth':2,'fiber':3},
 'cushion':{'cloth':2,'fiber':2},
 'foam_pad':{'cloth':2,'fiber':4,'leather':1},
 'carving_tool':{'wood':2,'ingot':1,'scrap':1},
 'bed_frame':{'planks':8,'nails':5,'wood':3},
 'mattress':{'cloth':5,'fiber':6,'lashings':2},
 'house_pillow':{'cloth':3,'fiber':4},
 'house_cushion':{'cloth':3,'fiber':3},
}
def comfort_score(p):
 shelter=20 if p.get('inside') or protected_home(p) else 10 if p.get('housing') or p.get('tree_tent') else 0
 # Sleeping bags provide insulation. A bivy is an optional weatherproof outer
 # shell, never an alternative sleeping bag. A bedroll can be used underneath.
 uses_bag=p.get('sleep_kit')=='sleeping_bags' and p.get('sleeping_bags',0)>0
 uses_roll=p.get('sleep_kit')=='bedroll' and p.get('bedroll',0)>0
 uses_bivy=uses_bag and p.get('bivy_on',False) and (p.get('bivy_sack',0)>0 or p.get('bivy_prototype',0)>0)
 professional=uses_bivy and p.get('bivy_sack',0)>0
 prototype=uses_bivy and not professional and p.get('bivy_prototype',0)>0
 prototype_working=prototype and not p.get('bivy_leak',False)
 bag=19 if uses_bag else 6 if uses_roll else 0
 accessories=10*bool(p.get('pillow'))+6*bool(p.get('cushion'))+12*bool(p.get('foam_pad'))+7*bool(p.get('blanket'))
 furniture=min(24,4*sum(1 for x,y,kind in structures if kind.startswith('built:custom-furn-') and math.hypot(x-p['x']/T,y-p['y']/T)<4))
 homebed=sum(1 for x,y,kind in structures if kind.startswith('built:bedroom-') and math.hypot(x-p['x']/T,y-p['y']/T)<5)
 bedroom=min(36,homebed*9) if (p.get('housing',0)>=2 or p.get('inside') or p.get('treehouse')) else 0
 # Bivy cuts rain infiltration and wind chill, but cannot replace insulation.
 # A small breathable-shell bonus reflects reduced convective heat loss.
 cold_penalty=(22 if p.get('temperature',65)<35 else 0)
 if professional and cold_penalty:cold_penalty=max(0,cold_penalty-9)
 elif prototype_working and cold_penalty:cold_penalty=max(0,cold_penalty-4)
 wet_penalty=12 if weather in ('Rain','Storm') and shelter==0 else 0
 if professional:wet_penalty=max(0,wet_penalty-11)
 elif prototype_working:wet_penalty=max(0,wet_penalty-5)
 wind_bonus=(5 if professional else 2 if prototype_working else 0) if shelter==0 else 0
 return max(0,min(100,20+shelter+bag+accessories+furniture+bedroom+wind_bonus-cold_penalty-wet_penalty))
def furniture_recipe(p):
 shape=p.get('craft_shape','chair');material=p.get('craft_material','wood')
 cost={'wood':3,'planks':2,'lashings':1} if material=='wood' else {'stone':6,'mortar':2} if material=='stone' else {'ingot':3,'nails':4,'scrap':2} if material=='metal' else {'scrap':5,'wood':1}
 if shape in ('table','cot','cabinet'):cost={k:v*2 for k,v in cost.items()}
 if p.get('craft_style')=='polished':cost['planks']=cost.get('planks',0)+2
 if p.get('craft_style')=='painted':cost['clay']=cost.get('clay',0)+2
 if p.get('craft_fabric')=='cloth':cost['cloth']=2
 if p.get('craft_fabric')=='leather':cost['leather']=2
 return cost
def furniture_options(p):
 return [f'Shape: {p.get("craft_shape","chair")}',f'Material: {p.get("craft_material","wood")}',f'Finish: {p.get("craft_style","plain")}',f'Upholstery: {p.get("craft_fabric","none")}',
         'Craft + place custom furniture: '+', '.join(f'{k} x{v}' for k,v in furniture_recipe(p).items()),
         'Craft improvised prototype bivy', 'Craft sleeping bag', 'Craft pillow', 'Craft cushion', 'Craft sleeping pad',
         f'Bivy outer shell: {"ON" if p.get("bivy_on") else "OFF"} {"[proper]" if p.get("bivy_sack") else "[prototype]" if p.get("bivy_prototype") else "[not owned]"}',
         f'Use sleeping bag for sleep {"[owned]" if p.get("sleeping_bags") else "[not owned]"}',
         f'Use bedroll for sleep {"[owned]" if p.get("bedroll") else "[not owned]"}',
         f'Sleep quality: {comfort_score(p)} / 100 (rest at shelter)',
         'Craft optional fine carving chisel', 'Place wooden bed frame', 'Place mattress', 'Place house pillow', 'Place house cushion',
         'Shape nearby wooden furniture (pressure craft)', 'Inspect shaping implements',
         f'Sanity: {int(p.get("sanity",75))}/100', 'Throw pottery on a wheel (3 clay, 1 water)', 'Build pottery wheel (wood 8, stone 4, lashings 2)',
         'Build firing kiln (bricks 5, stone 8, mortar 3)',
         'Fire unfired pottery (1 firewood)',
         'Prepare mineral glaze (sand 2, flux 1, clay 1)',
         'Glaze and refire a fired pot (1 glaze, 1 firewood)',
         'Melt raw sand into glass batch (sand 5, limestone 2, firewood 3)',
         'Shape hot glass (pressure session, needs glass batch)',
         'Make casting mold (clay 3, stone 2)',
         'Heat casting metal (ingot 3, firewood 2, mold needed)',
         'Cast hot metal (pressure session)',
         'Collect volcanic heat at deep cave (dangerous; crucible required)',
         'Build insulated crucible (ingot 4, stone 5, flux 2)',
         'Inspect fired pottery / glass / metal inventory', 'Craft proper weatherproof bivy sack (advanced materials)']
# Freehand art is stored per furniture tile, independently of furniture's original kind.
# Each mark is [local_x,local_y,brush_size]; coordinates are clamped to the 40px tile.
carving_art={str(k):[v for v in marks if isinstance(v,list) and len(v)==3][:1800]
             for k,marks in (data.get('carving_art',{}) if isinstance(data,dict) and isinstance(data.get('carving_art'),dict) else {}).items()
             if isinstance(marks,list)}
carving_session=None

def carving_implement(p):
 if p.get('carving_tool'):return ('Chisel',1)
 if p.get('axe'):return ('Axe',3)
 if p.get('pickaxe'):return ('Pickaxe',4)
 if p.get('flint',0):return ('Flint',2)
 if p.get('scrap',0):return ('Scrap',3)
 if p.get('stone',0):return ('Stone',4)
 return ('Improvised mark',2)

# V70: timed material-shaping instead of freehand drawing. Pressure and wheel
# speed are continuous inputs; fatigue, overpressure and sudden jerks cause cracks.
pottery_wheel_built=False
if isinstance(data,dict):pottery_wheel_built=bool(data.get('pottery_wheel_built',False))
# The entire workshop inventory is kept separately to preserve old saves.
material_arts=dict(data.get('material_arts',{})) if isinstance(data,dict) and isinstance(data.get('material_arts'),dict) else {}
material_arts.setdefault('kiln_built',False)
material_arts.setdefault('crucible_built',False)

def begin_shaping(p,i,kind,key='',tool=None):
 global carving_session
 tool=tool or ('Hands',2)
 carving_session=dict(player=i,kind=kind,key=key,tool=tool,pressure=0.0,
  applied=False,progress=0.0,stage=0,integrity=100.0,spin=0.65 if kind=='pottery' else 0.0,
  quality=0.0,marks=[],total={'pottery':4,'glass':6,'metal':5}.get(kind,5),failed=False)
 p['menu']=None
 msg(('Pottery wheel' if kind=='pottery' else 'Glassblowing' if kind=='glass' else 'Metal casting' if kind=='metal' else 'Wood shaping') + ': hold SPACE or left mouse to press; release to rest. UP/DOWN adjust speed/angle.')

def shaping_tick(dt):
 global carving_session
 if not carving_session:return
 st=carving_session;p=players[st['player']]
 speed=st['spin'] if st['kind'] in ('pottery','glass') else 0.65
 st['pressure']=max(0.0,min(1.0,st['pressure']+dt*(0.7 if st['applied'] else -0.9)))
 # The sweet spot moves slightly between stages. High pressure or high wheel
 # speed increases work but accelerates damage to the material.
 target=0.36+0.08*(st['stage']%3)
 pressure=st['pressure']
 if st['applied'] and pressure>0.10:
  work=dt*(0.40+speed)*max(0.18,1-abs(pressure-target)*1.3)
  st['progress']+=work
  st['quality']+=dt*max(0.0,1-abs(pressure-target)*2)
  if pressure>0.73:st['integrity']-=dt*(18+75*(pressure-.73))*max(1,speed)
  if st['kind'] in ('pottery','glass') and (speed>.9 or speed<.2):st['integrity']-=dt*14
  if st['kind']=='glass' and pressure>.65:st['integrity']-=dt*18
  if st['kind']=='metal' and pressure>.68:st['integrity']-=dt*22
  p['energy']=max(0,p['energy']-dt*0.9)
 elif not st['applied']:
  st['integrity']=min(100,st['integrity']+dt*0.5)
 if st['progress']>=1:
  st['stage']+=1;st['progress']=0.0
  st['integrity']=max(0,st['integrity']-random.uniform(1,4))
  if st['kind']=='wood':
   st['marks'].append([random.randint(6,33),random.randint(6,33),st['tool'][1]])
  if st['stage']>=st['total']:
   if st['kind']=='wood':
    carving_art.setdefault(st['key'],[]).extend(st['marks'])
    msg('Wood shaping finished. The finished object has your tool marks. Sanity +7.')
   else:
    product={'pottery':'unfired_pot','glass':'glass_vessel','metal':'cast_metal_part'}[st['kind']]
    shared_items[product]=shared_items.get(product,0)+1
    if st['kind']=='pottery':msg('Wet clay vessel formed. You must FIRE it in the kiln before use!')
    elif st['kind']=='glass':msg('Glass shaped and annealed. One glass vessel enters shared storage.')
    else:msg('Molten metal cast into a part. It has cooled and entered shared storage.')
   p['sanity']=min(100,p.get('sanity',75)+7);carving_session=None;save();return
 if st['integrity']<=0:
  if st['kind']=='wood':
   msg('CRACK! You pressed too hard and split the furniture. Your tool marks were lost.')
   # The existing furnishing remains, but damage is permanent until repaired.
   key=st['key'];shared_items['scrap']=shared_items.get('scrap',0)+1
  else:msg('CRAFT FAILED! The hot material cracked, slumped, or spilled. Your batch is lost.')
  p['sanity']=max(0,p.get('sanity',75)-5)
  carving_session=None;save()


# Real-world-inspired material processing; temperatures and lava handling are
# abstract game mechanics, not instructions for hazardous real-world experiments.
def material_art_cost(p,cost):
 if not has_construction(p,cost):return False
 spend_construction(p,cost)
 return True

def material_art_choose(p,i,k):
 if k==24:
  if material_arts['kiln_built']:msg('Your firing kiln is already built.');return
  if material_art_cost(p,{'bricks':5,'stone':8,'mortar':3}):
   material_arts['kiln_built']=True;msg('Firing kiln built. Wet pots can now be fired.');save()
 elif k==25:
  if not material_arts['kiln_built']:msg('Build a firing kiln first.');return
  if material_art_cost(p,{'unfired_pot':1,'firewood':1}):
   # Small risk of cracked ceramics during firing.
   if random.random()<.12:msg('Kiln disaster: the pot cracked while firing.')
   else:shared_items['fired_pot']=shared_items.get('fired_pot',0)+1;msg('Pottery hardened in the kiln!')
   save()
 elif k==26:
  if material_art_cost(p,{'sand':2,'flux':1,'clay':1}):
   shared_items['mineral_glaze']=shared_items.get('mineral_glaze',0)+1;msg('Mixed a mineral glaze. Apply it to a fired vessel, then refire.');save()
 elif k==27:
  if not material_arts['kiln_built']:msg('A firing kiln is required.');return
  if material_art_cost(p,{'fired_pot':1,'mineral_glaze':1,'firewood':1}):
   if random.random()<.20:msg('Glaze firing failed: the pot cracked or the glaze ran.')
   else:shared_items['glazed_pot']=shared_items.get('glazed_pot',0)+1;msg('A shiny glazed ceramic vessel!')
   save()
 elif k==28:
  if not material_arts['kiln_built']:msg('Build a kiln for glassmaking first.');return
  fuel={'firewood':3}
  if int(material_arts.get('volcanic_heat',0))>0:
   fuel={}
  if material_art_cost(p,{'sand':5,'limestone':2,**fuel}):
   if not fuel:material_arts['volcanic_heat']-=1
   if random.random()<.18:msg('Glass batch overheated or contained impurities: wasted ingredients.')
   else:shared_items['glass_batch']=shared_items.get('glass_batch',0)+1;msg('Prepared a hot glass batch. Shape it before use.')
   save()
 elif k==29:
  if not material_art_cost(p,{'glass_batch':1}):return
  begin_shaping(p,i,'glass',tool=('Blowpipe',2))
 elif k==30:
  if material_art_cost(p,{'clay':3,'stone':2}):
   shared_items['casting_mold']=shared_items.get('casting_mold',0)+1;msg('Created a reusable mold for metal castings.');save()
 elif k==31:
  if not forge_built:msg('Build a forge to heat metal.');return
  if available_construction(p,'casting_mold')<1:msg('Make a casting mold first.');return
  fuel={'firewood':2}
  if int(material_arts.get('volcanic_heat',0))>0:
   fuel={}
  if material_art_cost(p,{'ingot':3,**fuel}):
   if not fuel:material_arts['volcanic_heat']-=1
   shared_items['hot_metal_batch']=shared_items.get('hot_metal_batch',0)+1
   msg('Metal heated for casting. The mold remains reusable.');save()
 elif k==32:
  if not material_art_cost(p,{'hot_metal_batch':1}):return
  begin_shaping(p,i,'metal',tool=('Casting mold',2))
 elif k==33:
  if not material_arts['crucible_built']:msg('A special insulated crucible is required.');return
  cx,cy=tile(p)
  cave_key=p.get('cave_tile')
  if isinstance(cave_key,(list,tuple)):cave_key=f'{int(cave_key[0])},{int(cave_key[1])}'
  depth=int(caves.get(str(cave_key),{}).get('depth',0))
  if depth<5:msg('Volcanic heat is only available in unusually deep caves.');return
  p['hp']=max(1,p['hp']-random.randint(8,22));p['energy']=max(0,p['energy']-14)
  material_arts['volcanic_heat']=int(material_arts.get('volcanic_heat',0))+1
  msg('Collected one abstract volcanic heat charge. Even the crucible is dangerously hot!');save()
 elif k==34:
  if material_arts['crucible_built']:msg('Insulated crucible already built.');return
  if era<3:msg('Requires Industrial Age metallurgy.');return
  if material_art_cost(p,{'ingot':4,'stone':5,'flux':2}):
   material_arts['crucible_built']=True;msg('Built insulated crucible for dangerous geothermal experiments.');save()
 elif k==35:
  names=('unfired_pot','fired_pot','glazed_pot','glass_batch','glass_vessel','casting_mold','hot_metal_batch','cast_metal_part')
  msg('Workshop: '+', '.join(f'{n}={available_construction(p,n)}' for n in names))

def furniture_choose(p,i,k):
 global pottery_wheel_built
 if 24<=k<=35:material_art_choose(p,i,k);return
 if k==36:
  cost=SLEEP_RECIPES['bivy_sack']
  if has_construction(p,cost):
   spend_construction(p,cost);p['bivy_sack']=p.get('bivy_sack',0)+1;msg('Crafted a robust bivy shell with layered weather protection.');save()
  return
 if k<4:
  field,values=(('craft_shape',FURN_SHAPES),('craft_material',FURN_MATERIALS),('craft_style',FURN_STYLES),('craft_fabric',FURN_FABRICS))[k]
  p[field]=values[(values.index(p.get(field,values[0]))+1)%len(values)];msg('Design changed: '+p[field]);return
 if k==4:
  if p.get('craft_material')=='metal' and not forge_built:msg('Metal furniture needs a constructed forge.');return
  if p.get('craft_material')=='stone' and not p.get('pickaxe'):msg('Stone furniture requires a pickaxe for shaping.');return
  if not bench_near(p) and not any(name=='BUILDER' and near(p,x,y,2.5) for name,x,y,_ in places):msg('Build near a workbench or the Builder first.');return
  cost=furniture_recipe(p)
  if not has_construction(p,cost):return
  cx,cy=tile(p);spots=[(cx+dx,cy+dy) for dx,dy in ((1,0),(0,1),(-1,0),(0,-1),(2,0),(0,2))]
  available=next(((x,y) for x,y in spots if 1<=x<N-1 and 1<=y<N-1 and terrain[y][x]!='water' and land_available(x,y) and not any(a==x and b==y for a,b,_ in structures)),None)
  if not available:msg('No empty adjacent tile for furniture.');return
  spend_construction(p,cost)
  x,y=available;kind='built:custom-furn-'+ '-'.join((p['craft_shape'],p['craft_material'],p['craft_style'],p['craft_fabric']))+':'+str(i+1)
  structures.append([x,y,kind]);msg(f'Built custom {p["craft_style"]} {p["craft_material"]} {p["craft_shape"]}.');save();return
 if 5<=k<=9:
  item=list(SLEEP_RECIPES)[k-5];cost=SLEEP_RECIPES[item]
  if has_construction(p,cost):spend_construction(p,cost);p[item]=p.get(item,0)+1;msg('Crafted '+item.replace('_',' '));save()
  return
 if k==10:
  if not (p.get('bivy_sack',0) or p.get('bivy_prototype',0)):msg('Buy a proper bivy at SHOP (420c), craft an advanced shell or improvise a prototype in F7.');return
  p['bivy_on']=not p.get('bivy_on',False)
  if p['bivy_on'] and not p.get('sleeping_bags',0):msg('Bivy shell enabled, but you need a sleeping bag inside it to benefit.')
  else:msg(('Proper bivy' if p.get('bivy_sack') else 'Experimental prototype bivy')+' shell '+('enabled' if p['bivy_on'] else 'removed')+'.')
  save();return
 if k in (11,12):
  item='sleeping_bags' if k==11 else 'bedroll'
  if p.get(item,0):p['sleep_kit']=item;msg('Equipped '+('sleeping bag' if k==11 else 'bedroll')+' for sleeping.');save()
  else:msg('You do not own that sleeping kit.')
  return
 if k==13:msg(f'Sleep quality: {comfort_score(p)}/100. Shelter, warm bedding and nearby furniture improve rest.');return
 if 14<=k<=18:
  item=('carving_tool','bed_frame','mattress','house_pillow','house_cushion')[k-14]
  if item!='carving_tool' and not (p.get('housing',0)>=2 or p.get('inside') or p.get('treehouse')):
   msg('Heavy bedroom furniture needs a proper house, treehouse, or interior first.');return
  if not bench_near(p) and not any(name=='BUILDER' and near(p,x,y,2.5) for name,x,y,_ in places):
   msg('Find a workbench or the Builder to make this.');return
  if not has_construction(p,SLEEP_RECIPES[item]):return
  if item=='carving_tool':
   spend_construction(p,SLEEP_RECIPES[item]);p['carving_tool']=p.get('carving_tool',0)+1
   msg('Made a fine carving chisel. It gives more precise woodworking cuts.');save();return
  cx,cy=tile(p);spots=[(cx+dx,cy+dy) for dx,dy in ((1,0),(0,1),(-1,0),(0,-1),(2,0),(0,2))]
  pos=next(((x,y) for x,y in spots if 1<=x<N-1 and 1<=y<N-1 and terrain[y][x]!='water' and land_available(x,y) and not any(a==x and b==y for a,b,_ in structures)),None)
  if pos is None:msg('No free spot for bedroom furniture.');return
  spend_construction(p,SLEEP_RECIPES[item]);structures.append([pos[0],pos[1],'built:bedroom-'+item+':'+str(i+1)])
  msg('Placed '+item.replace('_',' ')+'. This is permanent furniture, not portable gear.');save();return
 if k==19:
  cx,cy=tile(p)
  target=next((q for q in structures if q[2].startswith('built:custom-furn-') or q[2].startswith('built:bedroom-') if math.hypot(q[0]-cx,q[1]-cy)<=3),None)
  if target is None:msg('Place wooden furniture nearby before shaping.');return
  if 'metal' in target[2] or 'stone' in target[2]:msg('This workstation shapes wood. Use wooden furniture.');return
  tool=carving_implement(p)
  begin_shaping(p,i,'wood',f'{target[0]},{target[1]}',tool);return
 if k==20:
  msg('Tools change the width of cuts. Hold to press, release to recover; too much pressure can split wood.');return
 if k==21:msg(f'Sanity {int(p.get("sanity",75))}/100. Careful crafting can help you relax.');return
 if k==22:
  if not pottery_wheel_built:msg('Build a pottery wheel at F7 first.');return
  if not has_construction(p,{'clay':3,'water_bottles':1}):return
  spend_construction(p,{'clay':3,'water_bottles':1})
  begin_shaping(p,i,'pottery');return
 if k==23:
  if pottery_wheel_built:msg('Pottery wheel already built.');return
  cost={'wood':8,'stone':4,'lashings':2}
  if not has_construction(p,cost):return
  spend_construction(p,cost);pottery_wheel_built=True
  msg('Built a spinning pottery wheel! Shape clay through four pressure stages.');save();return

def rest_at_shelter(p):
 rental=p.get('rental') and time.time()<p.get('rent_until',0)
 primitive=(p.get('bedroll') or p.get('sleeping_bags') or p.get('hammock') or p.get('tree_tent') or p.get('quinzee') or p.get('igloo') or p.get('treehouse'))
 if p.get('housing',0)==0 and not (primitive or rental or p.get('cave_tile')):
  msg('No sleeping place! Make a bedroll, sleeping bag or shelter; a bivy sack only protects an inner sleeping bag.');return
 # Prototype bivies have unpredictable seams and coatings: especially unreliable in storms.
 prototype_active=(p.get('sleep_kit')=='sleeping_bags' and p.get('sleeping_bags',0)>0 and p.get('bivy_on') and not p.get('bivy_sack',0) and p.get('bivy_prototype',0)>0)
 p['bivy_leak']=bool(prototype_active and random.random() < (0.55 if weather=='Storm' else 0.34 if weather=='Rain' else 0.12))
 q=comfort_score(p);p['sleep_quality']=q
 if p['bivy_leak']:msg('Your prototype bivy leaked or let a draft through! Consider a properly sealed shell.')
 if q<25:
  p['energy']=min(100,p['energy']+25);p['hp']=min(p['maxhp'],p['hp']+4)
  msg('Terrible sleep: cold ground, poor bedding or bad weather. Sleep quality '+str(q)+'/100.')
 else:
  p['energy']=min(100,p['energy']+min(85,25+round(q*.65)))
  # Recovery needs calories and water as well as quality sleep.
  heal=round(q*.32) if p.get('hunger',0)>25 and p.get('thirst',0)>25 else 3
  p['hp']=min(p['maxhp'],p['hp']+heal)
  msg(f'Rested. Sleep quality {q}/100; recovered {heal} health. Good bedding actually matters.')
 p['hunger']=max(0,p.get('hunger',90)-4)
 p['thirst']=max(0,p['thirst']-3)
 p['sanity']=max(0,min(100,p.get('sanity',75)+(5 if q>=65 else -3 if q<25 else 1)))


def protected_home(p):
 return (p['housing']>=2 or p.get('treehouse') or p.get('igloo') or
         (p.get('rental') and time.time()<p.get('rent_until',0)))

def campfire_near(p):
 return any(kind.startswith('campfire') and near(p,x,y,3.4) for x,y,kind in structures)

def bench_near(p):
 return any(kind.startswith('bench') and near(p,x,y,2.5) for x,y,kind in structures)

def watercollector_near(p):
 return any(kind.startswith('collector') and near(p,x,y,2.5) for x,y,kind in structures)

# Free-placement construction, available anywhere near each player.
# Era-aware structures: name, unlock era, wood, stone, scrap, ore, gems.
# Ordered in pages of eight; existing v41 structures remain fully compatible.
FREE_BUILD=[
 ('floor',0,2,0,0,0,0),('wall',0,3,0,0,0,0),('roof',0,4,0,0,0,0),
 ('door',0,3,0,0,0,0),('window',1,2,1,0,0,0),('bridge',0,4,0,0,0,0),
 ('campfire',0,5,2,0,0,0),('storage chest',0,8,2,0,0,0),
 ('reed hut',0,10,3,0,0,0),('palisade',0,5,1,0,0,0),
 ('watch fire',0,6,4,0,0,0),('stone altar',0,1,10,0,0,0),
 ('market stall',1,12,2,1,0,0),('stone tower',1,5,18,2,0,0),
 ('drawbridge',1,16,5,3,0,0),('barracks',1,22,10,3,0,0),
 ('clocktower',2,25,20,5,3,0),('glasshouse',2,18,9,4,0,0),
 ('stone fountain',2,5,18,2,0,0),('observatory',2,22,16,7,4,0),
 ('steam engine',3,20,14,12,7,0),('smokestack',3,12,18,12,5,0),
 ('rail track',3,6,6,4,2,0),('factory',3,40,28,20,10,0),
 ('electric lamp',4,5,3,8,1,0),('radio mast',4,14,12,14,5,0),
 ('water pump',4,18,8,12,4,0),('hangar',4,35,18,18,8,0),
 ('solar array',5,20,9,16,8,1),('data tower',5,15,24,20,10,1),
 ('drone pad',5,18,12,14,7,0),('neon beacon',5,10,5,16,4,1),
 ('rift arch',6,30,24,26,12,3),('energy pylon',6,16,15,18,10,2),
 ('hover platform',6,25,12,20,12,2),('rift monument',6,35,30,25,16,4)]
# Early-era materials/structures and later staffed industry.
FREE_BUILD.append(('bank',2,30,20,8,5,0))
FREE_BUILD.extend([
 ('lean-to',0,5,0,0,0,0),('wattle hut',0,8,2,0,0,0),
 ('clay oven',0,3,6,0,0,0),('charcoal pit',0,5,3,0,0,0),
 ('tanning rack',0,6,1,0,0,0),('granary',0,12,6,0,0,0),
 ('farmstead',0,14,5,0,0,0),('village dormitory',1,20,10,2,0,0),
 ('tavern',1,20,8,3,0,0),('training yard',1,18,10,3,0,0),
 ('stable',1,18,6,2,0,0),('distillery',2,25,10,5,1,0),
 ('fuel refinery',3,30,20,12,6,0),('vehicle workshop',4,35,22,14,8,0),
 ('airfield',4,40,25,20,10,0),('robotics lab',5,28,20,18,8,1)
])
BUILD_EXTRAS.update({
 'lean-to':{'fiber':3,'lashings':2},'wattle hut':{'clay':5,'fiber':6,'lashings':3},
 'clay oven':{'clay':7},'charcoal pit':{'clay':3},'tanning rack':{'planks':2},
 'granary':{'planks':5,'lashings':2},'farmstead':{'planks':4,'lashings':3},
 'village dormitory':{'planks':8,'nails':5,'bricks':5},
 'tavern':{'planks':10,'bricks':8,'nails':6,'glass':2},
 'training yard':{'planks':5,'nails':4},'stable':{'planks':7,'lashings':4},
 'distillery':{'bricks':8,'glass':4,'gears':2},
 'fuel refinery':{'bricks':10,'concrete':8,'gears':6,'ingot':8},
 'vehicle workshop':{'concrete':12,'gears':10,'wiring':8,'nails':8},
 'airfield':{'concrete':20,'wiring':12,'gears':8},
 'robotics lab':{'circuits':12,'wiring':16,'glass':10,'concrete':10}
})
# Public infrastructure can be placed in-world as visible facilities.
FREE_BUILD.extend([
 ('latrine',0,5,3,0,0,0),('fire bucket station',0,7,4,0,0,0),
 ('stone road',1,0,8,0,0,0),('apothecary',2,10,8,2,0,0),
 ('sewer conduit',3,0,12,3,0,0),('firehouse',3,18,15,8,2,0),
 ('paved road',4,0,10,5,0,0),('medical clinic',4,18,12,9,0,0)
])
BUILD_EXTRAS.update({
 'latrine':{'clay':3,'fiber':3},'fire bucket station':{'planks':3},
 'stone road':{'mortar':2},'apothecary':{'glass':2,'bricks':4},
 'sewer conduit':{'bricks':5,'mortar':3},'firehouse':{'bricks':8,'nails':8},
 'paved road':{'concrete':5},'medical clinic':{'glass':6,'concrete':6,'wiring':3}
})
# Mining-site buildings, in increasing order of sophistication.
FREE_BUILD.extend([
 ('ore bin',0,6,3,0,0,0),('mine entrance frame',0,8,5,0,0,0),
 ('timber mine supports',0,9,2,0,0,0),('stone smelter',1,6,12,2,0,0),
 ('minecart track',2,7,6,5,0,0),('ore crusher',3,12,15,8,4,0),
 ('mining lift',3,16,18,9,5,0),('electric drill station',4,18,14,14,7,0),
 ('automated mining rig',5,25,21,20,10,1)])
BUILD_EXTRAS.update({
 'ore bin':{'planks':2,'lashings':2},'mine entrance frame':{'planks':5,'lashings':3},
 'timber mine supports':{'planks':5,'lashings':3},'stone smelter':{'clay':6,'bricks':3},
 'minecart track':{'nails':4,'planks':4},'ore crusher':{'gears':5,'nails':6},
 'mining lift':{'gears':8,'nails':8,'planks':5},
 'electric drill station':{'wiring':6,'gears':8,'concrete':5},
 'automated mining rig':{'circuits':6,'wiring':10,'concrete':9,'gears':8}
})
# Preservation buildings can be placed on any unlocked dry tile through F3.
FREE_BUILD.extend([
 ('drying rack',0,8,2,0,0,0),('smokehouse',0,12,8,2,0,0),
 ('salt shed',0,8,5,0,0,0),('root cellar',1,12,18,0,0,0),
 ('butter churn',1,9,2,0,0,0),('dairy shed',1,15,8,0,0,0),
 ('pickling station',2,12,8,2,0,0),('ice house',2,16,15,1,0,0)])
BUILD_EXTRAS.update({
 'drying rack':{'fiber':4,'lashings':3},
 'smokehouse':{'bricks':3,'planks':4,'clay':4},
 'salt shed':{'planks':4,'lashings':2},
 'root cellar':{'planks':8,'mortar':4,'bricks':4},
 'butter churn':{'planks':5,'nails':2},
 'dairy shed':{'planks':8,'lashings':4},
 'pickling station':{'glass':3,'bricks':3},
 'ice house':{'planks':8,'bricks':6,'mortar':5}})
FREE_BUILD.extend([('nursery',0,10,4,0,0,0),('herb garden',0,6,3,0,0,0),('greenhouse',3,16,12,4,0,0)])
BUILD_EXTRAS.update({'nursery':{'planks':4,'fiber':3},'herb garden':{'fiber':4},'greenhouse':{'glass':8,'planks':7,'nails':5}})
PRESERVATION_BUILDINGS={'drying rack','smokehouse','salt shed','root cellar','butter churn','dairy shed','pickling station','ice house'}

def preservation_near(p,kind):
 return any(str(v).startswith('built:'+kind+':') and near(p,x,y,2.6) for x,y,v in structures)

def preserve_options(p):
 nearby=[b for b in sorted(PRESERVATION_BUILDINGS) if preservation_near(p,b)]
 return ['Nearby: '+(', '.join(nearby) if nearby else 'none'),
   'Salt-preserve 3 food (needs salt shed, 2 salt)',
   'Smoke 3 food (needs smokehouse, 2 firewood)',
   'Dry 3 food (needs drying rack, 1 salt)',
   'Pickle 2 food (needs pickling station, 1 salt + 1 glass)',
   'Churn butter (needs dairy shed + butter churn, 3 milk)',
   'Make cheese (needs dairy shed, 3 milk + 1 salt)',
   'Collect fresh milk (needs dairy shed + 1 grain)',
   'Store winter ice (needs ice house, winter only)',
   'Inspect storage and freshness']

def preserve_choose(p,k):
 global food_age,preservation_log
 if k==0 or k==9:
  msg(f'Shared food {shared_items.get("food",0)}, preserved {shared_items.get("preserved_food",0)}, smoked {shared_items.get("smoked_food",0)}, pickles {shared_items.get("pickles",0)}. {preservation_log}');return
 methods={1:('salt shed',{'food':3,'salt':2},'preserved_food',3),
  2:('smokehouse',{'food':3,'firewood':2},'smoked_food',3),
  3:('drying rack',{'food':3,'salt':1},'preserved_food',2),
  4:('pickling station',{'food':2,'salt':1,'glass':1},'pickles',2),
  5:('butter churn',{'milk':3},'butter',2),
  6:('dairy shed',{'milk':3,'salt':1},'cheese',2),
  7:('dairy shed',{'grain':1},'milk',2),
  8:('ice house',{'wood':1},'ice_blocks',2)}
 if k not in methods:return
 building,cost,output,quantity=methods[k]
 if not preservation_near(p,building):msg('Build '+building+' nearby using F3 first.');return
 if k==5 and not preservation_near(p,'dairy shed'):msg('Also build a dairy shed nearby.');return
 if k==8 and season!='Winter':msg('Ice can only be harvested in winter.');return
 if not settle_take(p,cost):return
 shared_items[output]=shared_items.get(output,0)+quantity
 if 'food' in cost:food_age=max(0,food_age-2)
 preservation_log=f'{quantity} {output} prepared at {building}.'
 msg(preservation_log)

# Extra physical machinery; components are required when constructing.
for _machine_name,_spec in MACHINES.items():
 FREE_BUILD.append((_machine_name,_spec['era'],0,0,0,0,0))
 BUILD_EXTRAS[_machine_name]=_spec['cost']
# Data-pack buildings are appended after the built-in construction catalog.
for _name,_structure in EXT_MODS.buildings.items():
 _cost=_structure['cost']
 FREE_BUILD.append((_name,_structure['era'],_cost.get('wood',0),_cost.get('stone',0),_cost.get('scrap',0),_cost.get('ore',0),_cost.get('gems',0)))
 BUILD_EXTRAS[_name]={k:v for k,v in _cost.items() if k not in ('wood','stone','scrap','ore','gems')}
BUILD_PAGE_SIZE=8
build_mode=False;build_kind=0;build_cursor=[120,120];build_owner=0

def place_building(p,i,x,y):
 global structures
 if not (1<=x<N-1 and 1<=y<N-1):msg('Outside the island. The ocean owns that land.');return
 if not land_available(x,y):msg('Land is locked! Purchase its expansion at the EXPANSION dock office.');return
 if math.hypot(p['x']/T-(x+.5),p['y']/T-(y+.5))>6:msg('Too far away. Build within six tiles of your player.');return
 kind,req,w,stone,scrap,ore,gems=FREE_BUILD[build_kind]
 if era<req:msg(f'{kind.title()} requires {ERAS[req]} technology.');return
 if terrain[y][x]=='water' and kind not in ('bridge','drawbridge','hover platform'):msg('This structure needs dry ground.');return
 if terrain[y][x]!='water' and kind in ('bridge','drawbridge'):msg('Bridges need water.');return
 if any(a==x and b==y for a,b,_ in structures):msg('A structure already occupies this tile.');return
 if any(math.hypot(x-a,y-b)<1.5 for _,a,b,_ in places):msg('Too close to a village building.');return
 costs={'wood':w,'stone':stone,'scrap':scrap,'ore':ore,'gems':gems,**BUILD_EXTRAS.get(kind,{})}
 if not has_construction(p,costs):return
 spend_construction(p,costs)
 actual='chest'+str(i+1) if kind=='storage chest' else kind+str(i+1) if build_kind<8 else 'built:'+kind+':'+str(i+1)
 structures.append([x,y,actual])
 if kind in MACHINES:machine_states[f'{x},{y}']={'on':True,'condition':100,'fuel':0,'progress':0,'charge':0}
 if kind=='storage chest':storage_boxes[f'{x},{y}']={}
 if kind in ('floor','wall','roof','door','window','reed hut','barracks','factory','hangar'):
  p['custom_rooms']=p.get('custom_rooms',0)+1
  if kind=='wall':p['custom_walls']=p.get('custom_walls',0)+1
  if kind=='roof':p['custom_roofs']=p.get('custom_roofs',0)+1
 if kind in ('campfire','watch fire'):p['campfires']=p.get('campfires',0)+1
 xp(p,9);msg(f'P{i+1} built {kind}. The local zoning committee is concerned.');save()

def recipes_build(p,kind,i):
 costs={'campfire':(5,2,0,0),'bench':(10,3,2,0),'collector':(6,2,3,0),
        'tarp':(4,0,4,0),'sleeping_bag':(3,0,6,0),'raft':(14,0,3,0),'boat':(24,5,5,300),
        'floor':(2,0,0,0),'wall':(3,0,0,0),'roof':(4,0,0,0),'door':(3,0,0,0),
        'window':(2,1,0,0),'furniture':(5,0,2,100)}
 w,st,sc,coins=costs[kind]
 extras=BUILD_EXTRAS.get(kind,LEGACY_EXTRAS.get(kind,{}))
 if not has_construction(p,extras):return
 if any(p[a]<n for a,n in [('wood',w),('stone',st),('scrap',sc),('wallet',coins)]):
  msg(f'Need {w} wood, {st} stone, {sc} scrap, {coins} coins. Your wallet fainted.');return
 if kind in ('raft','boat') and not (shoreline(p) or near(p,111,125,2.5)):msg('Craft watercraft near a shore or at the DOCK.');return
 if kind=='bench' and p.get('craft_bench'):msg('You already made a workbench.');return
 if kind=='collector' and p.get('water_collectors',0)>=4:msg('Four collectors per player is enough for a tiny water empire.');return
 spend_construction(p,extras)
 for a,n in [('wood',w),('stone',st),('scrap',sc),('wallet',coins)]:p[a]-=n
 tx,ty=tile(p)
 if kind in ('campfire','bench','collector','floor','wall','roof','door','window','furniture'):
  structures.append([tx,ty,kind+str(i+1)])
 if kind=='bench':p['craft_bench']=1
 if kind=='collector':p['water_collectors']+=1
 if kind=='tarp':p['tarps']+=1
 if kind=='sleeping_bag':p['sleeping_bags']+=1
 if kind=='raft':p['raft']+=1
 if kind=='boat':p['boat']+=1
 if kind=='campfire':p['campfires']+=1
 if kind in ('floor','wall','roof','door','window','furniture'):
  p['custom_rooms']+=1
  if kind=='roof':p['custom_roofs']+=1
  if kind=='wall':p['custom_walls']+=1
  if kind=='furniture':p['home_furnish']+=1;p['home_comfort']+=8
 xp(p,15);msg(f'P{i+1} crafted {kind.replace("_"," ")}. A goose inspected your workmanship.')

def enter_home(p,i):
 if p['inside']:
  if p.get('cave_tile'):cave_action(p,i);return
  p['inside']=False;msg(f'P{i+1} stepped back outdoors.');return
 if not protected_home(p):msg('You need an owned shack, cabin, treehouse, igloo or an active rental for an interior.');return
 if p.get('home_tile') and not near(p,*p['home_tile'],3) and not (p.get('rental') and near(p,119,129,3)):
  msg('Stand beside your home (or the housing office for a rental).');return
 p['inside']=True;msg(f'P{i+1} entered a cozy interior. No rain on your inventory now.')

def toggle_boat(p,i):
 if p.get('aboard'):
  if not any(0<=tile(p)[0]+dx<N and 0<=tile(p)[1]+dy<N and terrain[tile(p)[1]+dy][tile(p)[0]+dx]!='water' and land_available(tile(p)[0]+dx,tile(p)[1]+dy) for dx,dy in ((0,1),(0,-1),(1,0),(-1,0))):
   msg('Cannot disembark in open water. Try a shore.');return
  x,y=tile(p); land=next(( (x+dx,y+dy) for dx,dy in ((0,1),(0,-1),(1,0),(-1,0)) if 0<=x+dx<N and 0<=y+dy<N and terrain[y+dy][x+dx]!='water' and land_available(x+dx,y+dy)),None)
  if land:p['x']=(land[0]+.5)*T;p['y']=(land[1]+.5)*T
  p['aboard']=False;msg(f'P{i+1} disembarked.');return
 if not (p.get('raft') or p.get('boat')):msg('Craft a raft or boat at CAMP first.');return
 if not shoreline(p):msg('Launch only beside the shore.');return
 p['aboard']=True;msg(f'P{i+1} launched a '+('boat' if p['boat'] else 'raft')+'. Watch for hungry fish.')

QUESTS=[('Lumber Lunatic','wood',25,225),('Rock Collector','stone',20,260),('Something Fishy','fish',8,360),('Goose Exterminator','monsters',6,440),('Cartographer','explore',900,600)]
def quest_options(p):
 rows=[]
 for title,stat,goal,reward in QUESTS:
  done=title in p.get('quests_claimed',[])
  progress=p.get('stats',{}).get(stat,0)
  rows.append(f'{title}: {min(progress,goal)}/{goal} - {"CLAIMED" if done else str(reward)+"c reward"}')
 return rows

# v57 - Real-world-inspired settlement infrastructure and hazards.
# Each project consumes resources from player/shared construction stock plus treasury coins.
CIVIC_PROJECTS=(
 ('sanitation','Dig latrines / install sewers',0,{'wood':8,'stone':7,'clay':5,'planks':2},160),
 ('fire_service','Build fire buckets / watch station',0,{'wood':10,'stone':5,'water_bottles':2},190),
 ('roads','Build roads / transport depots',1,{'stone':12,'planks':4,'nails':2},340),
 ('clinic','Build apothecary / clinic',2,{'planks':9,'glass':2,'bricks':6},620),
)

def civic_options(p):
 rows=[f'Settlement health {civic["health"]}/100 | fires {civic["fires"]} | illnesses {civic["illnesses"]}',
       f'Recent: {civic["recent"][:70]}']
 for key,title,required,ingredients,coins in CIVIC_PROJECTS:
  cost=', '.join(f'{q} {name}' for name,q in ingredients.items())
  rows.append(f'{title} [Lv {civic[key]}/3, {ERAS[required]}] {coins}c + {cost}')
 rows.append('Inspect infrastructure: water, fire readiness, transport and public health')
 return rows

def civic_choose(p,k):
 global settlement_treasury
 if k==0:msg(f'Public health {civic["health"]}/100. Illness {civic["illnesses"]} / fires {civic["fires"]}.');return
 if k==1:msg(civic['recent']);return
 if k==len(CIVIC_PROJECTS)+2:
  msg(f'Sanitation {civic["sanitation"]}, Fire {civic["fire_service"]}, Roads {civic["roads"]}, Clinic {civic["clinic"]}.');return
 index=k-2
 if not (0<=index<len(CIVIC_PROJECTS)):return
 key,title,required,ingredients,coins=CIVIC_PROJECTS[index]
 if civic[key]>=3:msg(title+': maximum capacity already built.');return
 if era<required:msg(title+' requires '+ERAS[required]+'.');return
 if settlement_treasury<coins:msg(f'Village treasury needs {coins} coins. Deposit funds at VILLAGE.');return
 if not has_construction(p,ingredients):return
 spend_construction(p,ingredients);settlement_treasury-=coins;civic[key]+=1
 civic['recent']=title+f' upgraded to level {civic[key]}.'
 msg(civic['recent'])

def tick_civic(seconds):
 # Active-game time only, with bounded catch-up after lag.
 civic['clock']+=seconds
 if civic['clock']<90:return
 cycles=min(2,int(civic['clock']//90));civic['clock']-=cycles*90
 for _ in range(cycles):
  people=len(villagers)+government.get('servants',0)
  if people==0:continue
  pollution=max(0,10+people*2-civic['sanitation']*10-civic['roads']*2)
  fire_risk=max(1,17+people-civic['fire_service']*12)
  if random.randrange(100)<pollution:
   civic['illnesses']+=1;civic['health']=max(0,civic['health']-random.randint(4,11))
   civic['recent']='Contaminated water caused illness. Improve sanitation and clinic access.'
   msg(civic['recent'])
  elif civic['clinic']>0:civic['health']=min(100,civic['health']+3*civic['clinic'])
  if random.randrange(100)<fire_risk:
   civic['fires']+=1
   damage=max(1,12-civic['fire_service']*4)
   civic['health']=max(0,civic['health']-damage)
   # Fires have an economic consequence without deleting player structures.
   loss=min(settlement_treasury,max(15,110-civic['fire_service']*30))
   settlement_loss=loss
   globals()['settlement_treasury']=max(0,settlement_treasury-settlement_loss)
   civic['recent']=f'Village fire! {loss}c damage. Fire readiness {civic["fire_service"]}/3.'
   msg(civic['recent'])
  if civic['health']<35:
   # Poor health stops some economic production through reduced treasury income.
   fine=min(settlement_treasury,20)
   globals()['settlement_treasury']=max(0,settlement_treasury-fine)
   if fine:civic['recent']='Sick workers slowed commerce; medical expenses '+str(fine)+'c.'
  civic['incidents']+=1

# Village jobs and military: payroll cycles are in active game time, not wall clock.
VILLAGER_NAMES=('Ada','Bram','Cora','Dax','Ember','Finn','Gita','Hugo','Iris','Juno','Keen','Lena')
JOB_WAGES={'farmer':35,'tavern keeper':50,'guard':60,'engineer':90,'organizer':55}  # minimum fair wage / 60 game seconds
JOB_HOUSING={'farmer':0,'tavern keeper':1,'guard':1,'engineer':3}

def built_count(kind):
 return sum(1 for a,b,v in structures if v=='built:'+kind or str(v).startswith('built:'+kind+':'))

def housing_capacity():
 # A bed for each new hire, not just a bigger wallet.
 return 2*built_count('wattle hut')+built_count('lean-to')+4*built_count('village dormitory')+2*built_count('reed hut')+3*built_count('barracks')

def staff_count(job):return sum(1 for v in villagers if v['job']==job)

def update_villager_housing():
 beds=housing_capacity()
 assigned=set()
 for v in villagers:
  bed=v.get('bed')
  if not isinstance(bed,int) or not 0<=bed<beds or bed in assigned:
   v['bed']=None
  else:assigned.add(bed)
 # An employed, adequately rested organizer handles unassigned residents.
 organizer=any(v.get('job')=='organizer' and not v.get('striking') and v.get('morale',0)>=25 for v in villagers)
 if organizer:
  for v in villagers:
   if v.get('bed') is None:
    empty=next((j for j in range(beds) if j not in assigned),None)
    if empty is not None:v['bed']=empty;assigned.add(empty)
 for v in villagers:v['homeless']=v.get('bed') is None

def name_villager(v):
 # Synchronous Pygame text prompt; no platform-specific dialog dependency.
 name=str(v.get('name','Villager'))[:22]
 while True:
  for e in pygame.event.get():
   if e.type==pygame.QUIT:return
   if e.type==pygame.KEYDOWN:
    if e.key==pygame.K_ESCAPE:return
    if e.key==pygame.K_RETURN:
     if name.strip():v['name']=name.strip()[:22]
     return
    if e.key==pygame.K_BACKSPACE:name=name[:-1]
    elif e.unicode and e.unicode.isprintable() and len(name)<22:name+=e.unicode
  screen.fill((18,31,43))
  screen.blit(big.render('RENAME VILLAGER',True,(247,210,122)),(340,220))
  screen.blit(font.render(name+'_',True,(235,240,248)),(350,300))
  screen.blit(small.render('Type name | Enter saves | Esc cancels',True,(176,200,210)),(350,350))
  pygame.display.flip();clock.tick(30)

def village_report():
 update_villager_housing()
 return f'{len(villagers)} villagers | {sum(v["homeless"] for v in villagers)} homeless | {sum(v["striking"] for v in villagers)} refusing work | Food {shared_items.get("food",0)}'


def settle_take(p,needed):
 if not has_construction(p,needed):return False
 spend_construction(p,needed);return True

def settlement_options(p):
 return [f'Treasury: {settlement_treasury}c / {len(villagers)} villagers / Beds {housing_capacity()}',
  'Deposit 500c to village treasury',
  f'Hire farmer (Ancient, farmstead, 35c/payroll) [{staff_count("farmer")}]',
  f'Hire tavern keeper (Medieval, tavern, 50c/payroll) [{staff_count("tavern keeper")}]',
  f'Hire engineer (Industrial, workshop, 90c/payroll) [{staff_count("engineer")}]',
  'Raise all wages 10c / payroll (morale boost)',
  'Dismiss last villager (severance: 100c)',
  f'Inspect workforce: {settlement_log[:60] or "no recent payroll"}',
  'Primitive: bake clay bricks (6 clay + 2 firewood)',
  'Primitive: make charcoal (4 wood -> 3 charcoal)',
  'Primitive: tan leather (2 hide + 1 charcoal -> 2 leather)',
  'Farm: thresh grain (4 seed -> 5 grain)',
  'Brew beer (5 grain + 2 water bottles -> 3 beer)',
  'Refine fuel (4 charcoal + 2 ore -> 3 fuel) [Industrial]',
  'Inspect villagers: hunger, beds and morale',
  'Feed hungry villagers (shared food or player food)',
  'Give emergency meals (3 food, +morale)',
  'Assign idle villager to farm (build farmstead first)',
  'Assign idle villager to tavern (Medieval; build tavern)',
  'Assign idle villager to repairs (Industrial; build workshop)',
  'Hire settlement organizer (beds, food, stores; 55c/payroll)',
  'Assign first free bed to an unhoused villager',
  'Inspect everyone: health, sleep, hunger, thirst',
  'Give drinking water to the thirstiest villager',
  'Rename a villager (select below)' ]+[f'Rename {v["name"]}' for v in villagers]

def settlement_choose(p,k):
 global settlement_treasury,settlement_log
 if k==0:msg(village_report()+f' | Treasury {settlement_treasury}c');return
 if k==14:
  msg(village_report())
  for v in villagers[:5]:msg(f'{v["name"]}: {v["job"]}, hunger {int(v["hunger"])}, morale {int(v["morale"])}, {"homeless" if v["homeless"] else "sheltered"}.')
  return
 if k>=25:
  j=k-25
  if 0<=j<len(villagers):name_villager(villagers[j]);msg('Villager renamed.')
  return
 if k==20:
  idle=next((v for v in villagers if v['job']=='idle'),None)
  if not idle:msg('Nobody available to organize sleeping places.');return
  if settlement_treasury<55:msg('Pay an organizer at least 55 coins per payroll.');return
  idle['job']='organizer';idle['wage']=55;idle['striking']=False;msg(idle['name']+' now organizes beds, food stores and preservation.');update_villager_housing();return
 if k==21:
  update_villager_housing()
  # Manual assignment works without organizer; can free up beds by building more huts.
  vacant=next((j for j in range(housing_capacity()) if all(v.get('bed')!=j for v in villagers)),None)
  person=next((v for v in villagers if v.get('bed') is None),None)
  if vacant is None or person is None:msg('No vacant bed or no unhoused villager.');return
  person['bed']=vacant;update_villager_housing();msg(person['name']+f' assigned sleeping place #{vacant+1}.');return
 if k==22:
  update_villager_housing()
  for v in villagers:
   msg(f'{v["name"]}: HP {int(v.get("hp",100))} Sleep {int(v.get("sleep",65))} Hunger {int(v.get("hunger",80))} Thirst {int(v.get("thirst",80))} Bed {v.get("bed") if v.get("bed") is not None else "NONE"}.')
  return
 if k==23:
  target=min(villagers,key=lambda v:v.get('thirst',80)) if villagers else None
  if not target:msg('No villagers.');return
  if shared_items.get('water_bottles',0)>0:shared_items['water_bottles']-=1
  elif p.get('water_filled',0)>0:p['water_filled']-=1
  else:msg('No bottled water available for villagers.');return
  target['thirst']=min(100,target.get('thirst',80)+55);msg(target['name']+' drank clean water.');return
 if k==24:msg('Select a villager name in the following menu entries to rename them.');return
 if k in (15,16):
  if not villagers:msg('No villagers need feeding.');return
  hungry=sorted(villagers,key=lambda v:v.get('hunger',80))
  target=hungry[0]
  if k==15:
   if shared_items.get('food',0)>0:shared_items['food']-=1
   elif p.get('food',0)>0:p['food']-=1
   else:msg('No food in the party supplies. Gather or cook food.');return
   target['hunger']=min(100,target.get('hunger',0)+45);target['morale']=min(100,target['morale']+6)
   msg(target['name']+' ate a meal. Hunger '+str(int(target['hunger']))+'/100.')
  else:
   if shared_items.get('food',0)<3:msg('Emergency village meals require 3 food in shared supplies.');return
   shared_items['food']-=3
   for v in villagers:v['hunger']=min(100,v['hunger']+24);v['morale']=min(100,v['morale']+8)
   msg('Community meal served. People appreciate being fed.')
  return
 if k in (17,18,19):
  job={17:'farmer',18:'tavern keeper',19:'engineer'}[k]
  req={'farmer':0,'tavern keeper':1,'engineer':3}[job]
  building={'farmer':'farmstead','tavern keeper':'tavern','engineer':'vehicle workshop' if era>=4 else 'factory'}[job]
  idle=next((v for v in villagers if v['job']=='idle'),None)
  if not idle:msg('No idle villagers. Recruit more after arranging beds.');return
  if era<req or not built_count(building):msg('First unlock the era and build a '+building+'.');return
  if settlement_treasury<JOB_WAGES[job]:msg('Deposit at least one wage into the village treasury.');return
  idle['job']=job;idle['wage']=JOB_WAGES[job];idle['striking']=False
  msg(idle['name']+' is now a '+job+'. Pay wages and keep them fed.');return
 if k==1:
  if buy(p,500):settlement_treasury+=500;msg('Deposited 500c into village payroll.')
 elif k in (2,3,4):
  job={2:'farmer',3:'tavern keeper',4:'engineer'}[k]
  req={'farmer':0,'tavern keeper':1,'engineer':3}[job]
  building={'farmer':'farmstead','tavern keeper':'tavern','engineer':'vehicle workshop' if era>=4 else 'factory'}[job]
  if era<req:msg('This profession is not unlocked yet.')
  elif not built_count(building):msg('Build a '+building+' before hiring.')
  elif len(villagers)>=housing_capacity():msg('No spare beds! Build huts or a village dormitory.')
  elif settlement_treasury<JOB_WAGES[job]*2:msg('Fund at least two wage payments before hiring.')
  else:
   name=VILLAGER_NAMES[len(villagers)%len(VILLAGER_NAMES)]+str(len(villagers)//len(VILLAGER_NAMES)+1)
   villagers.append({'name':name,'job':job,'wage':JOB_WAGES[job],'morale':80,'hunger':80,'homeless':False,'unpaid_cycles':0,'trained':0,'striking':False});msg(name+' hired as '+job+'. Fair wage guaranteed.')
 elif k==5:
  if not villagers:msg('No employees to give raises to.')
  else:
   for v in villagers:v['wage']+=10;v['morale']=min(100,v['morale']+15)
   msg('Everyone gets a raise. Productivity thanks you.')
 elif k==6:
  if not villagers:msg('Nobody works here.')
  elif settlement_treasury<100:msg('Need 100c treasury for fair severance pay.')
  else:
   settlement_treasury-=100;v=villagers.pop();msg(v['name']+' left with 100c severance.')
 elif k==7:msg(settlement_log or 'No payroll has run yet.')
 else:
  recipes={8:({'clay':6,'firewood':2},'bricks',5,0),9:({'wood':4},'charcoal',3,0),
    10:({'hide':2,'charcoal':1},'leather',2,0),11:({'seed':4},'grain',5,0),
    12:({'grain':5,'water_bottles':2},'beer',3,1),13:({'charcoal':4,'ore':2},'fuel',3,3)}
  cost,item,qty,req=recipes[k]
  if era<req:msg('Needs '+ERAS[req]+' technology.')
  elif k==12 and not built_count('tavern'):msg('Build a tavern to brew beer.')
  elif k==13 and not built_count('fuel refinery'):msg('Build a fuel refinery.')
  elif settle_take(p,cost):shared_items[item]=shared_items.get(item,0)+qty;msg(f'Processed {qty} {item} for the village.')

def army_options(p):
 return [f'Garrison: {staff_count("guard")} guards; training {army_training}; vehicles {len(vehicles)}',
   'Recruit guard (Medieval; 60c/payroll; bed + training yard)',
   'Train guards (+1 training, costs 3 food + 70c)',
   'Improve defenses (cost 6 wood, 4 stone, 100c)',
   'Assemble tank (Modern, 15 ingots, 12 gears, 8 fuel, 1500c)',
   'Assemble plane (Modern, 20 ingots, 15 wiring, 12 fuel, 3000c)',
   'Assemble drone (Digital, 8 circuits, 6 wiring, 5 fuel, 1800c)',
   'Repair/refuel vehicle (4 ingots, 3 fuel, 350c)',
   f'Inspect vehicle hangar: '+', '.join(v['kind'] for v in vehicles[-4:])]

def army_choose(p,k):
 global settlement_treasury,army_training
 if k==0 or k==8:msg(army_options(p)[k]);return
 if k==1:
  if era<1 or not built_count('training yard'):msg('Build a Medieval training yard first.')
  elif len(villagers)>=housing_capacity():msg('Soldiers need beds. Build a dormitory or barracks.')
  elif settlement_treasury<120:msg('Fund two soldier paychecks in the village treasury.')
  else:
   villagers.append({'name':'Guard '+str(staff_count('guard')+1),'job':'guard','wage':60,'morale':75,'hunger':80,'homeless':False,'unpaid_cycles':0,'trained':0,'striking':False});msg('A new guard joined your garrison. Wages due each minute.')
 elif k==2:
  if staff_count('guard')==0:msg('Recruit guards first.')
  elif p['wallet']<70:msg('Training costs 70c.')
  elif settle_take(p,{'food':3}):p['wallet']-=70;army_training+=1;msg('Guard training improved. Patrols are more effective.')
 elif k==3:
  if p['wallet']>=100 and settle_take(p,{'wood':6,'stone':4}):p['wallet']-=100;army_training+=1;msg('Barricades strengthened; guards can hold the line.')
 elif k in (4,5,6):
  specs={4:('tank',4,'vehicle workshop',{'ingot':15,'gears':12,'fuel':8},1500),
         5:('plane',4,'airfield',{'ingot':20,'wiring':15,'fuel':12},3000),
         6:('drone',5,'robotics lab',{'circuits':8,'wiring':6,'fuel':5},1800)}
  kind,req,building,cost,coins=specs[k]
  if era<req or not built_count(building):msg('Unlock '+ERAS[req]+' and build a '+building+'.')
  elif staff_count('engineer')<1:msg('Hire an engineer to assemble vehicles.')
  elif p['wallet']<coins:msg('Need '+str(coins)+' coins for assembly.')
  elif settle_take(p,cost):p['wallet']-=coins;vehicles.append({'kind':kind,'condition':100,'fuel':80,'active':True});msg(kind.title()+' assembled. It needs fuel and repairs to patrol.')
 elif k==7:
  damaged=next((v for v in vehicles if v.get('condition',100)<100 or v.get('fuel',0)<80),None)
  if not damaged:msg('No vehicles require service.')
  elif p['wallet']>=350 and settle_take(p,{'ingot':4,'fuel':3}):p['wallet']-=350;damaged['condition']=min(100,damaged.get('condition',100)+55);damaged['fuel']=min(100,damaged.get('fuel',0)+70);msg('Vehicle serviced and refueled.')

def tick_settlement(seconds):
 global settlement_clock,settlement_treasury,settlement_log
 settlement_clock+=seconds
 if settlement_clock<60:return
 cycles=min(3,int(settlement_clock//60));settlement_clock-=cycles*60
 for _ in range(cycles):
  update_villager_housing()
  # All villagers have needs, even residents without a job. Housing cannot be
  # substituted by a large treasury: bad living conditions steadily hurt morale.
  for v in villagers:
   v['hunger']=max(0,v.get('hunger',80)-random.randint(13,22))
   v['thirst']=max(0,v.get('thirst',80)-random.randint(23,33) if weather=='Heatwave' or season=='Summer' else v.get('thirst',80)-random.randint(10,16))
   v['sleep']=max(0,v.get('sleep',65)-(24 if v.get('homeless') else 12))
   if not v.get('homeless') and v.get('sleep',0)<70:v['sleep']=min(100,v['sleep']+42)
   if v['thirst']<35 and shared_items.get('water_bottles',0)>0:
    shared_items['water_bottles']-=1;v['thirst']=min(100,v['thirst']+55)
   if v['hunger']>60 and v['thirst']>60 and v['sleep']>60:
    v['hp']=min(100,v.get('hp',100)+random.randint(2,6))
   if v['hunger']==0 or v['thirst']==0 or v['sleep']==0:
    v['hp']=max(0,v.get('hp',100)-random.randint(5,11));v['morale']=max(0,v.get('morale',65)-8)
   if v['hp']==0:v['striking']=True
   if v['homeless']:v['morale']=max(0,v.get('morale',65)-random.randint(3,7))
   elif v['hunger']>45:v['morale']=min(100,v.get('morale',65)+2)
  # Perishable shared food ages during active play. Cellars and ice houses delay rot.
  global food_age,preservation_log
  food_age+=1
  freshness_limit=4+3*int(built_count('root cellar')>0)+5*int(built_count('ice house')>0)
  if season=='Summer':freshness_limit=max(2,freshness_limit-2)
  if food_age>=freshness_limit:
   food_age=0
   spoiled=min(shared_items.get('food',0),max(1,shared_items.get('food',0)//5))
   if spoiled:
    shared_items['food']-=spoiled
    preservation_log=f'{spoiled} fresh food spoiled. Preserve it or build a cellar/ice house.'
    msg(preservation_log)
  # Serve the hungriest first; one food feeds one person (not three people).
  for v in sorted(villagers,key=lambda worker:worker['hunger']):
   if v['hunger']<=65:
    food_type=next((f for f in ('food','smoked_food','preserved_food','pickles','cheese') if shared_items.get(f,0)>0),None)
    if food_type:
     shared_items[food_type]-=1;v['hunger']=min(100,v['hunger']+55)
   if v['hunger']<25:v['morale']=max(0,v['morale']-15)
   if v['hunger']==0:v['morale']=max(0,v['morale']-9)
  # A funded and healthy organizer maintains shared supplies, food stores and bed assignments.
  active_organizer=any(v.get('job')=='organizer' and not v.get('striking') and v.get('morale',0)>=25 and v.get('hp',100)>25 for v in villagers)
  if active_organizer:
   for box in storage_boxes.values():
    if not isinstance(box,dict):continue
    for item in ('food','grain','salt','preserved_food','smoked_food','pickles','cheese','butter','water_bottles'):
     amount=max(0,int(box.get(item,0)))
     if amount:
      shared_items[item]=shared_items.get(item,0)+amount
      box[item]=0
   # Auto-preservation is limited by actually built facilities and ingredients.
   if built_count('smokehouse') and shared_items.get('food',0)>=9 and shared_items.get('firewood',0)>=2:
    shared_items['food']-=3;shared_items['firewood']-=2
    shared_items['smoked_food']=shared_items.get('smoked_food',0)+3
    msg('Organizer smoked 3 surplus food for storage.')
   elif built_count('salt shed') and shared_items.get('food',0)>=9 and shared_items.get('salt',0)>=2:
    shared_items['food']-=3;shared_items['salt']-=2
    shared_items['preserved_food']=shared_items.get('preserved_food',0)+3
    msg('Organizer salted 3 surplus food.')
  payroll=sum(max(JOB_WAGES.get(v['job'],0),v.get('wage',0)) for v in villagers if v['job']!='idle')+government['servants']*40
  paid=payroll<=settlement_treasury
  if paid:settlement_treasury-=payroll
  for v in villagers:
   if v['job']=='idle':v['striking']=False;continue
   if not paid:
    v['unpaid_cycles']=v.get('unpaid_cycles',0)+1
    v['morale']=max(0,v['morale']-20)
   else:v['unpaid_cycles']=0
   v['striking']=not paid or v['hunger']<30 or v.get('thirst',80)<25 or v.get('sleep',65)<20 or v.get('hp',100)<20 or v['morale']<25
   if not v['striking']:
    v['morale']=min(100,v['morale']+2)
    if v['job']=='farmer' and built_count('farmstead'):
     shared_items['food']=shared_items.get('food',0)+5;shared_items['grain']=shared_items.get('grain',0)+3
    elif v['job']=='tavern keeper' and built_count('tavern'):
     if shared_items.get('grain',0)>=3:
      shared_items['grain']-=3;shared_items['beer']=shared_items.get('beer',0)+2
      settlement_treasury+=random.randint(28,70)
    elif v['job']=='engineer':
     for vehicle in vehicles:vehicle['condition']=min(100,vehicle.get('condition',100)+1)
   elif v['morale']<15:msg(v['name']+' is furious and refuses to work. Provide food, pay and shelter.')
  if government['servants'] and paid:
   meals=min(government['servants'],shared_items.get('food',0))
   shared_items['food']-=meals
   if meals<government['servants']:
    government['unrest']=min(100,government['unrest']+2)
    msg('Household servants are missing meals. Unrest is growing.')
  if government['forced_labor']:
   government['labor_cycles']=government.get('labor_cycles',0)+1
   government['labor_policy_age']=government.get('labor_policy_age',0)+1
   cycle=government['labor_policy_age']
   industrial_pressure=max(0,era-2)*2+min(5,len(vehicles))
   yield_stone=max(0,8-(cycle//5)-industrial_pressure)
   government['last_labor_yield']=yield_stone
   shared_items['stone']=shared_items.get('stone',0)+yield_stone
   government['unrest']=min(100,government['unrest']+(1 if era<2 else 3))
   if era>=3 and cycle%3==0:settlement_treasury=max(0,settlement_treasury-35)
  if not paid and payroll:msg('Workers went unpaid! They may stop working or leave.')
  if all(v['hunger']<25 for v in villagers) and villagers:msg('The whole village is hungry. Find food or establish farms!')
  if len(villagers)>2:
   angry=[v for v in villagers if v['morale']<8 and v['hunger']<18]
   if angry and random.random()<.35:
    leaving=random.choice(angry);villagers.remove(leaving)
    msg(leaving['name']+' left the settlement after prolonged hunger and neglect.')
  settlement_log=f'Payroll {payroll}c {"paid" if paid else "MISSED"}; {village_report()}. Treasury {settlement_treasury}c.'
  defenders=sum(1 for v in villagers if v['job']=='guard' and not v.get('striking'))
  active=[v for v in vehicles if v.get('condition',0)>0 and v.get('fuel',0)>0]
  for vehicle in active:
   vehicle['fuel']=max(0,vehicle['fuel']-3)
   vehicle['condition']=max(0,vehicle['condition']-random.choice([0,0,1,2]))
  if defenders or active:
   # Defensive patrols reduce nearby threats, without granting arbitrary player buffs.
   protection=min(12,defenders*(1+army_training//3)+len(active)*3)
   nearby=[m for m in monsters if math.hypot(m['x']/T-120,m['y']/T-120)<23]
   for m in nearby[:min(len(nearby),protection)]:
    if m in monsters:monsters.remove(m)
   if nearby:msg(f'Village patrol pushed back {min(len(nearby),protection)} nearby threats.')


# v55: Government and unrest. All numbers are fictional game mechanics.
def council_record(line):
 government['history']=(government.get('history',[])+[str(line)[:120]])[-16:]
 msg(line)

def council_options(p):
 g=government
 return [f"System: {g['system']} | Ruler P{g['ruler']+1} | unrest {g['unrest']} | legitimacy {g['legitimacy']}",
  f"Workers: {len(villagers)} | paid servants: {g['servants']} | forced labor: {'LEGAL' if g['forced_labor'] else 'BANNED'}",
  'Hire paid household servant (bed + 80c treasury; 40c/payroll)',
  'Dismiss a servant (80c severance)',
  'Impose forced labor decree (serious revolt risk)',
  'Abolish forced labor and release everyone (cost 250c)',
  'Declare constitutional democracy (elections begin)',
  'Restore hereditary chiefdom (unrest increases)',
  'Hold early election (democracy only; public support matters)',
  'Allow public assembly (+legitimacy; +unrest if unrest already high)',
  'Suppress protest (lowers visible unrest briefly; future backlash)',
  'Hold public hearing (120c; reduces unrest)',
  'Inspect last government incidents',
  'View labor economy and public opinion',
  'Convene public debate on labor laws (later eras)',
  'Negotiate transition to paid employment (later eras)']

def council_choose(p,k):
 g=government
 if k in (0,1):council_record(council_options(p)[k]);return
 if k==2:
  if len(villagers)+g['servants']>=housing_capacity():council_record('No bed available for a servant; build housing first.')
  elif settlement_treasury<80:council_record('Village treasury needs 80c to hire a paid servant.')
  else:g['servants']+=1;council_record('Paid household servant hired. Pay and food are required each payroll.')
 elif k==3:
  if not g['servants']:council_record('No servants to dismiss.')
  elif settlement_treasury<80:council_record('Treasury needs 80c for severance.')
  else:
   globals()['settlement_treasury']-=80;g['servants']-=1;council_record('Servant dismissed with severance.')
 elif k==4:
  if g['forced_labor']:council_record('Forced labor is already permitted.')
  else:g['forced_labor']=True;g['labor_policy_age']=0;g['unrest']=min(100,g['unrest']+10);g['legitimacy']=max(0,g['legitimacy']-10);council_record('Compulsory labor decree enacted. Short-term output may rise, with social costs accumulating.')
 elif k==5:
  if not g['forced_labor']:council_record('Forced labor is already prohibited.')
  elif settlement_treasury<250:council_record('Release and transition program needs 250c treasury.')
  else:
   globals()['settlement_treasury']-=250;g['forced_labor']=False;g['last_labor_yield']=0;g['unrest']=max(0,g['unrest']-20);g['legitimacy']=min(100,g['legitimacy']+18);council_record('Forced labor abolished. Residents are released; old records remain.')
 elif k==6:
  g['system']='democracy';g['legitimacy']=min(100,g['legitimacy']+12);g['election_clock']=0;council_record('Democracy proclaimed. Elections occur periodically; existing laws remain until repealed.')
 elif k==7:
  g['system']='chiefdom';g['unrest']=min(100,g['unrest']+20);g['legitimacy']=max(0,g['legitimacy']-8);council_record('Chiefdom restored. Political opposition is unhappy.')
 elif k==8:
  if g['system']!='democracy':council_record('Elections require a democracy.')
  else:hold_election()
 elif k==9:
  g['legitimacy']=min(100,g['legitimacy']+5);g['unrest']=min(100,g['unrest']+(5 if g['unrest']>65 else -3));council_record('Public assembly permitted. Residents freely voice their concerns.')
 elif k==10:
  g['unrest']=max(0,g['unrest']-12);g['legitimacy']=max(0,g['legitimacy']-23);g['unrest']=min(100,g['unrest']+7 if g['forced_labor'] else g['unrest']);council_record('Protest suppressed. Anger has not disappeared.')
 elif k==11:
  if settlement_treasury<120:council_record('Public hearing requires 120c treasury.')
  else:
   globals()['settlement_treasury']-=120;g['unrest']=max(0,g['unrest']-18);g['legitimacy']=min(100,g['legitimacy']+9);council_record('Open hearing held. Some grievances addressed.')
 elif k==12:council_record(' | '.join(g.get('history',[])[-3:]) or 'Nothing on record.')
 elif k==13:
  support=g.get('factions',{})
  current=g.get('last_labor_yield',0) if g['forced_labor'] else 0
  council_record(f'Labor: compulsory output {current} stone/payroll; policy age {g.get("labor_policy_age",0)} cycles. Estate advocates {support.get("estate_owners",0)}; reformers {support.get("reformers",0)} (0-100).')
 elif k==14:
  if not labor_debate_unlocked():council_record('Organized debate has not emerged yet. Develop a Renaissance-era settlement with villagers.')
  else:
   g['opinion_clock']=0
   a=g['factions']['estate_owners'];r=g['factions']['reformers']
   council_record(f'Public forum: estate advocates {a}/100 cite output; reformers {r}/100 demand paid work and rights. No law changes automatically.')
   g['unrest']=max(0,g['unrest']-4)
 elif k==15:
  if not labor_debate_unlocked():council_record('Requires a developed Renaissance-era settlement with villagers.')
  elif not g['forced_labor']:council_record('Compulsory labor is already banned. Paid employment is available at VILLAGE.')
  elif settlement_treasury<160:council_record('Transition planning requires 160 treasury coins.')
  else:
   globals()['settlement_treasury']-=160
   g['forced_labor']=False;g['last_labor_yield']=0
   g['unrest']=max(0,g['unrest']-14);g['legitimacy']=min(100,g['legitimacy']+9)
   council_record('Negotiated release and transition to paid employment. Hire workers through VILLAGE for continued output.')


def hold_election():
 g=government
 if g['system']!='democracy':return
 incumbent_score=g['legitimacy']-g['unrest']*.65-(22 if g['forced_labor'] else 0)+random.randint(-18,18)
 if incumbent_score>=40:
  g['legitimacy']=min(100,g['legitimacy']+5);council_record('Election: incumbent leadership retained. Existing policies remain in force.')
 else:
  old=g['ruler'];g['ruler']=(old+1)%len(players) if len(players)>1 else 0
  g['legitimacy']=45;g['unrest']=max(10,g['unrest']-12)
  council_record('Election: the incumbent was removed. Existing laws remain until changed by the new government.')
 g['election_clock']=0

def labor_debate_unlocked():
 # Early settlements lack organized mass politics; advanced towns develop factions.
 return era>=2 and len(villagers)+government.get('servants',0)>=3

def evolve_labor_opinion():
 g=government
 if not labor_debate_unlocked():
  g['factions']={'estate_owners':0,'reformers':0}
  return
 factions=g['factions']
 modernization=min(35,max(0,era-2)*9)+min(20,len(vehicles)*3)
 if g['forced_labor']:
  factions['estate_owners']=min(100,max(5,round(63-modernization*.8-g.get('labor_policy_age',0)*.4)))
  factions['reformers']=min(100,max(5,round(24+modernization+g.get('labor_policy_age',0)*.8+g['unrest']*.18)))
 else:
  factions['estate_owners']=min(100,max(0,round(factions.get('estate_owners',25)*.85)))
  factions['reformers']=min(100,max(0,round(factions.get('reformers',40)*.92)))

def tick_government(seconds):
 g=government
 g['election_clock']+=seconds
 g['opinion_clock']=g.get('opinion_clock',0)+seconds
 if g['opinion_clock']>=45:
  g['opinion_clock']%=45
  evolve_labor_opinion()
  if labor_debate_unlocked() and g['forced_labor'] and random.random()<.35:
   council_record(random.choice(['Estate representatives defend compulsory harvest quotas.','A reform club petitions for paid work and freedom.','Town meeting divides over labor rules and modernization.']))
 # Servants are paid on settlement payroll: accounted there to avoid repeated charges.
 if g['system']=='democracy' and g['election_clock']>=420:hold_election()
 if random.random()<seconds/60:
  if g['forced_labor']:
   g['unrest']=min(100,g['unrest']+random.randint(6,13));g['legitimacy']=max(0,g['legitimacy']-random.randint(2,7))
   council_record(random.choice(['Forced laborers escape into the forest.','Protesters blockade the market.','Workers sabotage an unsafe work site.']))
  elif g['unrest']>0:g['unrest']=max(0,g['unrest']-random.randint(1,4))
 if g['unrest']>=85 and random.random()<seconds/12:
  g['overthrows']+=1;g['unrest']=35;g['legitimacy']=30
  g['system']='interim council';g['forced_labor']=False
  g['ruler']=(g['ruler']+1)%len(players) if len(players)>1 else 0
  g['servants']=max(0,g['servants']-1)
  for q in players:q['hp']=max(1,q['hp']-random.randint(12,32))
  council_record('UPRISING! The ruler was overthrown; the old administration collapsed. Players were injured during the chaos.')
  g['rebellions']+=1

def regional_market_options(name,p):
 region=next((r for r,(_,_,label,*_) in ISLAND_MARKETS.items() if label==name),None)
 if region is None:return []
 origin,destination=ISLAND_MARKETS[region][3:5]
 trade=regional_trade.get(region,0)
 return [f'Buy {origin} supply crate (135c; includes 6 items)',
         f'Sell 4 {destination} for {230+min(160,trade*4)}c',
         f'Buy island provisions: 4 food + 3 water (175c)',
         f'Invest in local port (600c, {trade}/10 standing)',
         'Inspect regional trade conditions']

def fantasy_site_options(name,p):
 region=next((r for r,(_,_,label) in ISLAND_FANTASY.items() if label==name),None)
 if region is None:return []
 return ['Offer 2 gems to the island spirit', 'Request a mysterious blessing (150c)', 'Inspect the ancient site']

def regional_market_choose(p,name,k):
 region=next((r for r,(_,_,label,*_) in ISLAND_MARKETS.items() if label==name),None)
 if not region:return
 _,_,_,stock,demand=ISLAND_MARKETS[region]
 standing=regional_trade.get(region,0)
 if k==0:
  if buy(p,135):pickup(p,'wood' if stock=='timber' else stock,6);msg(f'{name}: loaded six units of {stock}.')
 elif k==1:
  item='wood' if demand=='timber' else demand
  if p.get(item,0)>=4:
   p[item]-=4;coin(p,230+min(160,standing*4));regional_trade[region]=min(100,standing+2)
   msg(f'Export shipment delivered at {name}. Trade standing increased.')
  else:msg(f'The market needs 4 {item}; you only have {p.get(item,0)}.')
 elif k==2:
  if buy(p,175):pickup(p,'food',4);pickup(p,'water',3);msg('Bought provisions for the crossing.')
 elif k==3:
  if standing>=10:msg('Your trading post already has maximum local standing.')
  elif buy(p,600):regional_trade[region]=standing+1;msg('Investment completed. Regional standing improved.')
 else:msg(f'{region}: trading standing {standing}/10. Commodity demand: {demand}.')

def fantasy_site_choose(p,name,k):
 region=next((r for r,(_,_,label) in ISLAND_FANTASY.items() if label==name),None)
 if region is None:return
 if k==0:
  if fantasy_quests.get(region):msg('This island spirit has already rewarded this save.');return
  if p.get('gems',0)<2:msg('The spirit requests two gems.');return
  p['gems']-=2;fantasy_quests[region]=True
  reward={'Amber Wilds':650,'Frostwood Reach':950,'Sunken Keys':1400}[region]
  coin(p,reward);xp(p,80);msg(f'{name}: the ancient bargain succeeds. +{reward} coins and experience!')
 elif k==1:
  if buy(p,150):
   heal=random.randint(14,35);p['hp']=min(100,p['hp']+heal);p['sanity']=min(100,p.get('sanity',75)+12)
   msg(f'{name} grants +{heal} health and +12 sanity.')
 elif k==2:msg(f'Ancient {region} shrine. One permanent gem-offering reward per world. The strange magic is real.')

def options(name,p):
 if name in [v[2] for v in ISLAND_MARKETS.values()]:return regional_market_options(name,p)
 if name in [v[2] for v in ISLAND_FANTASY.values()]:return fantasy_site_options(name,p)
 if name=='PUBLIC WORKS':return civic_options(p)
 if name=='COUNCIL':return council_options(p)
 if name=='PRESERVE':return preserve_options(p)
 if name=='VILLAGE':return settlement_options(p)
 if name=='ARMY':return army_options(p)
 if name=='MACHINE':return machine_options(p)
 if name=='ENCOUNTER':
  site=next((a for a in all_encounters() if a['id']==p.get('encounter_id')),None)
  return [c['text'] for c in site['choices']] if site else ['Leave']
 if name=='MOD_CRAFT':return [f'Craft {rid} => {rec["quantity"]} {rec["output"]} | '+', '.join(f'{k}:{v}' for k,v in rec['requires'].items()) for rid,rec in EXT_MODS.recipes.items()] or ['No mod recipes loaded']
 if name=='EXCHANGE':return stock_options(p)
 if name=='CASINO':return casino_options(p)
 if name=='BUSINESS':return business_options(p)
 if name=='EXPANSION':return expansion_options()
 if name=='FORGE':return forge_options(p)
 if name=='CONTRACTS':return contract_options(p)
 if name=='INVENTOR':
  rows=[]
  for title,req,w,stone,scrap,ore,gems,coins,rp,seconds,item,amount in PROJECTS:
   marker='BUILT' if title in workshops else 'LOCKED' if era<req else f'{coins}c {rp}RP, {w}w {stone}s {scrap}scr {ore}ore {gems}g'
   rows.append(f'{title} [{ERAS[req]}]: {marker}')
  return rows
 if name=='RESEARCH':
  if era>=len(ERAS)-1:return ['All eras unlocked — enjoy the future!']
  rp,w,st,ore,gem,coins=ERA_COSTS[era]
  return [f'Advance to {ERAS[era+1]}: {rp} RP, {w} wood, {st} stone, {ore} ore, {gem} gems, {coins}c',
          f'Current age: {era_name()} | Research: {knowledge} RP',
          'Earn research through gathering, fighting, exploring and crafting',
          'Tech unlocks: Ancient > Medieval > Renaissance > Industrial > Modern > Digital > Rift']
 if name=='MINE':
  cave=caves.get(p.get('cave_tile'),{})
  d=int(cave.get('depth',0));return [f'Dig tunnel deeper (depth {d}/8; 8 energy)',
   f'Mine cave vein (depth {d}, available ore {max(0,int(cave.get("vein",0)))})',
   'Craft unlit torches (2 wood + 1 fiber → 3)',
   'Craft flint & steel (2 flint + 1 ingot + 1 scrap)',
   'Light torches (1 unlit torch + flint & steel)',
   'Inspect cave safety']
 if name=='EXPEDITION':return quest_options(p)
 if name=='MOD WORKSHOP':return options('MOD_CRAFT',p)
 if name=='SHADY':return ['Buy dubious treasure map (200c)','Buy regional explorer map (350c)','Mystery package (100c)','Black-market scrap bundle (180c)','Buy "ultra powerful" weapon (450c)','Buy "god-tier annihilator" (900c)','Sell 1 gem (220c)','Ask for a free tip']
 if name=='GEAR':return ['Buy thermal coat (700c)','Buy canteen (+2 bottles, 400c)','Buy field kit (+1 life saver, 500c)','Buy sail (600c)','Buy pickaxe (550c)','Buy axe (550c)','Buy map beacon (900c)','Buy solar lamp (700c)','Repair weapon (2 stone, 1 scrap, 90c)','Sharpen weapon (3 stone, 160c)','Buy portal gun (12000c, 3 gems, 8 scrap)','Repair portal gun (750c, 1 gem, 5 scrap)','Recharge portal gun (400c, 3 scrap)','Buy rift stabilizer (2800c, 2 gems)','Buy terrain scanner (1500c, 4 scrap)']
 if name=='FURNITURE':return furniture_options(p)
 if name=='INVENTORY':return carry_menu(p)
 if name=='CONTAINER':return container_menu(p)
 if name=='HOUSING':return ['Get bedroll (4 wood)','Make blanket (3 scrap)','Pitch tent (8 wood, 2 stone)','Build your own shack (18 wood, 12 stone, 250c)','Rent shack (120c / 10 min)','Rent cabin (300c / 10 min)','Build your own cabin (30 wood, 20 stone, 1000c)','Upgrade cottage (45 wood, 30 stone, 4000c)','Buy house (70 wood, 50 stone, 12000c)','Rest at shelter','Add furniture (500c, 4 wood)','Craft hammock (5 wood, 2 scrap)','Craft tree tent (12 wood, 5 scrap)','Craft campfire (5 wood, 2 stone)','Build quinzhee (winter, 6 snow)','Build igloo (winter, 12 snow, 4 stone)','Build treehouse (forest, 22 wood, 8 scrap, 350c)','End rental']
 if name=='ARCADE':return ['Coin flip: wager 50','Dice duel: wager 100','Lucky spin: wager 200']
 if name=='DOCK':return ['Buy fish bucket (120c)','Sell all fish','Buy bottled water x2 (80c)','Craft raft (14 wood, 3 scrap)','Craft boat (24 wood, 5 stone, 5 scrap, 300c)']
 if name=='BANK': return ['Deposit 100','Deposit ALL','Withdraw 100','Withdraw ALL','Upgrade capacity (500c)']
 if name=='SHOP': return ['Life saver (350c)','Sword (200c)','Bow (400c)','Rifle (900c)','Seeds x3 (60c)','Food x3 (90c)','Heal (70c)','Fish bucket (120c)','Water bottles x2 (80c)','Sell all fish','Buy torch (80c)','Buy food x5 (140c)','Explorer boots (600c)','Treasure compass (900c)','Lucky charm (1200c)','Buy bivy sack (420c)']
 if name=='FARM': return ['Plant crop (1 seed)','Harvest nearby crops','Buy seeds (40c)','Plant apple tree (2 seeds)','Plant pear tree (2 seeds)','Plant peach tree (2 seeds)','Plant plum tree (2 seeds)','Harvest nearby fruit','Inspect nearby orchard','Treat sick trees (1 salt, 2 water)','Prune nearby trees (axe)','Plant Money Tree (arcade prize)','Plant herbs (1 seed)','Harvest herbs','Buy orchard seeds (50c)','Harvest nearby Money Trees','Check soil moisture / NPK','Water nearby plots (1 bottle each)','Compost nearby plots (2 food each)','Plant nitrogen-fixing beans (1 seed)','Remove dead plants / weeds']
 if name=='MATERIALS':return material_options()
 if name=='BUILDER': return ['Build wall (3 wood)','Build house tile (8 wood,5 stone)','Build tower (6 stone)','Build bridge (4 wood)','Build floor (2 wood)','Build roof (4 wood)','Build door (3 wood)','Build window (2 wood,1 stone)','Build workbench','Build rain collector','Build furniture','Process construction materials']
 if name=='PRESTIGE': return [f'Prestige (level {5+3*p["prestige"]}, net worth {1500*(p["prestige"]+1)**2})']
 if name=='CAMP': return ['Rest: restore energy (free)','Cook food x1 (1 wood)','Craft torch (2 wood)','Craft wooden shield (5 wood)','Craft campfire (5 wood, 2 stone)','Craft hammock (5 wood, 2 scrap)','Craft tree tent (12 wood, 5 scrap)','Workbench (10 wood, 3 stone, 2 scrap)','Rain collector (6 wood, 2 stone, 3 scrap)','Tarp (4 wood, 4 scrap)','Sleeping bag (3 wood, 6 scrap)','Raft (14 wood, 3 scrap)','Boat (24 wood, 5 stone, 5 scrap, 300c)','Collect rainwater','Stoke nearby campfire (1 wood)'] + ['Craft '+kind for kind in RECIPES_EXTRA]
 if name=='TRADER': return ['Sell ore (45c each)','Sell gems (250c each)','Buy life saver (350c)','Buy food x5 (140c)','Buy wooden crate (160c)','Buy large chest (600c)','Buy backpack (+3 slots, 650c)','Buy supply bucket (90c)']
 if name=='ARENA': return ['Fight monster (+coins and XP)','Heal (70c)']
 return []

def buy(p,cost):
 if p['wallet']<cost: msg('Not enough coins. Your wallet is on a diet.'); return False
 p['wallet']-=cost; return True

def mine_choose(p,i,k):
 """Cave mining and ignition are separate actions; no instant free deep ore."""
 cave=caves.get(p.get('cave_tile'))
 if not cave:return
 depth=max(0,min(8,int(cave.get('depth',0))))
 has_light=bool(p.get('torches') or p.get('solar_lamp'))
 if k==0:
  if depth>=8:msg('The tunnel is already at maximum depth.');return
  if p.get('energy',0)<8:msg('Too exhausted to dig deeper.');return
  if depth>=2 and not p.get('pickaxe'):msg('Depth 3+ requires a pickaxe.');return
  if depth>=1 and not has_light:msg('Too dark to dig deeper. Bring and light a torch first.');return
  p['energy']=max(0,p['energy']-8)
  cave['depth']=depth+1;cave['vein']=int(cave.get('vein',0))+random.randint(2,5)
  cave['stability']=max(0,int(cave.get('stability',65))-random.randint(3,8))
  if random.random() < (0.08 if cave.get('reinforced') else .16):
   injury=random.randint(3,12);p['hp']-=injury;msg(f'Cave roof shifted! Lost {injury} HP.')
   if p['hp']<=0:death(p,i)
  else:msg(f'Dug down to layer {depth+1}. Ore vein exposed. Stability: {cave["stability"]}%.')
 elif k==1:
  if int(cave.get('vein',0))<=0:msg('This layer is exhausted. Dig deeper to expose another vein.');return
  if not has_light:msg('You cannot see the vein. Light a torch first.');return
  if p.get('energy',0)<6:msg('Not enough energy to mine.');return
  if depth>=3 and not p.get('pickaxe'):msg('Hard rock needs a pickaxe.');return
  p['energy']=max(0,p['energy']-6);cave['vein']-=1
  choices=['coal','copper_ore','iron_ore','silver_ore','gold_ore']
  weights=[max(5,45-depth*4),max(2,28-depth*2),8+depth*4,max(0,(depth-2)*5),max(0,(depth-4)*4)]
  ore=random.choices(choices,weights=weights,k=1)[0]
  pickup(p,ore,1);msg(f'Mined {ore.replace("_"," ")} at cave depth {depth}.')
  if random.random()<(.01 if cave.get('reinforced') else .045):
   p['hp']-=7;msg('A rock broke loose: -7 HP.')
   if p['hp']<=0:death(p,i)
 elif k==2:
  costs={'wood':2,'fiber':1}
  if has_construction(p,costs):spend_construction(p,costs);pickup(p,'unlit_torches',3);msg('Crafted three unlit torches.')
 elif k==3:
  costs={'flint':2,'ingot':1,'scrap':1}
  if p.get('flint_steel'):msg('You already have flint and steel.');return
  if has_construction(p,costs):spend_construction(p,costs);p['flint_steel']=1;msg('Made flint and steel. You can now light torches.')
 elif k==4:
  if not p.get('flint_steel'):msg('Craft flint and steel first.');return
  if not has_construction(p,{'unlit_torches':1}):return
  spend_construction(p,{'unlit_torches':1});pickup(p,'torches',1);msg('Lit a torch. The cave is much easier to navigate.')
 elif k==5:
  msg(f'Cave depth {depth}/8; stability {cave.get("stability",65)}%; ore remaining {cave.get("vein",0)}; '+('reinforced' if cave.get('reinforced') else 'UNREINFORCED'))

def choose(p,i):
 global era,knowledge
 name=p['menu']; k=p['selection']; opts=options(name,p)
 if not opts:return
 if name in [v[2] for v in ISLAND_MARKETS.values()]:regional_market_choose(p,name,k);p['menu']=None;save();return
 if name in [v[2] for v in ISLAND_FANTASY.values()]:fantasy_site_choose(p,name,k);p['menu']=None;save();return
 if name=='FURNITURE':furniture_choose(p,i,k);return
 if name=='MINE':mine_choose(p,i,k);p['menu']=None;save();return
 if name=='PUBLIC WORKS':civic_choose(p,k);p['menu']=None;save();return
 if name=='COUNCIL':council_choose(p,k);p['menu']=None;save();return
 if name=='PRESERVE':preserve_choose(p,k);p['menu']=None;save();return
 if name=='VILLAGE':settlement_choose(p,k);p['menu']=None;save();return
 if name=='ARMY':army_choose(p,k);p['menu']=None;save();return
 if name=='MACHINE':machine_choose(p,k);p['menu']=None;save();return
 if name=='ENCOUNTER':encounter_choose(p,i,k);return
 if name=='MOD_CRAFT':
  entries=list(EXT_MODS.recipes.items())
  if k<len(entries):
   rid,rec=entries[k]
   if era<rec['era']:msg(f'Recipe {rid} requires era {rec["era"]}.')
   elif rec['output'] not in ITEMS:msg(f'Recipe {rid} produces an unregistered item; blocked.')
   elif all(p.get(item,0)+shared_items.get(item,0)>=qty for item,qty in rec['requires'].items()):
    for item,qty in rec['requires'].items():
     from_pack=min(qty,p.get(item,0));p[item]-=from_pack
     shared_items[item]=shared_items.get(item,0)-(qty-from_pack)
    pickup(p,rec['output'],rec['quantity']);msg(f'Crafted {rec["quantity"]} {rec["output"]}!')
   else:msg('Missing ingredients in pack and party stockpile.')
  p['menu']=None;save();return
 if name=='MATERIALS':
  process_material(p,k);p['menu']=None;save();return
 if name=='EXCHANGE':
  do_stock_trade(p,k);p['menu']=None;save();return
 if name=='CASINO':
  if k>0:
   wager=[0,100,250,500,1000][k]
   if buy(p,wager):
    payouts=[0,180,750,2200,5000]
    odds=[0,.35,.17,.06,.03]
    if random.random()<odds[k]:
     p['wallet']+=payouts[k];msg(f'Casino paid {payouts[k]}c. The manager is furious.')
    else:
     p['casino_losses']=p.get('casino_losses',0)+wager
     if p['casino_losses']>=1000:unlock_achievement(p,'casino_broke')
     msg(f'Casino kept {wager}c. The house thanks you for your donation.')
  p['menu']=None;save();return
 if name=='BUSINESS':
  if not p.get('business_owned'):
   if k==0:
    business_materials={'planks':6,'nails':4,'glass':1,'bricks':2}
    if p['wallet']>=2200 and p['wood']>=12 and p['scrap']>=5 and has_construction(p,business_materials):
     spend_construction(p,business_materials)
     p['wallet']-=2200;p['wood']-=12;p['scrap']-=5;p['business_owned']=True
     msg('Souvenir stand opened. Expenses are not optional.')
    else:msg('Need 2200c, 12 wood, 5 scrap to open the stand.')
  elif k==1:
   if buy(p,60):
    income=random.choice([0,12,20,35,50,65,85,115,160,205])
    p['wallet']+=income;p['business_profit']+=income-60
    msg(f'Souvenir business: income {income}c minus 60c overhead = {income-60:+d}c.')
    if p['business_profit']>=350:unlock_achievement(p,'business')
  elif k==2:
   p['business_owned']=False;msg('Business shut down. No refunds on the sign.')
  p['menu']=None;save();return
 if name=='EXPANSION':
  next_region=max(unlocked_regions)+1
  if k!=next_region-1 or next_region>3:
   msg('Expansion permits must be purchased in order, one island at a time.')
  else:
   island,coins,wood,stone=EXPANSION_COSTS[k]
   if p['wallet']<coins or p.get('wood',0)<wood or p.get('stone',0)<stone:
    msg(f'{island} needs {coins} coins, {wood} wood and {stone} stone. Withdraw from shared supplies if needed.')
   else:
    p['wallet']-=coins;p['wood']-=wood;p['stone']-=stone
    unlocked_regions.append(next_region)
    msg(f'EXPANSION UNLOCKED: {island}! All players can now land and build there.')
  p['menu']=None;save();return
 if name=='CONTRACTS':
  if k<3:
   rank=p.get('contract_rank',0)
   title,item,amount,reward=CONTRACT_TYPES[(rank+k)%len(CONTRACT_TYPES)]
   if p.get(item,0)<amount:msg(f'Need {amount} {item}. Bring the full shipment in your backpack.')
   else:
    p[item]-=amount;coin(p,reward);xp(p,22);knowledge+=10;p['contract_rank']=rank+1
    msg(f'P{i+1} delivered {title}! +{reward} coins and +10 research. Nobody asked about the invoice.')
  else:msg('Withdraw materials from shared storage before claiming contracts.')
  p['menu']=None;save();return

 if name=='INVENTOR':
  title,req,w,stone,scrap,ore,gems,coins,rp,seconds,item,amount=PROJECTS[k]
  if title in workshops:msg(title+' already built. It supplies the shared party stash automatically.')
  elif era<req:msg('Technology locked: reach '+ERAS[req]+' first.')
  elif knowledge<rp:msg(f'Need {rp-knowledge} more research points for {title}.')
  elif any(p.get(key,0)<qty for key,qty in [('wood',w),('stone',stone),('scrap',scrap),('ore',ore),('gems',gems),('wallet',coins)]):msg('Missing materials. Withdraw from party storage or gather more.')
  else:
   for key,qty in [('wood',w),('stone',stone),('scrap',scrap),('ore',ore),('gems',gems),('wallet',coins)]:p[key]-=qty
   knowledge-=rp;workshops[title]=0;xp(p,35+req*12)
   tx,ty=tile(p);structures.append([tx,ty,'workshop'+str(k)])
   msg(f'Party built {title}! Automatic output unlocked: {amount} {item} / {seconds}s.')
  p['menu']=None;save();return
 if name=='RESEARCH':
  if k!=0:msg('Research Hall: advance your civilization by playing and collecting resources.')
  elif era>=len(ERAS)-1:msg('Your civilization has already mastered the Rift Age.')
  else:
   rp,w,st,ore,gem,coins=ERA_COSTS[era]
   if knowledge<rp:msg(f'Need {rp-knowledge} more research points before the next era.')
   elif any(p.get(key,0)<qty for key,qty in [('wood',w),('stone',st),('ore',ore),('gems',gem),('wallet',coins)]):msg('Not enough materials/coins. Withdraw shared supplies if needed.')
   else:
    knowledge-=rp;p['wood']-=w;p['stone']-=st;p['ore']-=ore;p['gems']-=gem;p['wallet']-=coins;era+=1
    xp(p,45*era);msg(f'CIVILIZATION ADVANCED! {ERAS[era]} unlocked for ALL players!')
  p['menu']=None;save();return
 if name=='FORGE':
  forge_action(p,k,i);p['menu']=None;save();return
 if name=='GEAR':
  required=6 if k in (10,11,12,13) else 5 if k in (6,7,14) else 4 if k in (0,2,3) else 3 if k in (4,5) else 1
  if not tech_gate(required):p['menu']=None;return
 if name=='SHADY' and k in (4,5) and not tech_gate(3):p['menu']=None;return
 if name=='SHOP':
  required=3 if k==3 else 1 if k in (1,2) else 4 if k in (12,13,14) else 0
  if not tech_gate(required):p['menu']=None;return
 if name=='DOCK' and k==4 and not tech_gate(1):p['menu']=None;return
 if name=='CAMP' and k==12 and not tech_gate(1):p['menu']=None;return
 if name=='BUILDER' and k in (9,10) and not tech_gate(2):p['menu']=None;return
 if name=='HOUSING' and k in (7,8) and not tech_gate(1 if k==7 else 3):p['menu']=None;return
 if name=='SHADY':
  p['dealer_visits']=p.get('dealer_visits',0)+1
  if k==0 and buy(p,200):
   target=random.choice(landmarks)
   ident=f'{target[0]},{target[1]}'
   if ident in p['treasures']:msg('Your map led to a looted chest. The dealer has disappeared behind a tree.')
   else:
    for yy in range(max(0,target[1]-6),min(N,target[1]+7)):
     for xx in range(max(0,target[0]-6),min(N,target[0]+7)):explored_sets[i].add(yy*N+xx) if land_available(xx,yy) else None
    msg(f'Purchased a suspicious map! New clue marked near tile {target[0]}, {target[1]}.')
  elif k==1:
   remaining=[r for r in REGION_MAPS if r[0] not in p['maps_owned']]
   if not remaining:msg('You already own every regional chart. The merchant sells you a compliment instead.')
   elif buy(p,350):
    title,cx,cy,radius,_=remaining[0];p['maps_owned'].append(title)
    # Reveal a sampled chart grid, not every tile, leaving exploration worthwhile.
    for yy in range(max(0,cy-radius),min(N,cy+radius+1),3):
     for xx in range(max(0,cx-radius),min(N,cx+radius+1),3):
      if (xx-cx)**2+(yy-cy)**2<=radius**2:explored_sets[i].add(yy*N+xx) if land_available(xx,yy) else None
    msg(f'Bought the {title} map. Its sketch reveals scattered terrain and navigation clues.')
  elif k==2 and buy(p,100):
   if random.random()<.27:msg('Package contained a wet sock. It is not even your size.')
   else:
    thing=random.choice(['food','scrap','ore','stone']);qty=random.randint(2,7);pickup(p,thing,qty);msg(f'Mystery package: {qty} {thing}! Surprisingly legal.')
  elif k==3 and buy(p,180):
   amount=random.randint(3,9);pickup(p,'scrap',amount);msg(f'Got {amount} scrap. The dealer insists it fell off a wagon.')
  elif k==4 and buy(p,450):
   roll=random.random()
   flashy=random.choice(['Thunderfang Obliterator','Voidblade EX','Ultra Doom Poker','Galaxy Ripper'])
   p['fake_weapon_name']=flashy
   if roll<0.58:
    p['weapon']=max(p['weapon'],1);p['weapon_condition']=random.randint(6,28)
    msg(f'You bought {flashy}! It turns out to be a painted bargain-bin sword with {p['weapon_condition']} durability.')
   elif roll<0.88:
    p['weapon']=max(p['weapon'],2);p['weapon_condition']=random.randint(45,85)
    msg(f'{flashy} is mostly hype, but at least it kind of works. Enjoy your suspicious mid-tier weapon.')
   else:
    p['weapon']=max(p['weapon'],3);p['weapon_condition']=115
    msg(f'Shockingly, {flashy} is real-ish! You got a scary weapon and the dealer looks offended.')
  elif k==5 and buy(p,900):
   roll=random.random()
   flashy=random.choice(['Apocalypse 9000','Godslapper Prime','Celestial Annihilator','Infinity Goose Cannon'])
   p['fake_weapon_name']=flashy
   if roll<0.68:
    p['weapon']=max(p['weapon'],1);p['weapon_condition']=random.randint(1,12)
    msg(f'{flashy} was a scam. It makes cool noises, then a spring falls out. Durability: {p['weapon_condition']}.')
   elif roll<0.93:
    p['weapon']=max(p['weapon'],2);p['weapon_condition']=random.randint(55,95)
    msg(f'{flashy} is not god-tier, but it is decent enough. You were only medium-scammed.')
   else:
    p['weapon']=max(p['weapon'],3);p['weapon_condition']=125
    msg(f'Against all odds, {flashy} is terrifyingly effective. Somewhere, a shady dealer loses money.')
  elif k==6:
   if p.get('gems',0)>0:p['gems']-=1;coin(p,220);msg('Sold a gem for 220 coins. The dealer smiled suspiciously.')
   else:msg('You have no gems. The dealer offers an imaginary one.')
  elif k==7:
   msg(random.choice(['The best treasure is the insurance we never bought.','Never trust a map drawn on a napkin. Especially mine.','A merchant in a trench coat is still just three raccoons.','Try crossing the ocean. The big rewards are far from town.','If a weapon glows but smells like paint, walk away.']))
  p['menu']=None;save();return
 if name=='GEAR' and k in (10,11,12,13,14):
  if k==10:
   if p.get('portal_gun'):msg('You already have a portal gun. One existential crisis at a time.')
   elif p['wallet']<12000 or p['gems']<3 or p['scrap']<8:msg('Portal gun requires 12000 coins, 3 gems and 8 scrap.')
   else:
    p['wallet']-=12000;p['gems']-=3;p['scrap']-=8
    p['portal_gun']=1;p['portal_condition']=100;p['portal_charges']=5
    msg('PORTAL GUN ACQUIRED! Aim by moving, fire with H / apostrophe / controller button 13.')
  elif k==11:
   if not p.get('portal_gun'):msg('You cannot repair a gun you do not own.')
   elif p['portal_condition']>=100:msg('Portal gun already at full condition.')
   elif p['wallet']<750 or p['gems']<1 or p['scrap']<5:msg('Portal repairs need 750 coins, 1 gem and 5 scrap.')
   else:
    p['wallet']-=750;p['gems']-=1;p['scrap']-=5;p['portal_condition']=100
    msg('Portal gun repaired. The engineer signed the receipt in a different dimension.')
  elif k==12:
   if not p.get('portal_gun'):msg('No portal gun. A battery for nothing would be peak capitalism.')
   elif p['portal_charges']>=5:msg('Portal gun battery is already full.')
   elif p['wallet']<400 or p['scrap']<3:msg('Recharging needs 400 coins and 3 scrap.')
   else:
    p['wallet']-=400;p['scrap']-=3;p['portal_charges']=5
    msg('Portal gun recharged: 5 rifts ready.')
  elif k==13:
   if p.get('portal_stabilizer'):msg('Rift stabilizer already installed.')
   elif not p.get('portal_gun'):msg('You need a portal gun before stabilizing its rifts.')
   elif p['wallet']<2800 or p['gems']<2:msg('Stabilizer requires 2800 coins and 2 gems.')
   else:
    p['wallet']-=2800;p['gems']-=2;p['portal_stabilizer']=1
    msg('Rift stabilizer installed: longer warp range, lower wear and quicker cooldown.')
  elif k==14:
   if p.get('portable_scanner'):msg('Terrain scanner already owned.')
   elif p['wallet']<1500 or p['scrap']<4:msg('Scanner requires 1500 coins and 4 scrap.')
   else:
    p['wallet']-=1500;p['scrap']-=4;p['portable_scanner']=1
    msg('Terrain scanner acquired: reveal a wider area while exploring.')
  p['menu']=None;save();return
 if name=='GEAR' and k in (8,9):
  if k==8:
   if p['stone']>=2 and p['scrap']>=1 and p['wallet']>=90:
    p['stone']-=2;p['scrap']-=1;p['wallet']-=90;p['weapon_condition']=100;msg('Weapon repaired! The goose blacksmith approves.')
   else:msg('Repair requires 2 stone, 1 scrap and 90 coins.')
  else:
   if p['stone']>=3 and p['wallet']>=160:
    p['stone']-=3;p['wallet']-=160;p['weapon_condition']=min(125,p.get('weapon_condition',100)+45);msg('Weapon sharpened. Very pointy.')
   else:msg('Sharpening requires 3 stone and 160 coins.')
  p['menu']=None;save();return
 if name=='EXPEDITION':
  title,stat,goal,reward=QUESTS[k]
  if title in p.get('quests_claimed',[]):msg('Contract already claimed. The mayor says no double dipping.')
  elif p.get('stats',{}).get(stat,0)<goal:msg('Contract unfinished. Get out there and cause productive chaos.')
  else:
   p['quests_claimed'].append(title);coin(p,reward);xp(p,30);msg(f'P{i+1} claimed {reward} coins for {title}!')
  p['menu']=None;save();return
 if name=='GEAR':
  kind=['thermal_coat','canteen','field_kit','sail','pickaxe','axe','map_beacon','solar_lamp'][k]
  price=[700,400,500,600,550,550,900,700][k]
  if p.get(kind):msg('Already owned. The shopkeeper refuses to sell you another identical brain cell.')
  elif buy(p,price):
   p[kind]=1
   if kind=='canteen':p['water_bottles']+=2
   if kind=='field_kit':pickup(p,'life',1)
   if kind=='solar_lamp':pickup(p,'torches',1)
   msg('Purchased '+kind.replace('_',' ')+'.')
  p['menu']=None;save();return
 if name in ('INVENTORY','CONTAINER'):
  inventory_choice(p,i);return
 if name=='CAMP' and k>=15:
  kind=list(RECIPES_EXTRA)[k-15]
  required=5 if kind in ('solar lamp','map beacon') else 4 if kind in ('field kit','thermal coat','sail') else 3 if kind in ('pickaxe','axe','camp stove','water filter') else 1
  if tech_gate(required):craft_extra(p,kind,i);save()
  p['menu']=None;return
 if name=='TRADER' and k>=4:
  kind=['storage chest','large chest','backpack','supply bucket'][k-4];price=[160,600,650,90][k-4]
  if buy(p,price):
   if kind=='backpack':p['inventory_slots']=min(30,p['inventory_slots']+3)
   else:
    x,y=tile(p);tag='bucket_store' if kind=='supply bucket' else 'chest';structures.append([x,y,tag+str(i+1)]);storage_boxes[f'{x},{y}']={'_max_types':4 if kind=='supply bucket' else 24 if kind=='large chest' else 12}
   msg(f'P{i+1} bought {kind}.')
  p['menu']=None;save();return
 if name=='HOUSING':
  if k==0:
   if p['wood']>=4:p['wood']-=4;p['bedroll']=1;msg('Bedroll crafted. Your spine gave it a 2-star review.')
   else:msg('Need 4 wood for a bedroll.')
  elif k==1:
   if p['scrap']>=3:p['scrap']-=3;p['blanket']=1;msg('Blanket made. You are now slightly less of a human popsicle.')
   else:msg('Need 3 scrap. Search the beach or forests.')
  elif k in (2,3,6,7,8):
   recipes={2:(8,2,0,1,'Tent'),3:(18,12,250,2,'Shack'),6:(30,20,1000,3,'Cabin'),7:(45,30,4000,4,'Cottage'),8:(70,50,12000,5,'House')}
   needwood,needstone,price,target,title=recipes[k]
   prereq={1:0,2:1,3:2,4:3,5:4}[target]
   if p['housing']!=prereq:msg('Housing upgrades must be unlocked in order. No skipping the cardboard era.')
   elif p['wood']<needwood or p['stone']<needstone or p['wallet']<price:msg('Not enough wood, stone or coins for this home.')
   elif not has_construction(p,HOUSING_EXTRAS.get(k,{})):pass
   else:
    spend_construction(p,HOUSING_EXTRAS.get(k,{}))
    p['wood']-=needwood;p['stone']-=needstone;p['wallet']-=price;p['housing']=target
    x,y=tile(p);p['home_tile']=[x,y];structures.append([x,y,'home'+str(i+1)])
    xp(p,24+target*11);msg(f'P{i+1} now owns a {title}! The housing market is bewildered.')
  elif k in (4,5):
   cost,label=(120,'shack') if k==4 else (300,'cabin')
   if buy(p,cost):
    p['rental']=label;p['rent_until']=time.time()+600
    msg(f'P{i+1} rented a {label} for ten real minutes. Your landlord accepts payment in memes.')
  elif k==9:rest_at_shelter(p)
  elif k==10:
   if p['housing']<2 and not p.get('treehouse'):msg('You need a sturdier home before ordering furniture from nowhere.')
   elif p['wood']>=4 and buy(p,500):p['wood']-=4;p['home_furnish']+=1;msg('Furniture purchased. A suspiciously fancy chair appears.')
   else:msg('Need 4 wood and 500 coins.')
  elif k in (11,12,13):
   wood,stone,scrap,kind={11:(5,0,2,'hammock'),12:(12,0,5,'tree_tent'),13:(5,2,0,'campfire')}[k]
   if p['wood']<wood or p['stone']<stone or p['scrap']<scrap:msg(f'Need {wood} wood, {stone} stone and {scrap} scrap.')
   else:
    p['wood']-=wood;p['stone']-=stone;p['scrap']-=scrap
    tx,ty=tile(p);structures.append([tx,ty,kind+str(i+1)])
    if kind=='hammock':p['hammock']+=1
    elif kind=='tree_tent':p['tree_tent']+=1
    else:p['campfires']+=1
    xp(p,12)
    msg('Tree tent crafted! Ropes lash it to the trees so your back does not freeze on the ground.' if kind=='tree_tent' else f'P{i+1} crafted a {kind.replace("_"," ")}! The squirrels demand zoning permits.')
  elif k==14:
   if season!='Winter':msg('A quinzhee needs winter snow. The climate disagrees.')
   elif p['snow_blocks']<6:msg('Need 6 packed snow blocks for a quinzhee.')
   else:
    p['snow_blocks']-=6;p['quinzee']=1;tx,ty=tile(p);structures.append([tx,ty,'quinzee'+str(i+1)])
    if not p['home_tile']:p['home_tile']=[tx,ty]
    xp(p,16);msg('Quinzhee built! You carved a shelter from a snow mound like a frosty goblin architect.')
  elif k==15:
   if season!='Winter':msg('Igloos need winter. Current season: not snowy enough.')
   elif p['snow_blocks']<12 or p['stone']<4:msg('Need 12 snow blocks and 4 stone for an igloo.')
   else:
    p['snow_blocks']-=12;p['stone']-=4;p['igloo']=1;tx,ty=tile(p);structures.append([tx,ty,'igloo'+str(i+1)])
    if not p['home_tile']:p['home_tile']=[tx,ty]
    xp(p,22);msg('Igloo completed. Architects are furious that snow won.')
  elif k==16:
   tx,ty=tile(p)
   if terrain[ty][tx]!='forest':msg('Treehouses must be anchored in the forest.')
   elif p['wood']<22 or p['scrap']<8 or p['wallet']<350:msg('Need 22 wood, 8 scrap and 350 coins.')
   elif not has_construction(p,{'planks':8,'lashings':6,'nails':4}):pass
   else:
    spend_construction(p,{'planks':8,'lashings':6,'nails':4})
    p['wood']-=22;p['scrap']-=8;p['wallet']-=350;p['treehouse']=1
    p['home_tile']=[tx,ty];structures.append([tx,ty,'treehouse'+str(i+1)])
    xp(p,32);msg("Treehouse built! You are now elevated above many of life's bad decisions.")
  elif k==17:
   p['rental']='';p['rent_until']=0;msg('Rental ended. Deposit returned: absolutely nothing.')
 elif name=='ARCADE':
  wager=[50,100,200][k]
  if buy(p,wager):
   odds=[.49,.42,.24][k]
   if random.random()<odds:
    reward=[100,250,1000][k];coin(p,reward);xp(p,8);msg(f'P{i+1} won {reward} coins! The arcade owner is crying.')
   else:msg(random.choice(['The slot machine ate your lunch money.','You rolled a potato. Critical failure.','The coin landed on its edge. The house still wins.']))
 elif name=='DOCK':
  if k==0 and buy(p,120):p['fish_bucket']+=1
  elif k==1:
   earnings=sum(MOD['fish'].get(f,{}).get('value',0)*n for f,n in p['fish_caught'].items());p['fish_caught']={};coin(p,earnings);msg(f'Sold your fish for {earnings} coins.')
  elif k==2 and buy(p,80):p['water_bottles']+=2
  elif k in (3,4):
   kind='raft' if k==3 else 'boat'
   if kind=='boat' and not (p['craft_bench'] or bench_near(p)):msg('Boat requires a workbench first.')
   else:recipes_build(p,kind,i)
 elif name=='BANK':
  if k==0: amt=min(100,p['wallet'],p['cap']-p['bank']); p['wallet']-=amt;p['bank']+=amt
  elif k==1: amt=min(p['wallet'],p['cap']-p['bank']);p['wallet']-=amt;p['bank']+=amt
  elif k==2: amt=min(100,p['bank']);p['bank']-=amt;p['wallet']+=amt
  elif k==3: amt=p['bank'];p['bank']=0;p['wallet']+=amt
  elif buy(p,500): p['cap']+=1000;msg('Bank expanded! The banker bought another spreadsheet.')
  msg(f'P{i+1} bank balance: {p["bank"]}/{p["cap"]}')
 elif name=='SHOP':
  if k==0 and buy(p,350):p['life']+=1
  elif k in (1,2,3) and buy(p,[0,200,400,900][k]):p['weapon']=max(p['weapon'],k)
  elif k==4 and buy(p,60):p['seed']+=3
  elif k==5 and buy(p,90):p['food']+=3
  elif k==6 and buy(p,70):p['hp']=p['maxhp']
  elif k==7 and buy(p,120):p['fish_bucket']+=1
  elif k==8 and buy(p,80):p['water_bottles']+=2
  elif k==10 and buy(p,80):p['torches']+=1
  elif k==11 and buy(p,140):p['food']+=5
  elif k==12 and not p['boots'] and buy(p,600):p['boots']=1;msg('Explorer boots equipped. Faster walking forever!')
  elif k==13 and not p['compass'] and buy(p,900):p['compass']=1;msg('Treasure compass acquired. Look for the gold direction marker!')
  elif k==14 and not p['luck'] and buy(p,1200):p['luck']=1;msg('Lucky charm equipped. Your fish are now slightly less judgmental.')
  elif k==15 and buy(p,420):p['bivy_sack']=p.get('bivy_sack',0)+1;msg('Bought a bivy sack. Put it around a sleeping bag using F7.')
  elif k==9:
   earnings=sum(MOD['fish'].get(f,{}).get('value',0)*n for f,n in p['fish_caught'].items())
   p['fish_caught']={};coin(p,earnings);msg(f'P{i+1} sold fish for {earnings} coins. Fish capitalism.')
 elif name=='FARM':
  x,y=tile(p);key=f'{x},{y}'
  if k==0 and p['seed']>0 and key not in crops and key not in orchards and soil_at(key)['disease']<85:p['seed']-=1;crops[key]=time.time();soil_at(key);msg('Crop planted. Water and soil nutrients are essential.')
  elif k==1:
   harvested=0
   for key,tm in list(crops.items()):
    cx,cy=map(int,key.split(','))
    if near(p,cx,cy,3) and time.time()-tm>=crop_time() and soil_good(key):
     q=soil_at(key);q['n']=max(0,q['n']-8);q['p']=max(0,q['p']-4);q['k']=max(0,q['k']-5);del crops[key];coin(p,55);xp(p,8);harvested+=1
   msg(f'Harvested {harvested} crops.')
  elif k==2 and buy(p,40):p['seed']+=3
  elif 3<=k<=6:
   species=('Apple','Pear','Peach','Plum')[k-3]
   if p['seed']<2:msg('Need two seeds.');return
   if not orchard_plant(p,species,i):return
   p['seed']-=2;msg(f'Planted a {species.lower()} sapling. It needs time and favorable seasons.');save()
  elif k==7:
   collected=0
   for obj in orchards.values():
    if not near(p,*obj['pos'],3) or obj['species']=='Money Tree':continue
    ready=orchard_ready(obj)
    if ready and obj.get('health',100)>15:
     yield_n=max(1,int(obj.get('health',100)//30));pickup(p,'food',yield_n);obj['harvested']=time.time();q=soil_at(f"{obj['pos'][0]},{obj['pos'][1]}");q['n']=max(0,q['n']-5);q['p']=max(0,q['p']-3);q['k']=max(0,q['k']-4);collected+=yield_n
   msg(f'Gathered {collected} fruit. Fruit trees recover between harvests.');save()
  elif k==8:
   names=[f"{v['species']}: {int(v.get('health',100))}% health, {'ripe' if orchard_ready(v) else 'growing/resting'}, {soil_report(str(v['pos'][0])+','+str(v['pos'][1]))}" for v in orchards.values() if near(p,*v['pos'],3)]
   msg(' | '.join(names[:2]) if names else 'No orchard trees nearby.')
  elif k==9:
   if p.get('salt',0)<1 or p.get('water_bottles',0)<2:msg('Tree care requires salt and two water bottles.');return
   sick=[v for v in orchards.values() if near(p,*v['pos'],3) and v.get('health',100)<95]
   if not sick:msg('No sick orchard trees nearby.');return
   p['salt']-=1;p['water_bottles']-=2
   for v in sick:v['health']=min(100,v.get('health',100)+30)
   msg('Treated nearby diseased trees.');save()
  elif k==10:
   if not p.get('axe',0):msg('Pruning requires an axe.');return
   count=0
   for v in orchards.values():
    if near(p,*v['pos'],3):v['health']=min(100,v.get('health',100)+8);v['pruned']=time.time();count+=1
   p['energy']=max(0,p['energy']-count*3);msg(f'Pruned {count} trees.');save()
  elif k==11:
   if 'Money Tree' not in p.get('arcade_unlocks',[]):msg('Win a Money Tree in minigames and claim it from the prize vault first.');return
   if orchard_plant(p,'Money Tree',i):p['arcade_unlocks'].remove('Money Tree');unlock_achievement(p,'money_tree');msg('A MONEY TREE! Absolutely ridiculous.');save()
  elif k==12:
   if p['seed']<1:msg('Need a seed.');return
   if orchard_plant(p,'Herbs',i):p['seed']-=1;msg('Herbs planted.');save()
  elif k==13:
   count=0
   for v in orchards.values():
    if v['species']=='Herbs' and near(p,*v['pos'],3) and orchard_ready(v):
     pickup(p,'food',1);v['harvested']=time.time();count+=1
   msg(f'Harvested {count} herb beds.');save()
  elif k==14 and buy(p,50):p['seed']+=4
  elif k==15:
   found=[v for v in orchards.values() if v.get('species')=='Money Tree' and near(p,*v['pos'],3)]
   ripe=[v for v in found if orchard_ready(v)]
   if not ripe:
    if found:
     remaining=min(max(0,(MONEY_TREE_GROW_SECONDS-(time.time()-v.get('planted',time.time()))) if not v.get('harvested',0) else (MONEY_TREE_REGROW_SECONDS-(time.time()-v['harvested']))) for v in found)
     msg(f'Money still growing on trees! About {int((remaining+3599)//3600)} hour(s) to go.')
    else:msg('No planted Money Tree within three tiles.')
    return
   total=0
   for v in ripe:
    gain=random.randint(1500,3000);coin(p,gain);total+=gain;v['harvested']=time.time();q=soil_at(f"{v['pos'][0]},{v['pos'][1]}");q['water']=max(0,q['water']-12);q['n']=max(0,q['n']-20);q['p']=max(0,q['p']-10);q['k']=max(0,q['k']-12)
   xp(p,12*len(ripe));msg(f'Picked dangling banknotes: +{total} coins from {len(ripe)} Money Tree(s)! They regrow slowly.')
   save()
  elif k==16:
   nearby=[key for key in set(crops)|set(orchards) if near(p,*map(int,key.split(',')),3)]
   msg(' | '.join(f'{key}: {soil_report(key)}' for key in nearby[:2]) if nearby else 'No growing plots within three tiles.')
  elif k==17:
   nearby=[key for key in set(crops)|set(orchards) if near(p,*map(int,key.split(',')),3) and soil_at(key)['water']<90]
   if not nearby:msg('Nearby planted plots have enough water.');return
   count=min(len(nearby),p.get('water_filled',0))
   if not count:msg('Need filled water bottles; fill near a shoreline.');return
   p['water_filled']-=count
   for key in nearby[:count]:soil_at(key)['water']=min(100,soil_at(key)['water']+45)
   msg(f'Watered {count} plots.');save()
  elif k==18:
   nearby=[key for key in set(crops)|set(orchards) if near(p,*map(int,key.split(',')),3)]
   count=min(len(nearby),p.get('food',0)//2)
   if not count:msg('Need nearby growing plots and 2 food per compost application.');return
   p['food']-=2*count
   for key in nearby[:count]:
    q=soil_at(key)
    for nutrient,add in [('n',28),('p',20),('k',20)]:q[nutrient]=min(100,q[nutrient]+add)
    q['disease']=max(0,q['disease']-10)
   msg(f'Composted {count} plots: nitrogen, phosphorus, and potassium restored.');save()
  elif k==19:
   if p['seed']<1 or key in crops or key in orchards or not land_available(x,y) or terrain[y][x]=='water':msg('Need a seed and empty dry unlocked ground.');return
   p['seed']-=1;crops[key]=time.time()-crop_time()*.4;soil_at(key)['n']=min(100,soil_at(key)['n']+30)
   msg('Planted nitrogen-fixing beans. Their roots restore soil nitrogen.');save()
  elif k==20:
   dead=[key for key,v in orchards.items() if v.get('health',100)<10 and near(p,*v['pos'],3)]
   for key in dead:del orchards[key];soil_at(key)['disease']=max(0,soil_at(key)['disease']-25)
   msg(f'Cleared {len(dead)} dead plants. Revive struggling trees with water and compost before they die.');save()
 elif name=='BUILDER':
  if k==11:p['menu']='MATERIALS';p['selection']=0;return
  recipes=[(3,0,'wall'),(8,5,'house'),(0,6,'tower'),(4,0,'bridge'),(2,0,'floor'),(4,0,'roof'),(3,0,'door'),(2,1,'window')]
  if 8<=k<=10:
   recipes_build(p,['bench','collector','furniture'][k-8],i);p['menu']=None;save();return
  wood,stone,kind=recipes[k]
  costs={'wood':wood,'stone':stone,**BUILD_EXTRAS.get(kind,LEGACY_EXTRAS.get(kind,{}))}
  if has_construction(p,costs):
   spend_construction(p,costs);x,y=tile(p);structures.append([x,y,kind])
   if kind in ('floor','door','window','roof'):p['custom_rooms']+=1
   if kind=='wall':p['custom_walls']+=1
   if kind=='roof':p['custom_roofs']+=1
   xp(p,12 if kind in ('wall','floor') else 15)
   msg('Construction complete. Building inspector is a goose.')
  else:msg('Not enough materials. Try hitting more trees.')
 elif name=='CAMP':
  if k==0:p['energy']=100;p['hp']=min(p['maxhp'],p['hp']+25);msg(f'P{i+1} rested. The campfire roasted their emotional damage.')
  elif k==1 and p['wood']>=1:p['wood']-=1;p['food']+=2;msg('Cooked two suspiciously crunchy meals.')
  elif k==2 and p['wood']>=2:p['wood']-=2;p['torches']+=1;msg('Crafted a torch. Darkness is filing a complaint.')
  elif k==3 and p['wood']>=5:p['wood']-=5;p['wooden_shield']=1;msg('Shield crafted! +30% protection from monsters.')
  elif k in (4,5,6):
   wood,stone,scrap,kind={4:(5,2,0,'campfire'),5:(5,0,2,'hammock'),6:(12,0,5,'tree_tent')}[k]
   if p['wood']<wood or p['stone']<stone or p['scrap']<scrap:msg('Not enough crafting materials.')
   else:
    p['wood']-=wood;p['stone']-=stone;p['scrap']-=scrap
    tx,ty=tile(p);structures.append([tx,ty,kind+str(i+1)])
    p['campfires' if k==4 else 'hammock' if k==5 else 'tree_tent']+=1
    msg('Tree tent crafted! Ropes lash it to the trees so your back does not freeze on the ground.' if k==6 else f'Crafted {kind.replace("_"," ")}!')
  elif 7<=k<=12:
   kind=['bench','collector','tarp','sleeping_bag','raft','boat'][k-7]
   if kind in ('boat',) and not (p.get('craft_bench') or bench_near(p)):
    msg('A boat requires a nearby workbench. A raft does not.');
   else:recipes_build(p,kind,i)
  elif k==13:
   if p['water_reserve']<=0:msg('No stored rainwater. Rain collectors need rain or snow.');
   else:
    n=min(int(p['water_reserve']),max(0,p['water_bottles']-p['water_filled']))
    p['water_reserve']-=n;p['water_filled']+=n;msg(f'Filled {n} bottles from your rainwater collectors.')
  elif k==14:
   if p['wood']<1 or not campfire_near(p):msg('Need 1 wood and a nearby campfire.')
   else:p['wood']-=1;p['firewood']+=3;msg('Campfire fueled for a while. Roast a joke, not your socks.')
  else:msg('Not enough supplies. Even the fire is disappointed.')
 elif name=='TRADER':
  if k==0:coin(p,p['ore']*45);msg(f'Sold {p["ore"]} ore.');p['ore']=0
  elif k==1:coin(p,p['gems']*250);msg(f'Sold {p["gems"]} gems.');p['gems']=0
  elif k==2 and buy(p,350):p['life']+=1
  elif k==3 and buy(p,140):p['food']+=5
 elif name=='PRESTIGE':
  nw=p['wallet']+p['bank']+p['wood']*10+p['stone']*15+p['life']*350+p.get('gems',0)*250+p.get('ore',0)*45
  if p['level']>=5+3*p['prestige'] and nw>=1500*(p['prestige']+1)**2:
   x,y=p['x'],p['y'];prestige=p['prestige']+1;old_achievements=list(p.get('achievements',[]));old_playtime=p.get('play_seconds',0.0);old_npc_encounters=p.get('npc_encounters',0);p.update(newplayer(i));p['achievements']=old_achievements;p['play_seconds']=old_playtime;p['npc_encounters']=old_npc_encounters;p['x'],p['y']=x,y;p['prestige']=prestige;msg(f'P{i+1} PRESTIGE {prestige}! +10% income forever.')
  else:msg('Prestige locked. The crown demands more grinding.')
 elif name=='ARENA':
  if k==0:
   damage=random.randint(10,55)-p['weapon']*10;armour_factor=EQUIPMENT.get(p.get('armour',''),('',0,0,''))[2];p['hp']-=max(1,round(max(1,damage)*(1-armour_factor)))
   if p['hp']<=0:death(p,i)
   else:coin(p,random.randint(50,160));xp(p,20);msg('Monster defeated! It dropped its tax return.')
  elif buy(p,70):p['hp']=p['maxhp']
 p['menu']=None;save()

def fire_portal(p,i):
 """Short-range world teleport; no portals may split the shared-camera party."""
 if p['menu'] or p.get('inside') or p.get('aboard'):
  msg('Portals are disabled in menus, houses and vehicles.');return
 if not tech_gate(6):return
 if not p.get('portal_gun'):
  msg('No portal gun. Visit GEAR and bring an irresponsible amount of money.');return
 if p.get('portal_cd',0)>0:
  msg(f'Portal gun cooling down: {p["portal_cd"]:.1f}s.');return
 if p.get('portal_condition',0)<=0:
  msg('Portal gun BROKEN. The space-time warranty was imaginary. Repair at GEAR.');return
 if p.get('portal_charges',0)<=0:
  msg('Portal battery empty! Recharge at GEAR.');return
 direction=p.get('dir',(0,1));dx,dy=direction
 mag=math.hypot(dx,dy)
 if mag<.01:dx,dy=0,1
 else:dx,dy=dx/mag,dy/mag
 startx,starty=p['x'],p['y']
 # Try farthest tile first, and search shorter hops if terrain blocks the path.
 maxdist=8 if p.get('portal_stabilizer') else 5
 dest=None
 for distance in range(maxdist,1,-1):
  xx=startx+dx*distance*T;yy=starty+dy*distance*T
  tx,ty=int(xx//T),int(yy//T)
  if not (0<=tx<world_limit and 0<=ty<world_limit and terrain[ty][tx]!='water' and land_available(tx,ty)):continue
  party=[q for q in players if q is not p]
  if any(math.hypot(xx-q['x'],yy-q['y'])>520 for q in party):continue
  if any(math.hypot(xx-m['x'],yy-m['y'])<26 for m in monsters):continue
  dest=(xx,yy);break
 if dest is None:
  msg('Rift obstructed or your friends are too far behind. Portal refused to split the party.');return
 wear=random.randint(4,8) if p.get('portal_stabilizer') else random.randint(9,15)
 p['portal_condition']=max(0,p['portal_condition']-wear)
 p['portal_charges']-=1;p['portal_cd']=2.5 if p.get('portal_stabilizer') else 4.0
 p['x'],p['y']=dest
 p['energy']=max(0,p['energy']-3)
 portals.append([startx,starty,0.7]);portals.append([dest[0],dest[1],0.7])
 msg(f'P{i+1} warped {int(math.hypot(dest[0]-startx,dest[1]-starty)//T)} tiles! '+('Rift stabilizer reduced wear.' if p.get('portal_stabilizer') else 'Reality requests a maintenance fee.'))
 save()

def attack(p,i):
 if p['cd']>0 or p.get('inside'):return
 if p['weapon'] and p.get('weapon_condition',100)<=0:msg(('Your '+p.get('fake_weapon_name','weapon')+' broke! Repair it at GEAR.') if p.get('fake_weapon_name') else 'Your weapon broke! Repair it at GEAR.');return
 if p['weapon']:p['weapon_condition']=max(0,p.get('weapon_condition',100)-max(1,random.randint(1,3)-(1 if p.get('belt')=='Tactical Belt' else 0)))
 p['cd']=.48 if p['weapon']>=2 else .7
 targets=[m for m in monsters if math.hypot(m['x']-p['x'],m['y']-p['y'])< (230 if p['weapon']>=2 else 85 if p.get('belt')=='Sword Belt' else 65)]
 if not targets:return
 m=min(targets,key=lambda m:math.hypot(m['x']-p['x'],m['y']-p['y']))
 m['hp']-=10+12*p['weapon']+(5 if p.get('ring')=='Ring of Embers' else 0)
 if m['hp']<=0:
  monsters.remove(m);p['stats']['monsters']+=1;coin(p,random.randint(25,90));xp(p,12)
  if m.get('kind')=='wolf':pickup(p,'hide',random.randint(1,2));msg(f'P{i+1} hunted a wolf and collected hide.')
  else:msg(f'P{i+1} defeated a hostile {m.get("kind","creature")}.')

def shoreline(p):
 x,y=tile(p)
 return any(0<=x+dx<N and 0<=y+dy<N and terrain[y+dy][x+dx]=='water' for dx,dy in ((0,1),(1,0),(-1,0),(0,-1)))

def water_action(p,i):
 if p['water_filled']>0:
  p['water_filled']-=1;p['thirst']=min(100,p['thirst']+55)
  msg(f'P{i+1} drank a water bottle. Hydration unlocked.')
 elif p['water_bottles']>0 and shoreline(p):
  p['water_filled']=p['water_bottles'];msg(f'P{i+1} refilled {p["water_filled"]} bottles at the pond. (Game water!)')
 else:msg('No water. Bring empty bottles to the shoreline.')

def fish_action(p,i):
 if not shoreline(p):msg('Fishing requires standing beside water.');return
 if season=='Winter' or weather=='Snow':
  x,y=tile(p)
  adj=[(x+dx,y+dy) for dx,dy in ((0,1),(1,0),(-1,0),(0,-1)) if 0<=x+dx<N and 0<=y+dy<N and terrain[y+dy][x+dx]=='water']
  if not adj:return
  ix,iy=adj[0];hole=f'{ix},{iy}'
  if hole not in ice_holes:
   if not (p.get('pickaxe') or p.get('spark_drill')):msg('ICE FISHING: Need a pickaxe or spark drill to cut an ice hole first.');return
   if p['energy']<15:msg('Not enough energy to cut through the ice.');return
   p['energy']-=15;ice_holes.add(hole);p['ice_holes_opened']=p.get('ice_holes_opened',0)+1
   msg(f'P{i+1} cut an ice-fishing hole! Fish again to cast your line.');return
 if not p['fish_bucket']:msg('Buy a fish bucket at the shop first.');return
 if p['fish_cd']>0:msg(f'Fishing cooldown: {p["fish_cd"]:.1f}s');return
 p['fish_cd']=MOD['fish_cooldown']
 caught=p['fish_caught'];total=sum(caught.values())
 if total>=MOD['fish_bucket_capacity']*p['fish_bucket']:
  msg('Fish bucket is full. Sell your fish at the shop!');return
 if random.random() < (.15 if p['luck'] else .24):msg(random.choice(MOD['jokes']));return
 species=list(MOD['fish']);weights=[MOD['fish'][f]['weight'] for f in species]
 f=random.choices(species,weights=weights)[0];caught[f]=caught.get(f,0)+1
 p['stats']['fish']+=1
 xp(p,5);msg(f'P{i+1} caught {f}! Bucket {total+1}/{MOD["fish_bucket_capacity"]*p["fish_bucket"]}.')

def spawn():
 for _ in range(40):
  viable=[r for r in REGIONS if r[1]-r[3]<world_limit and r[2]-r[4]<world_limit]
  _,cx,cy,rx,ry=random.choice(viable)
  x=random.randint(max(0,cx-rx),min(world_limit-1,cx+rx))
  y=random.randint(max(0,cy-ry),min(world_limit-1,cy+ry))
  if terrain[y][x] not in ('water','path') and math.hypot(x-120,y-120)>9:
   kind=random.choices(['goose','bandit','wolf']+list(EXT_MODS.enemies),weights=[12,9,9]+[a['weight'] for a in EXT_MODS.enemies.values()])[0]
   monsters.append(dict(x=(x+.5)*T,y=(y+.5)*T,hp=EXT_MODS.enemies.get(kind,{}).get('hp',60),cd=0,ai='wander',wander=0,wx=0,wy=0,kind=kind));return
for _ in range(12):spawn()
keys=[(pygame.K_w,pygame.K_s,pygame.K_a,pygame.K_d,pygame.K_e,pygame.K_SPACE,pygame.K_q,pygame.K_r),(pygame.K_UP,pygame.K_DOWN,pygame.K_LEFT,pygame.K_RIGHT,pygame.K_RETURN,pygame.K_RSHIFT,pygame.K_BACKSPACE,pygame.K_RCTRL)]
msg(f'Four strange choice-driven sites and modded encounters now available!')
msg(f'Slot {slot}: {world_options["mode"]} / {world_options["difficulty"]}, map {world_limit}x{world_limit}. Start with food and shelter!')
# Trusted Python mods receive live context; not sandboxed, so trust only reviewed source.
class PluginAPI:
 @property
 def players(self):return players
 @property
 def shared_items(self):return shared_items
 @property
 def structures(self):return structures
 @property
 def monsters(self):return monsters
 @property
 def terrain(self):return terrain
 def message(self,text):msg(str(text)[:140])
 def save(self):save()
 def spawn_enemy(self,x,y,kind='goose',hp=60):
  if 0<=x<N and 0<=y<N and terrain[y][x]!='water':
   monsters.append(dict(x=(x+.5)*T,y=(y+.5)*T,hp=int(hp),cd=0,ai='wander',wander=0,wx=0,wy=0,kind=str(kind)))
PLUGIN_API=PluginAPI()
EXT_MODS.dispatch('on_start',PLUGIN_API)
running=True; autosave=0; map_open=False; survival_tick=0; explored_sets=[set(map(int,p.get("explored",[]))) for p in players]
while running:
 dt=min(clock.tick(60)/1000,.05)
 if not paused:
  EXT_MODS.dispatch('on_tick',PLUGIN_API,dt=dt)
  for _event in EXT_MODS.events:
   if random.random()<(_event['chance']*dt):
    msg(_event['message'])
    if _event['item'] in ITEMS and _event['quantity']:
     shared_items[_event['item']]=shared_items.get(_event['item'],0)+_event['quantity']
 if not paused and not ach_view:check_achievements()
 if not paused and not ach_view and not gear_board_open and not forge_timing:
  for q in players:q['play_seconds']=q.get('play_seconds',0.0)+dt
  tick_roaming_npcs(dt)
  update_stocks(dt)
 if forge_timing:forge_timing['pos']=(forge_timing['pos']+dt*forge_timing['speed'])%1.0
 if not paused:
  tick+=dt;weather_timer+=dt;season_timer+=dt;autosave+=dt;workshop_clock+=dt;event_clock+=dt
  hazard_seconds=max(0,hazard_seconds-dt)
  if hazard_seconds<=0:hazard_kind=''
 if not paused:
  machine_clock+=dt
  tick_settlement(dt)
  tick_government(dt)
  tick_civic(dt)
  if machine_clock>=1:
   tick_machines(machine_clock);machine_clock=0
 if not paused and event_clock>=105:
  event_clock=0;island_event()
 if not paused and weather_timer>55:orchard_decay();weather=seasonal_weather();weather_timer=0;msg('Weather changed: '+weather)
 if not paused and season_timer>145:
  season_timer=0;season=SEASONS[(SEASONS.index(season)+1)%len(SEASONS)];weather=seasonal_weather();ice_holes.clear();msg('Season changed: '+season)
 if not paused and workshops:
  for title,req,w,stone,scrap,ore,gems,coins,rp,seconds,item,amount in PROJECTS:
   if title not in workshops:continue
   elapsed=workshops[title]+dt
   if elapsed>=seconds:
    cycles=min(10,int(elapsed//seconds));elapsed-=cycles*seconds
    if item=='knowledge':knowledge+=amount*cycles
    else:shared_items[item]=min(9999,shared_items.get(item,0)+amount*cycles)
    msg(f'{title} delivered {amount*cycles} {"research points" if item=="knowledge" else item} to the party!')
   workshops[title]=elapsed
 if not paused and autosave>20:save();autosave=0
 if carving_session is not None:shaping_tick(dt)
 for event in pygame.event.get():
  EXT_MODS.dispatch('on_event',PLUGIN_API,event=event)
  if event.type==pygame.QUIT:running=False
  if carving_session is not None:
   if event.type==pygame.QUIT:running=False;continue
   if event.type==pygame.KEYDOWN:
    if event.key==pygame.K_ESCAPE:carving_session=None;msg('Workshop exited. Unfinished work is lost.');continue
    if event.key==pygame.K_SPACE:carving_session['applied']=True;continue
    if event.key==pygame.K_UP:carving_session['spin']=min(1.15,carving_session['spin']+.08);continue
    if event.key==pygame.K_DOWN:carving_session['spin']=max(.1,carving_session['spin']-.08);continue
   if event.type==pygame.KEYUP and event.key==pygame.K_SPACE:carving_session['applied']=False;continue
   if event.type==pygame.MOUSEBUTTONDOWN and event.button==1:carving_session['applied']=True;continue
   if event.type==pygame.MOUSEBUTTONUP and event.button==1:carving_session['applied']=False;continue
   continue
  if event.type==pygame.KEYDOWN and event.key==pygame.K_F7 and not paused and not gear_board_open and not forge_timing:
   menu_for(players[0],'FURNITURE');msg('Furniture workshop: cycle designs and craft sleep equipment.');continue
  if event.type==pygame.KEYDOWN and event.key==pygame.K_F6 and not paused and not gear_board_open and not forge_timing:
   players[0]['menu']='MOD_CRAFT';players[0]['selection']=0;msg('Opened mod crafting recipes.');continue
  if event.type==pygame.KEYDOWN and event.key==pygame.K_F4 and not forge_timing:
   ach_view=not ach_view;continue
  if ach_view:
   if event.type==pygame.KEYDOWN:
    if event.key==pygame.K_ESCAPE:ach_view=False
    elif event.key in (pygame.K_LEFT,pygame.K_RIGHT):ach_player=(ach_player+(1 if event.key==pygame.K_RIGHT else -1))%len(players)
    elif event.key in (pygame.K_PAGEUP,pygame.K_PAGEDOWN):ach_page=(ach_page+(1 if event.key==pygame.K_PAGEDOWN else -1))%((len(ACHIEVEMENTS)+29)//30)
    elif pygame.K_1<=event.key<=pygame.K_4 and event.key-pygame.K_1<len(players):ach_player=event.key-pygame.K_1
   elif event.type==pygame.JOYBUTTONDOWN:
    if event.button in (1,9):ach_view=False
    elif event.button in (13,14):ach_player=(ach_player+(1 if event.button==14 else -1))%len(players)
   continue
  if forge_timing:
   owner=forge_timing['player']
   if event.type==pygame.KEYDOWN and event.key in (pygame.K_e if owner==0 else pygame.K_RETURN, pygame.K_SPACE):forge_strike()
   elif event.type==pygame.JOYBUTTONDOWN and event.button==0 and owner<len(players) and players[owner]['controller']==event.joy:forge_strike()
   continue
  if gear_board_open:
   if event.type==pygame.KEYDOWN:
    if event.key==pygame.K_ESCAPE:gear_close();continue
    if event.key==pygame.K_p:continue
    for j,player in enumerate(players[:2]):
     up,down,left,right,inter,atk,back,food=keys[j]
     if event.key in (up,down,left,right):
      gear_move(player,(int(event.key==right)-int(event.key==left),int(event.key==down)-int(event.key==up)))
     elif event.key==atk:gear_use(player,j)
    continue
   if event.type==pygame.JOYHATMOTION:
    for j,player in enumerate(players):
     if player['controller']==event.joy:
      gear_move(player,(int(event.value[0]),-int(event.value[1])))
    continue
   if event.type==pygame.JOYBUTTONDOWN:
    for j,player in enumerate(players):
     if player['controller']==event.joy:
      if event.button==2:gear_use(player,j)
      elif event.button in (1,9):gear_close()
      elif event.button in (11,12,13,14):gear_move(player,(-1,0) if event.button==13 else (1,0) if event.button==14 else (0,-1) if event.button==11 else (0,1))
    continue
   continue
  if event.type==pygame.KEYDOWN and event.key in (pygame.K_ESCAPE,pygame.K_p):
   if paused and pause_page=='mods':
    pause_page='main'
   else:
    paused=not paused
    if paused:
     pause_page='main'
     for player in players:player['menu']=None
   continue
  if event.type==pygame.JOYBUTTONDOWN and event.button==6:
   if paused and pause_page=='mods':pause_page='main'
   else:
    paused=not paused
    if paused:
     pause_page='main'
     for player in players:player['menu']=None
   continue
  if paused:
   if pause_page=='mods':
    if event.type==pygame.KEYDOWN:
     if event.key in (pygame.K_UP,pygame.K_w):mod_index=max(0,mod_index-1)
     elif event.key in (pygame.K_DOWN,pygame.K_s):mod_index=min(max(0,len(MOD_LIST)-1),mod_index+1)
     elif event.key==pygame.K_PAGEUP:mod_index=max(0,mod_index-8)
     elif event.key==pygame.K_PAGEDOWN:mod_index=min(max(0,len(MOD_LIST)-1),mod_index+8)
     elif event.key in (pygame.K_RETURN,pygame.K_BACKSPACE):pause_page='main'
    elif event.type==pygame.JOYBUTTONDOWN:
     if event.button in (0,1):pause_page='main'
     elif event.button==11:mod_index=max(0,mod_index-1)
     elif event.button==12:mod_index=min(max(0,len(MOD_LIST)-1),mod_index+1)
    elif event.type==pygame.JOYHATMOTION and event.value[1]:
     mod_index=max(0,min(max(0,len(MOD_LIST)-1),mod_index-event.value[1]))
    continue
   if event.type==pygame.KEYDOWN:
    if event.key in (pygame.K_UP,pygame.K_w):pause_index=(pause_index-1)%len(PAUSE_OPTIONS)
    elif event.key in (pygame.K_DOWN,pygame.K_s):pause_index=(pause_index+1)%len(PAUSE_OPTIONS)
    elif event.key in (pygame.K_LEFT,pygame.K_a) and pause_index in range(1,8):adjust_setting(pause_index,-1)
    elif event.key in (pygame.K_RIGHT,pygame.K_d) and pause_index in range(1,8):adjust_setting(pause_index,1)
    elif event.key in (pygame.K_RETURN,pygame.K_SPACE,pygame.K_e):
     if pause_index==0:paused=False
     elif pause_index==8:pause_page='mods';mod_index=0
     elif pause_index==9:save();msg('World saved.')
     elif pause_index==10:save();running=False
     else:adjust_setting(pause_index)
   elif event.type==pygame.JOYBUTTONDOWN:
    if event.button==0:
     if pause_index==0:paused=False
     elif pause_index==8:pause_page='mods';mod_index=0
     elif pause_index==9:save();msg('World saved.')
     elif pause_index==10:save();running=False
     else:adjust_setting(pause_index)
    elif event.button==1:paused=False
    elif event.button==11:pause_index=(pause_index-1)%len(PAUSE_OPTIONS)
    elif event.button==12:pause_index=(pause_index+1)%len(PAUSE_OPTIONS)
    elif event.button==13 and pause_index in range(1,8):adjust_setting(pause_index,-1)
    elif event.button==14 and pause_index in range(1,8):adjust_setting(pause_index,1)
   elif event.type==pygame.JOYHATMOTION:
    if event.value[1]:pause_index=(pause_index-event.value[1])%len(PAUSE_OPTIONS)
    if event.value[0] and pause_index in range(1,8):adjust_setting(pause_index,event.value[0])
   continue
  if event.type==pygame.KEYDOWN and event.key==pygame.K_F3:
   build_mode=not build_mode;build_owner=0
   p=players[build_owner];build_cursor=[int(p['x']//T),int(p['y']//T)]
   msg('Build mode: 1-8 choose, PgUp/PgDn pages, arrows move, Enter places, F3 exits.' if build_mode else 'Construction mode OFF.')
   continue
  if build_mode and event.type==pygame.KEYDOWN:
   if event.key in (pygame.K_1,pygame.K_2,pygame.K_3,pygame.K_4,pygame.K_5,pygame.K_6,pygame.K_7,pygame.K_8):build_kind=min(len(FREE_BUILD)-1,(build_kind//BUILD_PAGE_SIZE)*BUILD_PAGE_SIZE+event.key-pygame.K_1);continue
   if event.key in (pygame.K_PAGEUP,pygame.K_PAGEDOWN):
    page=(build_kind//BUILD_PAGE_SIZE+(1 if event.key==pygame.K_PAGEDOWN else -1))%(math.ceil(len(FREE_BUILD)/BUILD_PAGE_SIZE));build_kind=page*BUILD_PAGE_SIZE;continue
   if event.key in (pygame.K_LEFT,pygame.K_RIGHT,pygame.K_UP,pygame.K_DOWN):
    build_cursor[0]+=int(event.key==pygame.K_RIGHT)-int(event.key==pygame.K_LEFT)
    build_cursor[1]+=int(event.key==pygame.K_DOWN)-int(event.key==pygame.K_UP)
    build_cursor[0]=max(0,min(N-1,build_cursor[0]));build_cursor[1]=max(0,min(N-1,build_cursor[1]));continue
   if event.key==pygame.K_RETURN:place_building(players[build_owner],build_owner,*build_cursor);continue
  if build_mode and event.type==pygame.MOUSEMOTION:
   cx=sum(p['x'] for p in players)/len(players);cy=sum(p['y'] for p in players)/len(players)
   ox=int(W*.46-cx);oy=int(H*.49-cy)
   build_cursor=[int((event.pos[0]-ox)//T),int((event.pos[1]-oy)//T)]
  if build_mode and event.type==pygame.MOUSEBUTTONDOWN and event.button==1:
   place_building(players[build_owner],build_owner,*build_cursor);continue
  if build_mode and event.type==pygame.JOYBUTTONDOWN and event.button==10:
   build_mode=False;msg('Construction mode OFF.');continue
  if event.type==pygame.JOYBUTTONDOWN and event.button==10:
   build_mode=True;build_owner=next((ii for ii,q in enumerate(players) if q['controller']==event.joy),0)
   q=players[build_owner];build_cursor=[int(q['x']//T),int(q['y']//T)];msg('Controller construction mode ON: D-pad cursor, A place, X cycles.');continue
  if build_mode and event.type==pygame.JOYHATMOTION and event.joy == players[build_owner]['controller']:
   build_cursor[0]=max(0,min(N-1,build_cursor[0]+event.value[0]));build_cursor[1]=max(0,min(N-1,build_cursor[1]-event.value[1]));continue
  if build_mode and event.type==pygame.JOYBUTTONDOWN and event.joy==players[build_owner]['controller']:
   if event.button==0:place_building(players[build_owner],build_owner,*build_cursor)
   if event.button==2:build_kind=(build_kind+1)%len(FREE_BUILD)
   if event.button==4:build_kind=((build_kind//BUILD_PAGE_SIZE-1)%(math.ceil(len(FREE_BUILD)/BUILD_PAGE_SIZE)))*BUILD_PAGE_SIZE
   if event.button==5:build_kind=((build_kind//BUILD_PAGE_SIZE+1)%(math.ceil(len(FREE_BUILD)/BUILD_PAGE_SIZE)))*BUILD_PAGE_SIZE
   continue
  if event.type==pygame.KEYDOWN:
   if event.key==pygame.K_F2:map_open=not map_open
   if event.key==pygame.K_h and not build_mode:fire_portal(players[0],0)
   if event.key==pygame.K_QUOTE and len(players)>1 and not build_mode:fire_portal(players[1],1)
   if event.key in (pygame.K_1,pygame.K_2,pygame.K_3,pygame.K_4,pygame.K_5) and not players[0]['menu']:
    use_hotbar(players[0],0,event.key-pygame.K_1)
   if event.key==pygame.K_TAB:gear_board_open=True;[p.update(menu=None) for p in players];continue
   if event.key==pygame.K_BACKSLASH and len(players)>1:gear_board_open=True;[p.update(menu=None) for p in players];continue
   if event.key==pygame.K_c and not build_mode:cave_action(players[0],0)
   if event.key==pygame.K_v and not build_mode:reinforce_cave(players[0],0)
   if event.key==pygame.K_SEMICOLON and len(players)>1 and not build_mode:cave_action(players[1],1)
   if event.key==pygame.K_i:enter_home(players[0],0)
   if event.key==pygame.K_b:toggle_boat(players[0],0)
   if event.key==pygame.K_ESCAPE:
    for p in players:p['menu']=None
   for i,p in enumerate(players[:2]):
    up,down,left,right,inter,atk,back,food=keys[i]
    if p['menu']:
     if event.key==up:p['selection']=(p['selection']-1)%len(options(p['menu'],p))
     elif event.key==down:p['selection']=(p['selection']+1)%len(options(p['menu'],p))
     elif event.key==inter:choose(p,i)
     elif event.key==back:p['menu']=None
    else:
     if event.key==inter:action(p,i)
     if event.key==atk:attack(p,i)
     if event.key==(pygame.K_g if i==0 else pygame.K_RIGHTBRACKET):fish_action(p,i)
     if event.key==food and p['food']>0:p['food']-=1;p['hunger']=min(100,p.get('hunger',90)+45);p['hp']=min(p['maxhp'],p['hp']+35);p['energy']=min(100,p['energy']+25)
     if event.key==(pygame.K_f if i==0 else pygame.K_RALT):water_action(p,i)
     if i==1 and event.key==pygame.K_SLASH:toggle_boat(p,i)
     if i==1 and event.key==pygame.K_PERIOD:enter_home(p,i)
  if event.type==pygame.JOYHATMOTION:
   for i,p in enumerate(players):
    if p['controller']==event.joy and p['menu'] and event.value[1]:
     p['selection']=(p['selection']-event.value[1])%len(options(p['menu'],p))
  if event.type==pygame.JOYBUTTONDOWN:
   for i,p in enumerate(players):
    if p['controller']==event.joy:
     if event.button==0:
      if p['menu']:choose(p,i)
      else:action(p,i)
     if event.button==1:p['menu']=None
     if event.button==2:attack(p,i)
     if event.button==3 and p['food']>0:p['food']-=1;p['hunger']=min(100,p.get('hunger',90)+45);p['hp']=min(p['maxhp'],p['hp']+35);p['energy']=min(100,p['energy']+25)
     if event.button==4:water_action(p,i)
     if event.button==5:fish_action(p,i)
     if event.button==7:toggle_boat(p,i)
     if event.button==8:enter_home(p,i)
     if event.button==9:gear_board_open=True;[q.update(menu=None) for q in players]
     if event.button==13 and not p['menu'] and not build_mode:fire_portal(p,i)
     if event.button==14 and not p['menu'] and not build_mode:cave_action(p,i)
     if p['menu'] and event.button in (11,12):p['selection']=(p['selection']+(-1 if event.button==11 else 1))%len(options(p['menu'],p))
 pressed=pygame.key.get_pressed()
 if paused or gear_board_open:dt=0
 if world_options['mode']=='Creative':
  for p in players:
   p['hp']=p['maxhp'];p['energy']=100;p['hunger']=100;p['thirst']=100;p['temperature']=70
   p['wallet']=max(p['wallet'],100000)
   for key in ('wood','stone','scrap','ore','gems','food','ingot','clay','sand','fiber','planks','nails','bricks','mortar','glass','concrete','wiring','gears','circuits','crystal_dust','flint'):
    p[key]=max(100,p.get(key,0))

 for i,p in enumerate(players):
  p['forage_cd']=max(0,p['forage_cd']-dt);p['sprint']=min(100,p['sprint']+dt*(10 if p.get('ring')=='Ring of Tides' else 7));p['fish_cd']=max(0,p['fish_cd']-dt);p['portal_cd']=max(0,p.get('portal_cd',0)-dt);p['cd']=max(0,p['cd']-dt);p['invuln']=max(0,p['invuln']-dt)
  dx=dy=0
  if i<2:
   u,d,l,r,*_=keys[i];dx=int(pressed[r])-int(pressed[l]);dy=int(pressed[d])-int(pressed[u])
  else:
   if p['controller']<0 or p['controller']>=len(controllers):continue
   j=controllers[p['controller']];dx=j.get_axis(0);dy=j.get_axis(1)
   if abs(dx)<SETTINGS['controller_deadzone']:dx=0
   if abs(dy)<SETTINGS['controller_deadzone']:dy=0
   if p['menu']:
    hats=j.get_hat(0) if j.get_numhats() else (0,0)
    if hats[1] and p['interact']<=0:p['selection']=(p['selection']-hats[1])%len(options(p['menu'],p));p['interact']=.18
    p['interact']=max(0,p['interact']-dt)
  if paused or gear_board_open or p['menu'] or p.get('inside'):continue
  mag=max(1,math.hypot(dx,dy));dx/=mag;dy/=mag
  sprinting=bool(pressed[pygame.K_LSHIFT] if i==0 else pressed[pygame.K_RCTRL] if i==1 else (controllers[p['controller']].get_button(10) if controllers[p['controller']].get_numbuttons()>10 else False))
  speed=(285 if p.get('sail') and p.get('boat') else 230 if p.get('boat') else 165) if p.get('aboard') else (180 if p['boots'] else 145)*(.82 if weather=='Storm' else 1)*(.65 if p['energy']<15 else 1)
  if sprinting and p['sprint']>0 and p['energy']>5:speed*=1.65;p['sprint']=max(0,p['sprint']-dt*24);p['energy']=max(0,p['energy']-dt*.8)
  # Shared camera rule: nobody may travel too far from the party center.
  centerx=sum(q['x'] for q in players)/len(players);centery=sum(q['y'] for q in players)/len(players)
  if math.hypot(p['x']-centerx,p['y']-centery)>310 and (dx*(p['x']-centerx)+dy*(p['y']-centery))>0:dx=dy=0
  nx=p['x']+dx*speed*dt;ny=p['y']+dy*speed*dt
  tx,ty=int(nx//T),int(ny//T)
  if 0<=tx<world_limit and 0<=ty<world_limit and (terrain[ty][tx]=='water' if p.get('aboard') else terrain[ty][tx]!='water' and land_available(tx,ty)):p['x'],p['y']=nx,ny
  if dx or dy:
   p['dir']=(dx,dy);p['energy']=max(0,p['energy']-dt*.32);p['idle_seconds']=0.0
  elif dt>0:p['idle_seconds']=p.get('idle_seconds',0.0)+dt
  # Reveal a 9x9 square of tiles for this player only.
  tx,ty=tile(p)
  radius=9 if p.get('portable_scanner') else 7 if 'Arcade Compass' in p.get('arcade_unlocks',[]) else 6 if p.get('map_beacon') or p.get('ring')=='Ring of Echoes' else 4
  for yy in range(max(0,ty-radius),min(N,ty+radius+1)):
   for xx in range(max(0,tx-radius),min(N,tx+radius+1)):explored_sets[i].add(yy*N+xx) if land_available(xx,yy) else None
  p['stats']['explore']=len(explored_sets[i])
 for m in monsters:
  if paused:continue
  m['cd']=max(0,m['cd']-dt)
  nearest=min(players,key=lambda p:math.hypot(p['x']-m['x'],p['y']-m['y']))
  dist=math.hypot(nearest['x']-m['x'],nearest['y']-m['y'])
  difficulty=SETTINGS['enemy_ai']
  awareness={'Relaxed':125,'Normal':205,'Aggressive':300}[difficulty]
  if .48<(tick%240)/240<.94:awareness*=1.35
  speed={'Relaxed':30,'Normal':48,'Aggressive':65}[difficulty]
  if .48<(tick%240)/240<.94:speed*=1.2
  # Creatures wander while idle, then pursue a nearby player.
  if dist<awareness and not nearest.get('inside'):
   m['ai']='chase'
   dx=(nearest['x']-m['x'])/max(1,dist);dy=(nearest['y']-m['y'])/max(1,dist)
  else:
   m['ai']='wander'
   m['wander']=m.get('wander',0)-dt
   if m['wander']<=0:
    angle=random.random()*math.tau;m['wx']=math.cos(angle);m['wy']=math.sin(angle);m['wander']=random.uniform(1,4)
   dx=m['wx'];dy=m['wy'];speed*=.32
  if dist>30 or m['ai']=='wander':
   nx=m['x']+dx*speed*dt;ny=m['y']+dy*speed*dt
   tx,ty=int(nx//T),int(ny//T)
   if 0<=tx<world_limit and 0<=ty<world_limit and terrain[ty][tx]!='water':m['x'],m['y']=nx,ny
  if dist<34 and m['cd']==0 and nearest['invuln']==0 and not nearest.get('inside') and world_options['mode']!='Creative':
   nearest['hp']-=max(1,int(random.randint(5,13)*({'Peaceful':0,'Easy':.65,'Normal':1,'Hard':1.45,'Nightmare':1.9}.get(world_options['difficulty'],1))*(.7 if nearest['wooden_shield'] else 1)));nearest['invuln']=.5;m['cd']=1.2
   if nearest['hp']<=0:death(nearest,players.index(nearest))
 if not paused and world_options['difficulty']!='Peaceful' and len(monsters)<(32 if .48<(tick%240)/240<.94 else 22) and random.random()<dt*(.52 if .48<(tick%240)/240<.94 else .14)*{'Peaceful':0,'Easy':.6,'Normal':1,'Hard':1.5,'Nightmare':2}.get(world_options['difficulty'],1):spawn()
 survival_tick+=dt
 for p in players:
  if not paused:
   p["hunger"]=max(0,p.get("hunger",90)-dt*(.095 if season=='Winter' or weather=='Snow' else .055))
   if p["hunger"]<=0 and random.random()<dt*.08:p["hp"]=max(1,p["hp"]-1)
 if not paused and survival_tick>=1:
  survival_tick-=1
  if .48<(tick%240)/240<.94:
   for i,p in enumerate(players):
    if p.get('inside') and p.get('cave_tile') in caves:
     cave=caves[p['cave_tile']]
     if not cave.get('reinforced') and random.random()<.003:
      dmg=random.randint(7,20);p['hp']-=dmg;msg(f'CAVE-IN! P{i+1} takes {dmg} damage from loose stone!')
      if p['hp']<=0:death(p,i)
  # The caves remain usable through the night, but unreinforced ones have a small cave-in risk.
  for i,p in enumerate(players):
   if hazard_kind and hazard_seconds>0 and not p.get('inside'):
    px,py=tile(p);dist=math.hypot(px-hazard_center[0],py-hazard_center[1])
    if dist<13:
     if hazard_kind=='earthquake' and random.random()<.22:
      p['hp']-=max(1,round(random.randint(2,7)*(1-EQUIPMENT.get(p.get('armour',''),('',0,0,''))[2])));msg(f'P{i+1} hit by falling debris! The ground refuses to cooperate.')
     elif hazard_kind=='lightning_storm' and random.random()<.12 and not protected_home(p):
      p['hp']-=max(1,round(random.randint(5,12)*(1-EQUIPMENT.get(p.get('armour',''),('',0,0,''))[2])));msg(f'P{i+1} got zapped by nearby lightning! The sky has opinions.')
     elif hazard_kind=='strange_fog':p['thirst']=max(0,p['thirst']-.7)
     elif hazard_kind=='animal_stampede' and random.random()<.15:p['energy']=max(0,p['energy']-6)
     if p['hp']<=0:death(p,i)
   if p.get('water_collectors') and weather in ('Rain','Storm','Snow'):
    p['water_reserve']=min(p['water_collectors']*8,p['water_reserve']+0.15*p['water_collectors'])
   cold= season=='Winter' or weather in ('Snow','Storm')
   protected=bool(p.get('inside') or protected_home(p) or p.get('tree_tent') or p.get('igloo') or p.get('quinzee'))
   fire=campfire_near(p) and p.get('firewood',0)>0
   if fire:p['firewood']=max(0,p['firewood']-.008)
   target=90 if fire else 76 if protected else 40 if cold else 66
   if p.get('sleeping_bags') or p.get('tarps'):target+=8
   if p.get('thermal_coat'):target+=17
   if p.get('aboard') and cold:target-=7
   p['temperature']=max(0,min(100,p['temperature']+(target-p['temperature'])*.04))
   if p['temperature']<35:p['energy']=max(0,p['energy']-.5);p['hp']-=1.1 if p['temperature']<18 else .4
   p['thirst']=max(0,p['thirst']-(.46 if weather=='Heatwave' else .30 if season=='Summer' else .12))
   p['energy']=max(0,p['energy']-(0.03 if p['housing']>=3 or p.get('igloo') or p.get('treehouse') else .06))
   if weather in ('Storm','Rain') and p['housing']==0 and not (p['blanket'] or p.get('tree_tent') or p.get('hammock')):p['energy']=max(0,p['energy']-.09)
   elif season=='Winter' and p['housing']==0 and not (p.get('quinzee') or p.get('igloo') or p.get('tree_tent')):p['energy']=max(0,p['energy']-.08)
   elif weather=='Storm' and p['housing']==1:p['energy']=max(0,p['energy']-.025)
   if p['hunger']>65 and p['thirst']>65 and p['energy']>70 and 42<=p['temperature']<=85 and protected:
    p['hp']=min(p['maxhp'],p['hp']+0.35)
   if world_options['mode']!='Creative' and (p['thirst']==0 or p['energy']==0):
    p['hp']-=2
    if p['hp']<=0:death(p,i)
 for i,p in enumerate(players):p['explored']=sorted(explored_sets[i])
 # Camera follows average player position, clamped to island.
 cx=sum(p['x'] for p in players)/len(players);cy=sum(p['y'] for p in players)/len(players)
 ox=int(W*.46-cx);oy=int(H*.49-cy)
 # Camera follows the party; map_size defines world boundaries, not the screen size.
 ox=min(0,max(W-world_limit*T,ox));oy=min(0,max(H-world_limit*T,oy))
 screen.fill((23,47,62))
 min_y=max(0,(-oy)//T-1);max_y=min(N,(H-oy)//T+2)
 min_x=max(0,(-ox)//T-1);max_x=min(N,(W-ox)//T+2)
 for y in range(min_y,max_y):
  sy=y*T+oy
  for x in range(min_x,max_x):
   sx=x*T+ox
   t=terrain[y][x]
   variant=(x*41+y*103+(x*y)%29)%24
   screen.blit(terrain_tile(t,variant,season),(sx,sy))
   if t=='water' and (x*13+y*17)%6==0:
    wave=int(math.sin(tick*2+(x+y)*.8)*3)
    pygame.draw.arc(screen,(143,208,220),(sx+8+wave,sy+15,18,7),0,3.14,2)
   if t=='forest':draw_tree(sx,sy,variant,season)
   if t=='rock':draw_rock(sx,sy)
   draw_environment_details(sx,sy,x,y,t,variant,season,tick)
   if t=='sand' and any(0<=x+ax<N and 0<=y+ay<N and terrain[y+ay][x+ax]=='water' for ax,ay in ((0,1),(1,0),(-1,0),(0,-1))):
    if (x*13+y*19)%3:
     pygame.draw.arc(screen,(244,231,191),(sx+4,sy+25,28,9),0,math.pi,2)
   if t=='water' and any(0<=x+ax<N and 0<=y+ay<N and terrain[y+ay][x+ax]=='sand' for ax,ay in ((0,1),(1,0),(-1,0),(0,-1))):
    shift=2+int(math.sin(tick*3+x*.4+y*.2)*2)
    pygame.draw.arc(screen,(174,225,225),(sx+4,sy+12+shift,32,13),0,math.pi,2)
 # Locked expansion land is visually fogged and labelled.
 for region_id,(_,rx,ry,_,_) in enumerate(REGIONS[1:],1):
  if region_id in unlocked_regions:continue
  sx=int(rx*T+ox);sy=int(ry*T+oy)
  if -5200<sx<W+5200 and -5200<sy<H+5200:
   # Terrain stays in the world, but the player sees a subdued locked zone.
   for yy in range(max(0,int((-oy)//T)-1),min(N,int((H-oy)//T)+2)):
    for xx in range(max(0,int((-ox)//T)-1),min(N,int((W-ox)//T)+2)):
     if land_region(xx,yy)==region_id:
      fog=pygame.Surface((T,T),pygame.SRCALPHA);fog.fill((12,20,35,165))
      screen.blit(fog,(xx*T+ox,yy*T+oy))
   if -100<sx<W+100 and -80<sy<H+80:
    title=small.render('LOCKED: '+REGIONS[region_id][0].upper(),True,(255,222,128))
    pygame.draw.rect(screen,(19,30,45),(sx-title.get_width()//2-12,sy-12,title.get_width()+24,34),border_radius=7)
    screen.blit(title,(sx-title.get_width()//2,sy-2))
 for name,x,y,color in places:
  if not shop_available(name):continue
  sx=x*T+ox;sy=y*T+oy
  pygame.draw.ellipse(screen,(34,56,55),(sx-9,sy+39,62,12))
  pygame.draw.rect(screen,(235,213,165),(sx-8,sy+4,57,37),border_radius=5)
  pygame.draw.polygon(screen,color,[(sx-14,sy+6),(sx+20,sy-15),(sx+54,sy+6)])
  pygame.draw.rect(screen,(92,72,53),(sx+13,sy+21,15,20))
  pygame.draw.rect(screen,(109,177,194),(sx-2,sy+14,11,12))
  label=small.render(name,True,(251,249,235));pygame.draw.rect(screen,(25,39,48),(sx-14,sy-35,label.get_width()+12,22),border_radius=5)
  screen.blit(label,(sx-8,sy-33))
 for name,dx,dy in shady_dealers:
  sx=dx*T+ox;sy=dy*T+oy
  if -35<sx<W+35 and -35<sy<H+35:
   pygame.draw.circle(screen,(35,34,47),(sx+20,sy+23),14)
   pygame.draw.polygon(screen,(80,57,107),[(sx+9,sy+15),(sx+20,sy-2),(sx+32,sy+15)])
   pygame.draw.circle(screen,(245,205,115),(sx+20,sy+14),5)
   pygame.draw.rect(screen,(20,23,31),(sx-15,sy-24,130,19),border_radius=5)
   screen.blit(small.render(name,True,(243,201,110)),(sx-11,sy-23))
 for site in all_encounters():
  x,y=site['position'];sx=x*T+ox;sy=y*T+oy
  if -45<sx<W+45 and -45<sy<H+45 and land_available(x,y):
   bob=math.sin(tick*3+x)*3
   pygame.draw.ellipse(screen,(16,27,39),(sx+4,sy+28,33,10))
   pygame.draw.rect(screen,(45,68,81),(sx+8,sy+7+bob,25,23),border_radius=5)
   pygame.draw.rect(screen,(93,225,206),(sx+11,sy+10+bob,19,14),2,border_radius=3)
   pygame.draw.circle(screen,(250,205,98),(sx+20,sy+17+bob),4)
   text=small.render(site['label'],True,(207,250,234))
   screen.blit(text,(sx+20-text.get_width()//2,sy-21))
 for label,x,y in ODDITIES:
  sx=x*T+ox;sy=y*T+oy
  if -40<sx<W+40 and -40<sy<H+40:
   pygame.draw.circle(screen,(160,66,167),(sx+20,sy+18),11)
   pygame.draw.circle(screen,(232,186,242),(sx+20,sy+18),5)
   txt=small.render(label,True,(236,219,246))
   screen.blit(txt,(sx+15-txt.get_width()//2,sy-24))
 if hazard_kind and hazard_seconds>0:
  hx=hazard_center[0]*T+ox;hy=hazard_center[1]*T+oy
  hz=pygame.Surface((W,H),pygame.SRCALPHA)
  tint=(145,80,185,60) if hazard_kind=='strange_fog' else (220,125,65,55)
  pygame.draw.circle(hz,tint,(int(hx),int(hy)),13*T)
  screen.blit(hz,(0,0))
 for lx,ly in supply_caches:
  sx=lx*T+ox;sy=ly*T+oy
  if -20<sx<W+20 and -20<sy<H+20:
   pygame.draw.rect(screen,(173,113,58),(sx+9,sy+11,22,19),border_radius=3)
   pygame.draw.rect(screen,(233,187,68),(sx+17,sy+12,6,17))
 for lx,ly,kind in landmarks:
  sx=lx*T+ox;sy=ly*T+oy
  if -30<sx<W+30 and -30<sy<H+30:
   pygame.draw.rect(screen,(238,186,48) if kind=='CHEST' else (130,93,205),(sx+5,sy+5,30,30),border_radius=4)
   screen.blit(small.render('?' if kind=='CHEST' else '*',True,(20,20,30)),(sx+15,sy+8))
 # Dark rocky cave entrances, carved one stage at a time.
 for key,info in caves.items():
  xx,yy=map(int,key.split(','));sx=xx*T+ox;sy=yy*T+oy
  if -T<sx<W and -T<sy<H:
   if info.get('progress',0)>=5:
    pygame.draw.ellipse(screen,(13,19,27),(sx+4,sy+6,32,33))
    pygame.draw.arc(screen,(105,100,87),(sx+3,sy+4,34,36),0,math.pi,4)
    if info.get('reinforced'):
     pygame.draw.line(screen,(169,116,65),(sx+7,sy+9),(sx+7,sy+34),5)
     pygame.draw.line(screen,(169,116,65),(sx+33,sy+9),(sx+33,sy+34),5)
     pygame.draw.line(screen,(169,116,65),(sx+7,sy+9),(sx+33,sy+9),5)
    else:pygame.draw.circle(screen,(193,160,91),(sx+32,sy+7),4)
   else:
    pygame.draw.rect(screen,(63,65,70),(sx+8,sy+12,24,23),border_radius=4)
    pygame.draw.line(screen,(19,25,31),(sx+11,sy+16),(sx+24,sy+29),2+int(info.get('progress',0)//2))
 if build_mode and not map_open:
  bx,by=build_cursor; sx=bx*T+ox;sy=by*T+oy
  if -T<sx<W and -T<sy<H:
   allowed=0<=bx<N and 0<=by<N and math.hypot(players[build_owner]['x']/T-(bx+.5),players[build_owner]['y']/T-(by+.5))<=6
   preview=pygame.Surface((T,T),pygame.SRCALPHA);preview.fill((65,220,150,115) if allowed else (240,65,65,115))
   screen.blit(preview,(sx,sy));pygame.draw.rect(screen,(250,250,240),(sx,sy,T,T),2)
 for x,y,kind in structures:
  sx=x*T+ox;sy=y*T+oy
  if sx<-50 or sx>W+50 or sy<-50 or sy>H+50:continue
  if kind.startswith('built:'):
   name=kind.split(':')[1]
   if name.startswith('bedroom-'):
    item=name[len('bedroom-'):]
    pygame.draw.ellipse(screen,(23,37,40),(sx+4,sy+31,34,7))
    if item=='bed_frame':
     pygame.draw.rect(screen,(127,87,53),(sx+4,sy+8,32,27),border_radius=4)
     pygame.draw.rect(screen,(186,142,92),(sx+9,sy+12,22,18),border_radius=3)
     pygame.draw.rect(screen,(78,56,42),(sx+5,sy+4,30,7))
    elif item=='mattress':
     pygame.draw.rect(screen,(196,200,179),(sx+5,sy+9,30,25),border_radius=7)
     pygame.draw.line(screen,(152,165,148),(sx+7,sy+22),(sx+33,sy+22),2)
    else:
     pygame.draw.ellipse(screen,(211,187,145) if item=='house_cushion' else (225,220,202),(sx+7,sy+9,26,24))
     pygame.draw.line(screen,(145,128,103),(sx+10,sy+21),(sx+30,sy+21),1)
    for mx,my,brush in carving_art.get(f'{x},{y}',[]):
     pygame.draw.circle(screen,(96,56,27),(sx+int(mx),sy+int(my)),max(1,int(brush)//2))
    continue
   if name.startswith('custom-furn-'):
    parts=name.split('-');shape=parts[2] if len(parts)>2 else 'chair';material=parts[3] if len(parts)>3 else 'wood';style=parts[4] if len(parts)>4 else 'plain';fabric=parts[5] if len(parts)>5 else 'none'
    base={'wood':(155,113,74),'stone':(137,145,151),'metal':(93,128,147),'reclaimed':(120,105,85)}.get(material,(154,117,76))
    if style=='painted':base=(79,136,167)
    if style=='polished':base=tuple(min(255,z+22) for z in base)
    pygame.draw.ellipse(screen,(29,45,41),(sx+4,sy+31,33,7))
    pygame.draw.rect(screen,base,(sx+5,sy+15,30,17),border_radius=3)
    if shape in ('chair','bench','cot'):pygame.draw.rect(screen,base,(sx+5,sy+3,8 if shape=='chair' else 30,20),border_radius=2)
    if shape in ('table','cabinet','shelf'):pygame.draw.rect(screen,base,(sx+2,sy+9,36,8))
    if fabric!='none':pygame.draw.rect(screen,(190,115,105) if fabric=='cloth' else (138,89,56),(sx+9,sy+16,22,6),border_radius=2)
    if style=='carved':pygame.draw.line(screen,(227,207,151),(sx+10,sy+25),(sx+30,sy+25),2)
    if '|engraved=' in kind:
     pattern=kind.split('|engraved=')[-1]
     pygame.draw.circle(screen,(241,202,119),(sx+20,sy+23),8,2)
     if pattern=='stars':
      for px,py in ((14,19),(25,19),(20,27)):pygame.draw.circle(screen,(253,235,161),(sx+px,sy+py),2)
     elif pattern in ('waves','spiral'):pygame.draw.arc(screen,(245,219,157),(sx+12,sy+17,16,13),0,math.pi*1.6,2)
     elif pattern=='leaf':pygame.draw.ellipse(screen,(89,175,112),(sx+17,sy+17,8,12))
     else:pygame.draw.line(screen,(248,225,164),(sx+13,sy+18),(sx+27,sy+28),2)
    if shape=='stool':pygame.draw.line(screen,(70,60,45),(sx+12,sy+30),(sx+11,sy+36),3)
    for mx,my,brush in carving_art.get(f'{x},{y}',[]):
     pygame.draw.circle(screen,(234,210,142) if material=='metal' else (78,54,34),(sx+int(mx),sy+int(my)),max(1,int(brush)//2))
    continue
   if name in MACHINES:
    state=machine_states.get(f'{x},{y}',{});ok=state.get('on',True) and state.get('condition',100)>0
    pygame.draw.ellipse(screen,(18,37,43),(sx+3,sy+31,35,7))
    if name=='solar panel':
     pygame.draw.rect(screen,(23,63,116),(sx+2,sy+7,36,27),border_radius=3)
     for q in (13,24):pygame.draw.line(screen,(88,180,223),(sx+q,sy+7),(sx+q,sy+34),2)
     pygame.draw.line(screen,(88,180,223),(sx+2,sy+20),(sx+38,sy+20),2)
    elif name=='wind turbine':
     pygame.draw.line(screen,(155,165,172),(sx+20,sy+33),(sx+20,sy+7),5)
     for angle in (0,2.09,4.19):
      a=angle+tick*2;pygame.draw.line(screen,(218,231,226),(sx+20,sy+8),(sx+20+int(15*math.cos(a)),sy+8+int(15*math.sin(a))),4)
    elif name=='battery bank':
     pygame.draw.rect(screen,(70,104,133),(sx+7,sy+8,27,27),border_radius=4)
     pygame.draw.rect(screen,(82,225,166),(sx+12,sy+16,int(18*state.get('charge',0)/100),10))
    else:
     pygame.draw.rect(screen,(104,120,139),(sx+4,sy+12,32,23),border_radius=4)
     pygame.draw.rect(screen,(46,64,79),(sx+8,sy+17,24,12))
     pygame.draw.circle(screen,(93,231,172) if ok else (231,97,89),(sx+29,sy+14),3)
     if name=='security floodlight':pygame.draw.polygon(screen,(243,214,121),[(sx+9,sy+17),(sx-9,sy+38),(sx+31,sy+38)])
     elif name=='fuel generator':pygame.draw.circle(screen,(223,171,85),(sx+16,sy+24),7,2)
     elif name=='weather station':pygame.draw.line(screen,(207,224,231),(sx+20,sy+12),(sx+20,sy-4),2)
    if not ok:pygame.draw.line(screen,(233,90,80),(sx+4,sy+4),(sx+36,sy+36),3)
   elif name in ('lean-to','wattle hut','clay oven','charcoal pit','tanning rack','granary','farmstead','village dormitory','tavern','training yard','stable','distillery','fuel refinery','vehicle workshop','airfield','robotics lab'):
    body=(118,93,61) if era<3 else (107,127,147)
    pygame.draw.ellipse(screen,(29,40,38),(sx+3,sy+31,35,7))
    pygame.draw.rect(screen,body,(sx+5,sy+12,30,22),border_radius=3)
    pygame.draw.polygon(screen,(154,111,62) if name in ('lean-to','wattle hut','granary','farmstead','tavern','stable') else (74,99,116),[(sx+2,sy+14),(sx+20,sy+2),(sx+38,sy+14)])
    pygame.draw.rect(screen,(41,51,50),(sx+16,sy+23,8,12))
    if name in ('clay oven','charcoal pit','fuel refinery','distillery'):pygame.draw.circle(screen,(246,150,71),(sx+28,sy+27),5)
    if name in ('robotics lab','vehicle workshop','airfield'):pygame.draw.circle(screen,(98,211,233),(sx+11,sy+19),4)
   elif name in ('reed hut','market stall' ,'barracks','clocktower','glasshouse','observatory','factory','hangar'):
    body={'reed hut':(150,118,64),'market stall':(176,125,83),'barracks':(108,103,95),'clocktower':(143,121,97),'glasshouse':(114,182,187),'observatory':(85,110,145),'factory':(104,113,123),'hangar':(130,136,145)}[name]
    pygame.draw.ellipse(screen,(28,47,47),(sx+3,sy+30,35,9))
    pygame.draw.rect(screen,body,(sx+5,sy+12,30,24),border_radius=2)
    pygame.draw.polygon(screen,(113,65,49) if name not in ('glasshouse','observatory','hangar') else (66,133,164),[(sx+2,sy+13),(sx+20,sy+1),(sx+38,sy+13)])
    pygame.draw.rect(screen,(51,64,69),(sx+17,sy+24,8,12))
    if name in ('clocktower','observatory'):pygame.draw.circle(screen,(235,216,143),(sx+20,sy+12),6,2)
    if name=='factory':pygame.draw.rect(screen,(89,82,77),(sx+28,sy-5,6,16))
    if name=='market stall':pygame.draw.line(screen,(238,215,114),(sx+6,sy+13),(sx+33,sy+13),4)
   elif name in ('palisade','stone tower','drawbridge','stone fountain','rail track','water pump','hover platform'):
    if name in ('palisade','drawbridge','rail track'):
     pygame.draw.rect(screen,(122,92,58) if name!='rail track' else (83,90,97),(sx+1,sy+9,38,24))
     for n in range(4):pygame.draw.line(screen,(215,183,130) if name!='rail track' else (190,170,140),(sx+4+n*10,sy+9),(sx+4+n*10,sy+32),3)
    elif name=='stone fountain':
     pygame.draw.ellipse(screen,(108,144,163),(sx+2,sy+18,36,17));pygame.draw.circle(screen,(99,191,226),(sx+20,sy+18),9);pygame.draw.line(screen,(163,216,236),(sx+20,sy+5),(sx+20,sy+19),3)
    elif name=='water pump':
     pygame.draw.rect(screen,(107,132,147),(sx+8,sy+14,25,22));pygame.draw.line(screen,(200,202,185),(sx+21,sy+14),(sx+21,sy+4),4)
    elif name=='hover platform':
     pygame.draw.ellipse(screen,(52,221,217),(sx+3,sy+23,34,13));pygame.draw.ellipse(screen,(94,111,134),(sx+3,sy+13,34,17))
    else:
     pygame.draw.rect(screen,(124,126,130),(sx+7,sy+5,26,30));pygame.draw.rect(screen,(183,192,195),(sx+11,sy+9,18,10))
   elif name in ('stone altar','watch fire','steam engine','smokestack','electric lamp','radio mast','solar array','data tower','drone pad','neon beacon','rift arch','energy pylon','rift monument'):
    if name in ('rift arch','rift monument'):
     pygame.draw.ellipse(screen,(85,56,140),(sx+3,sy+2,34,36));pygame.draw.ellipse(screen,(87,225,226),(sx+10,sy+7,20,27));pygame.draw.ellipse(screen,(42,58,104),(sx+15,sy+11,10,19))
    elif name in ('neon beacon','energy pylon','radio mast','data tower','electric lamp','smokestack'):
     pygame.draw.rect(screen,(98,108,123),(sx+14,sy+7,12,30));pygame.draw.line(screen,(161,171,185),(sx+20,sy+7),(sx+20,sy-10),3)
     pygame.draw.circle(screen,(107,236,242) if name!='smokestack' else (140,142,139),(sx+20,sy+2),7)
    elif name in ('solar array','drone pad'):
     pygame.draw.rect(screen,(41,86,129),(sx+3,sy+7,34,27));pygame.draw.line(screen,(128,206,235),(sx+20,sy+7),(sx+20,sy+34),2)
    elif name=='watch fire':
     pygame.draw.rect(screen,(91,69,48),(sx+11,sy+17,18,20));pygame.draw.polygon(screen,(255,170,56),[(sx+12,sy+20),(sx+21,sy-2),(sx+28,sy+20)])
    elif name=='stone altar':
     pygame.draw.rect(screen,(155,147,138),(sx+5,sy+16,30,22));pygame.draw.circle(screen,(210,175,102),(sx+20,sy+14),7)
    else:
     pygame.draw.rect(screen,(106,103,96),(sx+4,sy+13,32,25));pygame.draw.circle(screen,(205,159,92),(sx+20,sy+15),9,3)
   else:pygame.draw.rect(screen,(147,113,82),(sx+4,sy+4,32,32))
   continue
  if kind.startswith('floor'):
   pygame.draw.rect(screen,(169,117,69),(sx+2,sy+2,36,36))
   for yy in (12,25):pygame.draw.line(screen,(117,76,45),(sx+3,sy+yy),(sx+37,sy+yy),2)
  elif kind.startswith('wall'):
   pygame.draw.rect(screen,(143,126,105),(sx+2,sy+3,36,34))
   for yy in (14,26):pygame.draw.line(screen,(91,88,84),(sx+3,sy+yy),(sx+37,sy+yy),2)
  elif kind.startswith('roof'):
   pygame.draw.polygon(screen,(155,66,60),[(sx,sy+13),(sx+20,sy-3),(sx+40,sy+13),(sx+35,sy+35),(sx+5,sy+35)])
  elif kind.startswith('door'):
   pygame.draw.rect(screen,(124,90,56),(sx+4,sy+4,32,32))
   pygame.draw.rect(screen,(74,46,33),(sx+13,sy+10,15,27));pygame.draw.circle(screen,(227,196,93),(sx+25,sy+24),2)
  elif kind.startswith('window'):
   pygame.draw.rect(screen,(116,90,65),(sx+4,sy+4,32,32))
   pygame.draw.rect(screen,(112,184,205),(sx+10,sy+10,20,20));pygame.draw.line(screen,(232,220,170),(sx+20,sy+10),(sx+20,sy+30),2)
  elif kind.startswith('bridge'):
   pygame.draw.rect(screen,(133,95,58),(sx,sy+4,40,32))
   for xx in (7,15,23,31):pygame.draw.line(screen,(78,58,43),(sx+xx,sy+5),(sx+xx,sy+35),2)
  elif kind.startswith('campfire'):
   pygame.draw.circle(screen,(105,91,75),(sx+20,sy+22),16)
   pygame.draw.polygon(screen,(255,154,52),[(sx+14,sy+30),(sx+20,sy+8),(sx+27,sy+30)])
   pygame.draw.polygon(screen,(255,225,90),[(sx+18,sy+28),(sx+20,sy+16),(sx+24,sy+28)])
  elif kind.startswith('chest'):
   pygame.draw.rect(screen,(140,88,38),(sx+6,sy+10,28,24),border_radius=3);pygame.draw.rect(screen,(228,183,65),(sx+17,sy+10,6,24))
  elif kind.startswith('bucket_store'):
   pygame.draw.ellipse(screen,(125,155,172),(sx+7,sy+8,26,25));pygame.draw.arc(screen,(220,225,230),(sx+12,sy+2,17,18),0,math.pi,2)
  elif kind.startswith('tree_tent'):
   pygame.draw.line(screen,(180,150,110),(sx+8,sy+8),(sx+20,sy+18),2);pygame.draw.line(screen,(180,150,110),(sx+32,sy+8),(sx+20,sy+18),2)
   pygame.draw.polygon(screen,(102,162,118),[(sx+10,sy+17),(sx+30,sy+17),(sx+20,sy+30)])
  elif kind.startswith('workshop'):
   pygame.draw.rect(screen,(98,105,122),(sx+4,sy+12,32,25),border_radius=3)
   pygame.draw.polygon(screen,(185,129,73),[(sx+2,sy+14),(sx+20,sy),(sx+38,sy+14)])
   pygame.draw.rect(screen,(64,76,83),(sx+25,sy-2,6,15))
   screen.blit(small.render('W',True,(255,232,137)),(sx+14,sy+15))
  elif kind.startswith('treehouse'):
   pygame.draw.rect(screen,(132,93,55),(sx+8,sy+10,24,18));pygame.draw.line(screen,(94,70,42),(sx+20,sy+28),(sx+20,sy+38),3)
  elif kind.startswith('quinzee'):
   pygame.draw.circle(screen,(238,241,245),(sx+20,sy+22),14);pygame.draw.arc(screen,(80,90,110),(sx+15,sy+20,10,12),0,3.14,2)
  elif kind.startswith('igloo'):
   pygame.draw.circle(screen,(230,236,242),(sx+20,sy+20),14);pygame.draw.rect(screen,(175,190,210),(sx+17,sy+20,8,10))
  else:
   custom_name=kind.split(':')[1] if kind.startswith('built:') else ''
   custom=EXT_MODS.buildings.get(custom_name)
   tint=tuple(custom['color']) if custom else (118,78,49)
   pygame.draw.rect(screen,tint,(sx+5,sy+5,30,30),border_radius=5)
   pygame.draw.polygon(screen,tuple(max(0,v-35) for v in tint),[(sx+2,sy+7),(sx+20,sy-2),(sx+38,sy+7)])
   screen.blit(small.render((custom_name[:2] if custom else kind[:2]).upper(),True,(255,255,255)),(sx+9,sy+12))
 for key,tm in crops.items():
  x,y=map(int,key.split(','));sx=x*T+ox;sy=y*T+oy;pygame.draw.circle(screen,(240,207,57) if time.time()-tm>=crop_time() else (49,106,36),(sx+20,sy+20),10)
 for ax,ay,kind in WILDLIFE:
  sx=int((ax+.5)*T+ox);sy=int((ay+.5)*T+oy)
  if -30<sx<W+30 and -30<sy<H+30:
   shade=(182,120,73) if kind=='deer' else (109,76,66) if kind=='boar' else (215,119,58) if kind=='fox' else (100,160,90)
   pygame.draw.ellipse(screen,(22,44,43),(sx-14,sy+7,29,8))
   pygame.draw.ellipse(screen,shade,(sx-13,sy-9,26,20))
   pygame.draw.circle(screen,(245,235,210),(sx+7,sy-3),3)
   if kind=='deer':
    pygame.draw.line(screen,(140,96,65),(sx-7,sy-8),(sx-13,sy-18),2)
    pygame.draw.line(screen,(140,96,65),(sx+6,sy-8),(sx+12,sy-18),2)
 # Working villagers and military vehicles are visible near the starter settlement.
 for idx,worker in enumerate(villagers):
  wx=132+idx%6*2; wy=141+idx//6*2
  sx=int(wx*T+ox+5*math.sin(tick*.35+idx));sy=int(wy*T+oy+4*math.cos(tick*.37+idx))
  if -25<sx<W+25 and -25<sy<H+25:
   clr={'idle':(156,143,111),'farmer':(112,188,102),'tavern keeper':(199,134,75),'engineer':(102,177,203),'guard':(197,88,91)}.get(worker['job'],(195,195,195))
   pygame.draw.ellipse(screen,(29,43,49),(sx-11,sy+12,23,7))
   pygame.draw.rect(screen,clr,(sx-8,sy-5,17,19),border_radius=5)
   pygame.draw.circle(screen,(233,195,149),(sx,sy-10),8)
   if worker.get('striking') or worker.get('hunger',100)<30:screen.blit(small.render('!',True,(247,106,78)),(sx+9,sy-25))
   if worker.get('homeless'):pygame.draw.arc(screen,(235,211,106),(sx-10,sy-22,20,7),0,3.14,2)
 for idx,v in enumerate(vehicles):
  sx=int((139+idx%5*3)*T+ox);sy=int((145+idx//5*3)*T+oy)
  if -60<sx<W+60 and -60<sy<H+60:
   col={'tank':(90,132,92),'plane':(126,168,202),'drone':(171,116,198)}[v['kind']]
   pygame.draw.rect(screen,col,(sx-18,sy-11,36,22),border_radius=5)
   if v['kind']=='tank':pygame.draw.line(screen,(39,51,43),(sx,sy),(sx+24,sy),5)
   elif v['kind']=='plane':pygame.draw.polygon(screen,(201,223,234),[(sx-6,sy-19),(sx+17,sy),(sx-6,sy+19)])
   else:
    for dx in (-14,14):pygame.draw.circle(screen,(210,178,233),(sx+dx,sy),8,2)
   if v.get('fuel',0)<=0:pygame.draw.line(screen,(215,69,64),(sx-17,sy-14),(sx+17,sy+14),3)
 draw_roaming_npcs(ox,oy)
 for m in monsters:
  mx,my=int(m['x']+ox),int(m['y']+oy)
  pygame.draw.ellipse(screen,(42,46,43),(mx-14,my+8,28,9))
  pygame.draw.ellipse(screen,(176,75,75),(mx-14,my-13,28,28))
  pygame.draw.polygon(screen,(208,91,85),[(mx-12,my-9),(mx-14,my-21),(mx-3,my-12)])
  pygame.draw.polygon(screen,(208,91,85),[(mx+12,my-9),(mx+14,my-21),(mx+3,my-12)])
  pygame.draw.circle(screen,(255,245,205),(mx-5,my-2),4);pygame.draw.circle(screen,(255,245,205),(mx+6,my-2),4)
  pygame.draw.circle(screen,(35,39,44),(mx-4,my-2),2);pygame.draw.circle(screen,(35,39,44),(mx+7,my-2),2)
 colors=[(62,210,255),(255,105,210),(240,225,90),(140,240,120)]
 for fx,fy,ttl in portals[:]:
  sx=int(fx+ox);sy=int(fy+oy)
  if -50<sx<W+50 and -50<sy<H+50:
   pygame.draw.ellipse(screen,(65,238,231),(sx-22,sy-30,44,60),4)
   pygame.draw.ellipse(screen,(176,67,244),(sx-16,sy-24,32,48),3)
 for effect in portals[:]:
  effect[2]-=dt
  if effect[2]<=0:portals.remove(effect)
 for i,p in enumerate(players):
  sx=int(p['x']+ox);sy=int(p['y']+oy);draw_avatar(sx,sy,colors[i],i+1,any(abs(v)>.01 for v in p.get('dir',(0,0))),tick)
  if 'Arcade Crown' in p.get('arcade_unlocks',[]):
   pygame.draw.polygon(screen,(250,215,91),[(sx-10,sy-26),(sx-9,sy-37),(sx-3,sy-31),(sx,sy-41),(sx+5,sy-31),(sx+10,sy-37),(sx+10,sy-26)])
  if 'Carnival Banner' in p.get('arcade_unlocks',[]):
   pygame.draw.line(screen,(230,224,171),(sx+16,sy-8),(sx+16,sy-46),2)
   pygame.draw.polygon(screen,(238,91,156),[(sx+16,sy-45),(sx+39,sy-40),(sx+16,sy-32)])
  pygame.draw.rect(screen,(50,35,35),(sx-18,sy-26,36,5));pygame.draw.rect(screen,(75,240,99),(sx-18,sy-26,int(36*p['hp']/p['maxhp']),5))
 # Day/night cycle; a torch reduces the night overlay for the party.
 night_phase=(tick%240)/240
 if .48<night_phase<.94 and world_options['lighting']!='Bright':
  darkness=pygame.Surface((W,H),pygame.SRCALPHA);darkness.fill((5,10,34,(145 if world_options['lighting']=='Moody' else 110) if any(p['torches'] or p.get('solar_lamp') for p in players) else (215 if world_options['lighting']=='Moody' else 170)));screen.blit(darkness,(0,0))
 if weather in ('Rain','Storm'):
  for z in range(90):
   xx=(z*117+int(tick*190))%W;yy=(z*73+int(tick*290))%H;pygame.draw.line(screen,(126,174,222),(xx,yy),(xx-4,yy+10),1)
 if weather=='Snow':
  for z in range(90):
   xx=(z*117+int(tick*100))%W;yy=(z*73+int(tick*120))%H;pygame.draw.circle(screen,(245,248,252),(xx,yy),2)
 if weather=='Fog':fog=pygame.Surface((W,H),pygame.SRCALPHA);fog.fill((215,218,215,65));screen.blit(fog,(0,0))
 if weather=='Windy':
  for z in range(30):
   xx=(z*87+int(tick*240))%W;yy=(z*53+int(tick*90))%H;pygame.draw.line(screen,(225,225,205),(xx,yy),(xx+18,yy),2)
 # Compass points toward the nearest unlooted landmark (for P1).
 if players and players[0]['compass']:
  p=players[0]; remaining=[(x,y,k) for x,y,k in landmarks if f'{x},{y}' not in p['treasures']]
  if remaining:
   lx,ly,_=min(remaining,key=lambda a:(a[0]*T-p['x'])**2+(a[1]*T-p['y'])**2)
   angle=math.atan2((ly+.5)*T-p['y'],(lx+.5)*T-p['x']);cx0,cy0=W-45,140
   pygame.draw.circle(screen,(25,25,35),(cx0,cy0),27)
   pygame.draw.line(screen,(255,220,70),(cx0,cy0),(int(cx0+21*math.cos(angle)),int(cy0+21*math.sin(angle))),5)
 # Indoor room overlay for each player occupying a shelter.
 for i,p in enumerate(players):
  if not p.get('inside'):continue
  bx=70+(i%2)*515;by=126+(i//2)*260
  cave_room=bool(p.get('cave_tile'))
  pygame.draw.rect(screen,(45,50,58) if cave_room else (79,57,43),(bx,by,485,226),border_radius=9)
  pygame.draw.rect(screen,(94,101,107) if cave_room else (176,141,91),(bx+16,by+32,453,176),border_radius=5)
  pygame.draw.rect(screen,(85,124,151),(bx+195,by+35,94,62))
  pygame.draw.rect(screen,(117,76,47),(bx+42,by+130,110,46),border_radius=6)
  pygame.draw.rect(screen,(96,126,94),(bx+52,by+136,90,34),border_radius=5)
  for f in range(min(4,p.get('home_furnish',0))):pygame.draw.rect(screen,(92,67,50),(bx+310+f*22,by+130,20,30))
  screen.blit(font.render((f'P{i+1} CAVE SHELTER — press C / ; / controller 14 to exit' if cave_room else f'P{i+1} HOME INTERIOR — press your interior key to exit'),True,(250,234,187)),(bx+12,by+5))
 if build_mode and not map_open:
  kind,req,w,stone,scrap,ore,gems=FREE_BUILD[build_kind]
  surface=pygame.Surface((W,70),pygame.SRCALPHA);surface.fill((17,37,42,235));screen.blit(surface,(0,105))
  caption=f'CONSTRUCTION  PAGE {build_kind//8+1}/{math.ceil(len(FREE_BUILD)/8)}  [{build_kind%8+1}] {kind.upper()}  — {ERAS[req]} {"LOCKED" if era<req else "READY"}'
  screen.blit(font.render(caption,True,(243,222,159)),(12,111))
  fullcost={'wood':w,'stone':stone,'scrap':scrap,'ore':ore,'gems':gems,**BUILD_EXTRAS.get(kind,{})}
  screen.blit(small.render('Need: '+cost_text(fullcost)[:115]+'  |  PgUp/PgDn pages; click / Enter to build',True,(230,235,226)),(12,139))
 # HUD
 hud=pygame.Surface((W,105),pygame.SRCALPHA);hud.fill((16,24,32,225));screen.blit(hud,(0,0))
 screen.blit(big.render(f'STRAY SHORES v0.1.0 - SLOT {slot}',True,(252,218,102)),(12,5));screen.blit(font.render(f'{ERAS[era]} | {knowledge} RP | Village {settlement_treasury}c / {len(villagers)} staff | {season} | {weather} | {"Night" if .48<(tick%240)/240<.94 else "Day"} | F1 Help  F2 Maps  |  Party tether 310px',True,(222,232,238)),(215,12))
 for i,p in enumerate(players):
  x=14+i*276; txt=f'P{i+1} HP {p["hp"]}/{p["maxhp"]}  Coins {p["wallet"]}  Bank {p["bank"]}'
  screen.blit(small.render(txt+f'  {shelter_name(p)}' + (f'  RIFT {p.get("portal_charges",0)}/5:{p.get("portal_condition",0)}%' if p.get('portal_gun') else ''),True,colors[i]),(x,45));screen.blit(small.render(f'HP {p["hp"]}  EN {int(p["energy"])}  HUNGER {int(p.get("hunger",90))}  WATER {int(p["thirst"])}  Fish {sum(p['fish_caught'].values())}/{MOD['fish_bucket_capacity']*p['fish_bucket']} Bottles {p['water_filled']}/{p['water_bottles']}  Temp {int(p.get("temperature",65))}  Pack {filled_slots(p)}/{p.get("inventory_slots",5)}  Wpn {p.get("weapon_condition",100)}  Snow {p.get("snow_blocks",0)}  Build {p.get("custom_rooms",0)}  Map {100*len(explored_sets[i])/(N*N):.1f}% Sprint {int(p["sprint"])}%' ,True,(240,240,240)),(x,67))
 for i,p in enumerate(players):
  if p['menu']:
   opts=options(p['menu'],p);mx=34+(i%2)*535;my=110+(i//2)*190
   inventory_view=p['menu'] in ('INVENTORY','CONTAINER')
   visible=9 if inventory_view else 7
   top=max(0,min(p['selection']-4,len(opts)-visible));view=opts[top:top+visible]
   menu_h=74+len(view)*27
   panel=pygame.Surface((492,menu_h),pygame.SRCALPHA);panel.fill((13,25,36,245));screen.blit(panel,(mx,my))
   pygame.draw.rect(screen,colors[i],(mx,my,492,menu_h),2,border_radius=11)
   title=f'P{i+1}  /  {"PARTY SUPPLIES" if p["menu"]=="INVENTORY" else "LOCAL STORAGE" if inventory_view else p["menu"]}'
   screen.blit(font.render(title,True,colors[i]),(mx+15,my+11))
   if inventory_view:
    sub=f'PACK {filled_slots(p)}/{p.get("inventory_slots",5)}    SHARED {sum(shared_items.get(it,0) for it in ITEMS)}    SIZE {p.get("transfer_mode","ALL")}'
    screen.blit(small.render(sub,True,(169,202,215)),(mx+15,my+37))
   for j,opt in enumerate(view,top):
    yy=my+65+(j-top)*27
    selected=j==p['selection']
    if selected:pygame.draw.rect(screen,(56,78,91),(mx+9,yy-2,473,25),border_radius=5)
    heading=opt.startswith('---')
    text_color=(255,225,136) if selected else (117,188,201) if heading else (225,234,235)
    screen.blit(small.render(('▸ ' if selected else '  ')+opt[:61],True,text_color),(mx+15,yy+2))
   if len(opts)>visible:
    screen.blit(small.render(f'{top+1}-{top+len(view)} of {len(opts)}',True,(150,177,191)),(mx+358,my+12))
 logsurf=pygame.Surface((W,112),pygame.SRCALPHA);logsurf.fill((12,18,27,210));screen.blit(logsurf,(0,H-112))
 for z,s in enumerate(logs[-5:]):screen.blit(small.render(s[:135],True,(230,230,215)),(12,H-105+z*20))
 if pressed[pygame.K_F1]:
  pygame.draw.rect(screen,(16,24,36),(230,145,690,380),border_radius=12)
  controls=['P1: WASD move | E interact/confirm | SPACE attack | R eat | Q close','P2: Arrows move | ENTER interact/confirm | Right Shift attack | Right Ctrl eat','Controllers: Stick move | A interact | X attack | Y eat | LB water | RB fish','P1: F water, G fish | P2: Right Alt water, ] fish | F2 maps','Forest = wood, rocks = stone, sand = search; build at BUILDER','Death: life saver consumed or lose 50% wallet + some resources','Shift sprint (P1); P2 Right Ctrl sprint | CAMP: rest/craft | TRADER: sell ore/gems', 'HOUSING: Rent or build shelters incl. treehouses, quinzhees and igloos.', 'Winter lets you gather snow blocks on open ground for snow shelters.', 'BUILDER places house parts; CAMP crafts boats, tarps, sleeping bags & water collectors.', 'P1: TAB inventory | P2: backslash inventory | Controller: button 9', 'Shared inventory: TAB. Choose transfer size 1 / 5 / ALL, then deposit or withdraw.', 'P1: I interior, B launch/land boat | P2: . interior, / boat', 'F3 build mode: 1-8 part, mouse/arrows aim, click/Enter place', 'F7 workshop: pressure carving, pottery firing, glaze, glass shaping, metal molds and sleep gear', 'C dig/enter cave by rock (P2 ;, controller 14); V reinforces cave with supplies.', 'Nights spawn more monsters and make them faster; shelter before dark!', 'Winter cold drains health: shelter or stay near a fueled campfire.', 'EXCHANGE: fast fictional shares; CASINO: terrible odds; BUSINESS: run a souvenir stand.', 'Portal guns: P1 H, P2 apostrophe, controller button 13; Rift Age required.', 'VILLAGE hires paid farmers, tavern staff and engineers; ARMY trains guards and builds vehicles.', 'COUNCIL: laws and elections. PUBLIC WORKS: sanitation, fire, roads and clinics.', 'FORGE: discover recipes, then complete several strikes. Volatile minerals can explode!', 'Winter fishing: a pickaxe or drill must open an ice hole first.', 'Inside a cave press Interact to deepen tunnels, mine coal/metal ores, and make torches.', 'VILLAGE: rename villagers, inspect HP/sleep/thirst, assign beds or hire an organizer.', 'Healthy, hydrated and rested players recover HP while sheltered. Cold can be fatal.']
  for j,line in enumerate(controls[:13]):screen.blit(small.render(line,True,(245,245,245)),(250,160+j*25))
 if forge_timing:
  overlay=pygame.Surface((W,H),pygame.SRCALPHA);overlay.fill((5,8,14,220));screen.blit(overlay,(0,0))
  tx=155;ty=H//2-55;tw=810
  pygame.draw.rect(screen,(27,42,55),(tx-25,ty-105,tw+50,260),border_radius=16)
  screen.blit(big.render('BLACKSMITHING: STRIKE AT THE RIGHT TIME',True,(252,218,129)),(tx,ty-80))
  screen.blit(font.render(forge_timing['name']+' | Strike '+str(forge_timing['stage'])+'/'+str(forge_timing['stages'])+' | P'+str(forge_timing['player']+1)+' | E / Enter / Controller A',True,(236,229,212)),(tx,ty-38))
  pygame.draw.rect(screen,(102,107,114),(tx,ty,tw,30),border_radius=5)
  aim=forge_timing['target'];width=forge_timing['width']
  pygame.draw.rect(screen,(76,200,114),(int(tx+(aim-width/2)*tw),ty,int(width*tw),30),border_radius=3)
  pygame.draw.rect(screen,(252,218,133),(int(tx+forge_timing['pos']*tw)-3,ty-7,6,45))
  screen.blit(font.render('Each craft needs several strikes. Mistakes may cause total loss, salvage, or a blast.',True,(211,211,217)),(tx,ty+52))
 # Single shared equipment board with independent colored cursors.
 if gear_board_open:
  shade=pygame.Surface((W,H),pygame.SRCALPHA);shade.fill((4,9,18,235));screen.blit(shade,(0,0))
  title_surf=big.render('PARTY ARMOURY  |  SHARED EQUIPMENT',True,(245,229,175))
  screen.blit(title_surf,(W//2-title_surf.get_width()//2,23))
  screen.blit(small.render('MOVE: P1 WASD / P2 ARROWS / controllers D-pad    PICK / PLACE: attack key    ESC: close',True,(185,210,222)),(155,64))
  cells=gear_cells();cell_w=290;cell_h=61;xbase=105;ybase=108
  for k,cell in enumerate(cells):
   col=k%3;row=k//3;x=xbase+col*305;y=ybase+row*66
   if cell[0]=='stock':
    name=cell[1];qty=gear_stock.get(name,0)
    label=f'{name}     x{qty}';subtitle='SHARED STOCK  /  '+EQUIPMENT[name][0].upper()
   else:
    pi,slot=cell[1:];name=players[pi].get(slot,'') or '[empty]'
    label=f'P{pi+1} {slot.upper()}: {name}';subtitle='EQUIPPED TO PLAYER '+str(pi+1)
   pygame.draw.rect(screen,(27,43,57),(x,y,cell_w,cell_h),border_radius=9)
   pygame.draw.rect(screen,(74,95,112),(x,y,cell_w,cell_h),1,border_radius=9)
   screen.blit(small.render(label[:37],True,(239,237,221)),(x+12,y+9))
   screen.blit(small.render(subtitle,True,(151,185,205)),(x+12,y+32))
   # Draw offset concentric outlines if multiple players select the same cell.
   for pi,player in enumerate(players):
    if player.get('gear_cursor',0)%len(cells)==k:
     pygame.draw.rect(screen,colors[pi],(x-3-pi*2,y-3-pi*2,cell_w+6+pi*4,cell_h+6+pi*4),3,border_radius=12)
  for pi,player in enumerate(players):
   held=player.get('gear_held','') or 'nothing'
   screen.blit(small.render(f'P{pi+1} HOLDING: {held}',True,colors[pi]),(105+(pi%2)*460,614+(pi//2)*24))
 # Four personal exploration maps; unexplored terrain stays black.
 if map_open:
  shade=pygame.Surface((W,H),pygame.SRCALPHA);shade.fill((5,12,20,240));screen.blit(shade,(0,0))
  screen.blit(big.render('PERSONAL EXPLORATION MAPS - F2 to close',True,(245,228,145)),(180,12))
  scale=1
  for i,p in enumerate(players):
   left=35+(i%2)*555;top=60+(i//2)*325
   screen.blit(font.render(f'PLAYER {i+1}  |  {len(explored_sets[i])}/{N*N} tiles ({100*len(explored_sets[i])/(N*N):.2f}%)',True,colors[i]),(left,top))
   surf=pygame.Surface((N*scale,N*scale));surf.fill((9,13,21))
   for index in explored_sets[i]:
    y,x=divmod(index,N)
    if 0<=y<N and 0<=x<N:
     surf.set_at((x,y),COL[terrain[y][x]])
   for region_id,(_,rx,ry,_,_) in enumerate(REGIONS[1:],1):
    if region_id not in unlocked_regions:
     pygame.draw.circle(surf,(210,90,87),(rx*scale,ry*scale),8,2)
     pygame.draw.line(surf,(210,90,87),((rx-5)*scale,(ry-5)*scale),((rx+5)*scale,(ry+5)*scale),2)
   pygame.draw.circle(surf,colors[i],(int(p['x']//T)*scale,int(p['y']//T)*scale),4)
   screen.blit(pygame.transform.smoothscale(surf,(440,245)),(left,top+25))
 if not map_open:
  bar=['1 FOOD','2 DRINK','3 LIFE','4 FIRE','5 PACK']
  for n,label in enumerate(bar):
   bx=335+n*95;by=H-154
   pygame.draw.rect(screen,(36,48,60),(bx,by,90,30),border_radius=6)
   pygame.draw.rect(screen,(241,193,86) if players[0].get('hotbar_selection')==n else (105,126,139),(bx,by,90,30),2,border_radius=6)
   screen.blit(small.render(label,True,(245,240,225)),(bx+7,by+7))
 # Improved per-player quick HUD and a map preview.
 if not map_open:
  for i,p in enumerate(players):
   bx=12+i*276;by=H-187
   pygame.draw.rect(screen,(24,37,48),(bx,by,268,67),border_radius=8)
   for z,(name,val,col) in enumerate([('HP',max(0,p['hp'])/max(1,p['maxhp']),(225,79,81)),('ENERGY',p['energy']/100,(238,190,81)),('WATER',p['thirst']/100,(83,165,232))]):
    yy=by+8+z*19;screen.blit(small.render(name,True,(233,237,240)),(bx+7,yy-2))
    pygame.draw.rect(screen,(65,75,82),(bx+83,yy,173,11),border_radius=4)
    pygame.draw.rect(screen,col,(bx+83,yy,int(173*max(0,min(1,val))),11),border_radius=4)
  # A compact five-slot preview per player, with live stack counts.
  quick_items=('wood','stone','food','scrap','gems','ore','seed','life','torches')
  for i,p in enumerate(players):
   carried=[(name,p.get(name,0)) for name in quick_items if p.get(name,0)>0][:5]
   for j in range(5):
    x=14+i*276+j*52;y=H-218
    pygame.draw.rect(screen,(42,57,71),(x,y,49,27),border_radius=4)
    if j<len(carried):
     name,count=carried[j]
     item_col={'wood':(149,104,56),'stone':(159,169,174),'food':(181,211,91),'scrap':(130,147,171),'gems':(160,112,224),'ore':(106,138,161),'seed':(127,189,90),'life':(230,101,113),'torches':(241,182,84)}.get(name,(180,180,180))
     pygame.draw.rect(screen,item_col,(x+4,y+5,14,16),border_radius=3)
     pygame.draw.line(screen,(249,247,223),(x+6,y+8),(x+12,y+7),2)
     screen.blit(small.render(str(count),True,(241,246,246)),(x+21,y+5))
   screen.blit(small.render(f'{filled_slots(p)}/{p.get("inventory_slots",5)} slots',True,(233,201,119)),(14+i*276,H-244))
  if SETTINGS['show_minimap']:
   px,py=players[0]['x']/T,players[0]['y']/T
   pygame.draw.rect(screen,(15,25,35),(W-132,112,116,116),border_radius=8)
   for yy in range(-9,10):
    for xx in range(-9,10):
     tx,ty=int(px)+xx,int(py)+yy
     if 0<=tx<N and 0<=ty<N:
      color=tile_color(terrain[ty][tx]) if ty*N+tx in explored_sets[0] else (28,37,45)
      pygame.draw.rect(screen,color,(W-126+(xx+9)*5.7,118+(yy+9)*5.7,6,6))
   pygame.draw.circle(screen,(255,230,90),(W-72,171),4)
  if SETTINGS['show_fps']:screen.blit(small.render(f'FPS {clock.get_fps():.0f}',True,(244,244,244)),(W-90,7))
 # Pause menu / loaded-mod library. Everything is a snapshot from save-slot launch.
 if paused:
  shade=pygame.Surface((W,H),pygame.SRCALPHA);shade.fill((5,10,19,220));screen.blit(shade,(0,0))
  mx,my=255,60
  pygame.draw.rect(screen,(27,41,56),(mx,my,610,605),border_radius=16)
  pygame.draw.rect(screen,(107,141,160),(mx,my,610,605),2,border_radius=16)
  if pause_page=='mods':
   screen.blit(big.render(f'MODS  |  SAVE SLOT {slot}',True,(248,218,125)),(mx+135,my+20))
   active=sum(m['status']=='ACTIVE' for m in MOD_LIST)
   invalid=sum(m['status']!='ACTIVE' for m in MOD_LIST)
   screen.blit(small.render(f'{active} active  |  {invalid} blocked/warnings  |  {len(MOD_LIST)} files inspected',True,(187,208,219)),(mx+30,my+66))
   if not MOD_LIST:
    screen.blit(font.render('No mods installed for this save.',True,(215,225,232)),(mx+38,my+155))
   else:
    first=max(0,min(mod_index-4,max(0,len(MOD_LIST)-9)))
    for j in range(first,min(len(MOD_LIST),first+9)):
     m=MOD_LIST[j];y=my+103+(j-first)*39
     if j==mod_index:pygame.draw.rect(screen,(61,81,98),(mx+20,y-3,570,37),border_radius=6)
     status=m['status'];color=(117,218,164) if status=='ACTIVE' else (248,128,128)
     filename=m['name'][:33]+('...' if len(m['name'])>33 else '')
     screen.blit(small.render(('> ' if j==mod_index else '  ')+filename,True,(235,241,245)),(mx+26,y+6))
     screen.blit(small.render(m['scope'],True,(161,193,209)),(mx+334,y+6))
     screen.blit(small.render(status,True,color),(mx+418,y+6))
    chosen=MOD_LIST[mod_index]
    detail=chosen['features']
    screen.blit(small.render('Selected: '+chosen['name'][:60],True,(244,217,147)),(mx+27,my+479))
    screen.blit(small.render('Features: '+detail[:74],True,(194,218,224)),(mx+27,my+506))
   screen.blit(small.render('Python plugins need SHA256 opt-in; review all code before trusting.',True,(233,177,146)),(mx+25,my+545))
   screen.blit(small.render('Backups in Application Support/Stray Shores/backups/  |  Restart after edits',True,(190,208,217)),(mx+25,my+568))
  else:
   screen.blit(big.render('PAUSED  |  SETTINGS',True,(248,218,125)),(mx+130,my+16))
   for k,label in enumerate(PAUSE_OPTIONS):
    y=my+68+k*42
    value=''
    mapping={1:'show_fps',2:'show_minimap',3:'enemy_ai',4:'controller_deadzone',5:'screen_shake',6:'ui_scale',7:'volume'}
    if k in mapping:value='   '+str(SETTINGS[mapping[k]])
    if k==8:value=f'   ({sum(m["status"]=="ACTIVE" for m in MOD_LIST)} active)'
    color=(255,215,99) if k==pause_index else (214,225,233)
    if k==pause_index:pygame.draw.rect(screen,(59,76,92),(mx+25,y-4,554,35),border_radius=5)
    screen.blit(font.render(('> ' if k==pause_index else '   ')+label+value,True,color),(mx+43,y))
   screen.blit(small.render('Esc: resume  |  Up/Down: navigate  |  Left/Right: adjust  |  Enter/A: select',True,(192,208,217)),(mx+18,my+563))
 if ach_view:draw_achievement_journal()
 if not ach_view:draw_achievement_toast()
 if carving_session is not None:
  st=carving_session
  shade=pygame.Surface((W,H),pygame.SRCALPHA);shade.fill((10,17,24,235));screen.blit(shade,(0,0))
  screen.blit(big.render({'pottery':'POTTERY WHEEL','glass':'GLASS SHAPING','metal':'METAL CASTING'}.get(st['kind'],'WOOD SHAPING WORKSHOP'),True,(240,215,150)),(290,65))
  # Draw the material being physically reshaped, not a freehand bitmap editor.
  pygame.draw.rect(screen,(46,53,62),(125,132,575,445),border_radius=15)
  if st['kind'] in ('pottery','glass','metal'):
   pygame.draw.ellipse(screen,(96,108,114),(225,418,380,75))
   radius=int(70+15*st['progress']);height=int(115+st['stage']*22)
   pygame.draw.ellipse(screen,((76,186,216) if st['kind']=='glass' else (170,177,185) if st['kind']=='metal' else (154,105,79)),(410-radius,398-height,2*radius,58))
   pygame.draw.rect(screen,(154,105,79),(410-radius,418-height,2*radius,height))
   pygame.draw.ellipse(screen,(197,145,109),(410-radius,399-height,2*radius,40))
   pygame.draw.ellipse(screen,(104,72,58),(410-radius//2,403-height,radius,20))
  else:
   pygame.draw.rect(screen,(141,98,60),(237,215,345,195),border_radius=12)
   for q in range(st['stage']):
    pygame.draw.line(screen,(78,46,29),(268+q*54,240),(278+q*54,363),2+st['tool'][1])
  pygame.draw.rect(screen,(80,86,90),(738,207,289,22),border_radius=8)
  pygame.draw.rect(screen,(205,153,84),(738,207,int(289*st['pressure']),22),border_radius=8)
  screen.blit(font.render('Pressure  '+str(int(st['pressure']*100))+'%',True,(235,228,214)),(742,175))
  pygame.draw.rect(screen,(71,83,88),(738,280,289,20),border_radius=8)
  pygame.draw.rect(screen,(81,185,133),(738,280,int(289*st['progress']),20),border_radius=8)
  screen.blit(font.render(f'Stage {st["stage"]+1}/{st["total"]} - shape progress',True,(232,232,230)),(742,248))
  screen.blit(font.render(f'Material integrity: {int(max(0,st["integrity"]))}%',True,(235,205,176)),(742,335))
  if st['kind'] in ('pottery','glass'):screen.blit(font.render(f'Wheel speed: {st["spin"]:.2f}',True,(215,235,245)),(742,368))
  else:screen.blit(font.render('Tool: '+st['tool'][0],True,(215,235,245)),(742,368))
  for n,line in enumerate(('Hold SPACE or left-click: apply pressure','Release: relax your hands','UP/DOWN: change wheel speed / angle','Too much force can crack your work','Esc: abandon unfinished piece')):
   screen.blit(small.render(line,True,(218,221,228)),(740,420+n*30))
 pygame.display.flip()
save();pygame.quit()
